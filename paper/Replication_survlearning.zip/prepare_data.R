# Reconstruct entry-day predictors from the public daily archive, using base R.
# Run in this folder. Place data_2013.zip beside this script first.
# Source: https://www.backblaze.com/cloud-storage/resources/hard-drive-test-data
archive <- "data_2013.zip"
if (!file.exists(archive)) stop("Place the original Backblaze data_2013.zip in this folder.")
files <- utils::unzip(archive, list = TRUE)$Name
files <- sort(files[grepl("(^|/)2013-[0-9]{2}-[0-9]{2}[.]csv$", files)])
stopifnot(length(files) == 266L)
cohort <- NULL
records <- 0L
for (file in files) {
  header <- names(read.csv(unz(archive, file), nrows = 0L))
  classes <- stats::setNames(rep("NULL", length(header)), header)
  classes[c("date", "serial_number", "model")] <- "character"
  classes[c("capacity_bytes", "failure", "smart_5_raw", "smart_9_raw",
    "smart_194_raw", "smart_197_raw")] <- "numeric"
  daily <- read.csv(unz(archive, file), stringsAsFactors = FALSE, colClasses = classes)
  records <- records + nrow(daily)
  date <- as.numeric(as.Date(daily$date))
  stopifnot(length(unique(date)) == 1L, !anyDuplicated(daily$serial_number))
  fresh <- if (is.null(cohort)) rep(TRUE, nrow(daily)) else
    !daily$serial_number %in% cohort$serial_number
  if (any(fresh)) {
    new <- daily[fresh, ]
    cohort <- rbind(cohort, data.frame(serial_number = new$serial_number, model = new$model,
      capacity_bytes = new$capacity_bytes, first_date_num = date[1L],
      last_date_num = date[1L], failure_date_num = NA_real_, baseline_failure = new$failure,
      smart_5_first = new$smart_5_raw, smart_9_first = new$smart_9_raw,
      smart_194_first = new$smart_194_raw, smart_197_first = new$smart_197_raw))
  }
  index <- match(daily$serial_number, cohort$serial_number)
  cohort$last_date_num[index] <- date[1L]
  failed <- index[daily$failure == 1L]
  failed <- failed[is.na(cohort$failure_date_num[failed])]
  cohort$failure_date_num[failed] <- date[1L]
  cat(basename(file), ": ", nrow(daily), " records\n", sep = "")
}
cohort$event <- as.integer(!is.na(cohort$failure_date_num))
cohort$time_days <- ifelse(cohort$event == 1L, cohort$failure_date_num,
  cohort$last_date_num) - cohort$first_date_num
cohort$baseline_date <- as.character(as.Date(cohort$first_date_num, origin = "1970-01-01"))
# Keep the original model encoding; the group stored as "2 TB" pools nominal
# 1.5 and 2 TB drives. Tables and figures display it as "1.5/2 TB".
cohort$capacity_group <- paste0(round(cohort$capacity_bytes / 1e12), " TB")
cohort$manufacturer <- ifelse(grepl("^Hitachi", cohort$model), "Hitachi",
  ifelse(grepl("^ST", cohort$model), "Seagate",
  ifelse(grepl("^WDC|^WD", cohort$model), "Western Digital",
  ifelse(grepl("^TOSHIBA", cohort$model), "Toshiba", "Other"))))
cohort$eligible <- cohort$baseline_failure == 0L & cohort$time_days > 0
cohort$exclusion <- ifelse(cohort$baseline_failure == 1L, "failure_at_entry",
  ifelse(cohort$time_days <= 0, "no_positive_post_entry_followup", "included"))
stopifnot(nrow(cohort) == 29072L, sum(cohort$event) == 724L,
  !anyDuplicated(cohort$serial_number))
write.csv(cohort, "backblaze_2013_baseline.csv", row.names = FALSE, na = "")
write.csv(data.frame(daily_records = records, drives = nrow(cohort),
  failures = sum(cohort$event), eligible = sum(cohort$eligible),
  eligible_failures = sum(cohort$event[cohort$eligible]),
  missing_smart5 = sum(is.na(cohort$smart_5_first[cohort$eligible])),
  missing_smart9 = sum(is.na(cohort$smart_9_first[cohort$eligible])),
  missing_smart194 = sum(is.na(cohort$smart_194_first[cohort$eligible])),
  missing_smart197 = sum(is.na(cohort$smart_197_first[cohort$eligible]))),
  "baseline_provenance.csv", row.names = FALSE)
write.csv(as.data.frame(table(cohort$exclusion)), "baseline_eligibility.csv", row.names = FALSE)
writeLines(capture.output(sessionInfo()), "data_sessionInfo.txt")
print(read.csv("baseline_provenance.csv"))
