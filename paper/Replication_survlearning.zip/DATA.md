# Backblaze 2013 baseline cohort

Source: [Backblaze Drive Stats](https://www.backblaze.com/cloud-storage/resources/hard-drive-test-data).
The original annual archive has 266 daily files (April 10 to December 31, 2013),
5,091,501 records, 29,072 drive serial numbers and 724 recorded failures.

## Reconstructing the baseline

The accompanying backblaze_2013_baseline.csv is rebuilt by prepare_data.R,
using only base R. Daily CSV files are processed in date order. All selected
SMART values are fixed at each drive's exact first record, never updated from
a later nonmissing value. baseline_date is retained and verified against entry.
SMART 5, 9, 194 and 197 are all observed at entry for every source drive.
No imputation is used. The provenance and eligibility tables are supplied.

The prediction landmark is immediately after the first snapshot, conditional on
the drive being operational. Six drives fail at their first record and eight
others have no positive post-entry follow-up. These histories stay in the source
CSV with eligibility/reason columns. The subsequent-failure analytic cohort has
29,058 drives, 718 failures and 28,340 censored observations (97.5291%).
These exclusions define a risk set, not a computationally convenient sample.

Elapsed duration is the failure or final recorded date minus the first recorded
date. Its maximum is 265 days. This is follow-up
after first appearance, not lifetime since installation. Nonfailure disappearance
is treated as censoring; informative withdrawal remains a substantive limitation.

The stratified random 80/20 split contains 23,246 training drives/574 failures
and 5,812 held-out drives/144 failures. Every full-application learner uses all
eligible training rows. The split is historical, not prospective or chronological.

## Capacity encoding

Capacity is encoded by round(capacity_bytes / 1e12). The stored "2 TB" factor
therefore pools nominal 1.5 TB (3,102 drives, 264 failures) and 2 TB
(5,198 drives, 55 failures). Tables and figures label this group "1.5/2 TB".
The internal level is used consistently in fitting and prediction.
capacity_exact_summary.csv reports both
byte-level categories. These counts are descriptive, not a capacity effect.

## Probability-assessment target

Event models use all training rows. For evaluation to 180 days, reference and
assessment restrict to drives entering by July 4, 2013, so later administrative
entry does not preclude that horizon. A reference reverse-KM model is stratified
by prespecified 30-day entry bands. Conditional independence of nonfailure
withdrawal within these bands and transportability are assumptions, not verified
facts. No censoring weight is silently clipped.

## Optional raw-data reconstruction

The main replication needs only the small supplied CSV. To audit its construction,
download the annual 2013 ZIP from the Backblaze source page, keep its name
data_2013.zip beside prepare_data.R, and run source("prepare_data.R").
The raw ZIP is about 81 MB and is not duplicated in the replication ZIP.

SHA256, raw archive:
7F5A53E79B16E695B4B034955806BB3BB194534B169F6ECA460DFD3DC48096FE

SHA256, supplied baseline CSV:
8C0EB6DB5CCD73B8545AA470D82C3855871A85373455321964A069CDC49AA925

Backblaze requests attribution and responsibility for data use, permits derived
works, and prohibits sale of the data themselves. The data are not relicensed
under the package's GPL license.
