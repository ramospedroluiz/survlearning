# Replication for the survlearning software manuscript.
# Run this file from its own folder, after installing the supplied source:
# remotes::install_local("survlearning_0.3.5.tar.gz",
#                        dependencies = NA, upgrade = "never")
# The complete comparison additionally needs censored and parsnip.
# Modeling dependencies are installed with the source package. Integrated
# engines do not require penAFT, randomForestSRC, flexsurv or survivalsvm.
# Neural Cox requires no additional runtime. No Torch or Python is needed.
# The drive-level CSV is distributed beside this script. Its provenance and
# limitations are described in DATA.md. No downloading is needed to run it.

Sys.setlocale("LC_ALL", "C")
options(width = 75, useFancyQuotes = FALSE)
library("survlearning")
library("survival")
stopifnot(as.character(packageVersion("survlearning")) == "0.3.5")
engines <- c("survival", "glmnet", "rpart", "gbm", "xgboost", "MTLR",
             "clarabel", "CoxBoost", "ranger", "aorsf", "nnet")
stopifnot(all(vapply(engines, requireNamespace, logical(1), quietly = TRUE)))
warnings_seen <- character()

# 1. Method catalogue and the small, common tuning grids.
catalogue <- surv_methods()
catalogue <- catalogue[catalogue$method != "km", ]
write.csv(catalogue, "method_catalogue.csv", row.names = FALSE)
grids <- list(
  aft = list(distribution = c("weibull", "lognormal", "loglogistic")),
  aft_lasso = list(lambda = c(0.01, 0.1)),
  aft_ridge = list(lambda = c(0.01, 0.1)),
  aft_elasticnet = list(lambda = c(0.01, 0.1), alpha = c(0.25, 0.75)),
  cox = NULL,
  cox_lasso = list(lambda = c(0.001, 0.01)),
  cox_ridge = list(lambda = c(0.001, 0.01)),
  cox_elasticnet = list(lambda = c(0.001, 0.01), alpha = c(0.25, 0.75)),
  tree = list(cp = c(0.001, 0.01, 0.05)),
  rsf = list(min_node = c(15L, 50L)),
  boosting = list(trees = c(100L, 200L)),
  xgboost_cox = list(trees = c(100L, 200L), depth = c(1L, 2L)),
  xgboost_aft = list(trees = c(100L, 200L), scale = c(0.5, 1)),
  mtlr = list(intervals = c(5L, 10L), lambda = c(0.1, 1)),
  svm = list(cost = 10^(-3:3), kernel = c("linear", "additive")),
  cox_spline = list(df = c(2L, 3L)),
  flexsurv = list(knots = c(0L, 1L)),
  coxboost = list(steps = c(50L, 100L)),
  ranger = list(min_node = c(15L, 50L)),
  aorsf = list(min_node = c(5L, 15L)),
  neural_cox = list(hidden = c(8L, 16L)),
  neural_discrete = list(hidden = c(4L, 8L)),
  svm_rank = list(kernel = c("linear", "additive"), lambda = 10^(-5:1)),
  svm_hybrid = list(kernel = c("linear", "additive"), lambda = 10^(-5:1),
                    rank_weight = c(0.25, 0.5, 0.75)),
  svm_ipcw = list(kernel = c("linear", "additive"), lambda = 10^(-5:1),
                  horizon = c(90, 180), epsilon = c(0, 0.02))
)
fixed <- list(rsf = list(trees = 200L, threads = 1L),
              xgboost_cox = list(threads = 1L),
              xgboost_aft = list(threads = 1L, distribution = "normal"),
              svm = list(solver = "clarabel"),
              svm_rank = list(max_iter = 5000L),
              svm_hybrid = list(max_iter = 5000L),
              svm_ipcw = list(max_iter = 5000L),
              flexsurv = list(scale = "hazard"),
              ranger = list(trees = 200L, threads = 1L),
              aorsf = list(trees = 200L, threads = 1L),
              neural_cox = list(epochs = 100L, learning_rate = .001,
                decay = .0001, ties = "efron"),
              neural_discrete = list(intervals = 8L, max_iter = 1000L, decay = .01))
labels <- c(aft = "Parametric AFT", aft_lasso = "Gehan AFT LASSO",
  aft_ridge = "Gehan AFT ridge", aft_elasticnet = "Gehan AFT elastic net",
  cox = "Cox", cox_lasso = "Cox LASSO", cox_ridge = "Cox ridge",
  cox_elasticnet = "Cox elastic net", tree = "Survival tree",
  rsf = "Random survival forest", boosting = "Cox gradient boosting",
  xgboost_cox = "XGBoost Cox", xgboost_aft = "XGBoost AFT",
  mtlr = "MTLR", svm = "Censored SVM",
  cox_spline = "Spline Cox", flexsurv = "Flexible parametric",
  coxboost = "Componentwise CoxBoost", ranger = "Ranger forest",
  aorsf = "Oblique forest", neural_cox = "Native neural Cox",
  neural_discrete = "Discrete neural survival",
  svm_linear = "SVR (linear)", svm_additive = "SVR (additive)",
  svm_rank = "Ranking SVM", svm_hybrid = "Hybrid SVM", svm_ipcw = "IPCW SVR",
  svm_rank_linear = "Ranking SVM (linear)", svm_rank_additive = "Ranking SVM (additive)",
  svm_hybrid_linear = "Hybrid SVM (linear)", svm_hybrid_additive = "Hybrid SVM (additive)",
  svm_ipcw_linear = "IPCW SVR (linear)", svm_ipcw_additive = "IPCW SVR (additive)")

# 2. A controlled illustration: 25 covariate-based methods on identical rows.
# This is one generated data set, not a repeated simulation experiment.
set.seed(20261020)
simulated <- data.frame(temperature = rnorm(1560, 30, 5),
  power_hours = runif(1560, 1000, 30000), load = runif(1560, 0, 1),
  design = factor(sample(c("A", "B"), 1560, replace = TRUE)))
z <- (simulated$temperature - 30) / 5
h <- (simulated$power_hours - 15500) / 14500
mu <- log(90) - 0.5 * z - 0.25 * h - 0.45 * simulated$load^2 +
      0.3 * z * simulated$load + 0.25 * (simulated$design == "B")
true_time <- exp(mu + 0.7 * rnorm(1560))
censor_time <- pmin(rexp(1560, rate = 1 / 160), 365)
simulated$time <- pmin(true_time, censor_time)
simulated$event <- as.integer(true_time <= censor_time)
sim_train <- simulated[1:360, ]
sim_test <- simulated[361:1560, ]
sim_formula <- Surv(time, event) ~ temperature + power_hours + load + design
sim_models <- list()
sim_results <- data.frame()
for (method in names(grids)) {
  cat("Simulation: ", method, "\n", sep = "")
  start <- proc.time()[["elapsed"]]
  settings_fixed <- if (is.null(fixed[[method]])) list() else fixed[[method]]
  fit <- withCallingHandlers(
    surv_tune(sim_formula, sim_train, method = method,
      grid = grids[[method]], params = settings_fixed,
      folds = 3, seed = 20261021),
    warning = function(w) {
      warnings_seen <<- c(warnings_seen, paste("simulation", method,
                                             conditionMessage(w), sep = ": "))
    })
  sim_models[[method]] <- fit
  risk <- surv_predict(fit, sim_test)
  cc <- concordance(Surv(time, event) ~ risk, sim_test, reverse = TRUE)
  sim_results <- rbind(sim_results, data.frame(method = method,
    cv = max(fit$results$mean_cindex, na.rm = TRUE),
    test = cc$concordance, se = sqrt(cc$var),
    seconds = proc.time()[["elapsed"]] - start,
    failed_folds = sum(fit$results$failed_folds)))
  write.csv(sim_results, "simulation_results.csv", row.names = FALSE)
  saveRDS(sim_models, "simulation_models.rds")
}

# 3. Entry-day predictors, verified against the original daily records.
cohort <- read.csv("backblaze_2013_baseline.csv", stringsAsFactors = FALSE)
stopifnot(nrow(cohort) == 29072L, sum(cohort$event) == 724L,
  all(cohort$baseline_date == as.character(as.Date(cohort$first_date_num, origin = "1970-01-01"))))
drives <- cohort[cohort$eligible, ]
stopifnot(nrow(drives) == 29058L, sum(drives$event) == 718L,
  all(drives$time_days > 0), all(drives$baseline_failure == 0L))
needed <- c("time_days", "event", "manufacturer", "capacity_group",
            "smart_5_first", "smart_9_first", "smart_194_first",
            "smart_197_first", "first_date_num")
missing <- colSums(is.na(drives[needed]))
write.csv(data.frame(variable = names(missing), missing = missing),
          "missingness.csv", row.names = FALSE)
stopifnot(!anyNA(drives[needed]), !anyDuplicated(drives$serial_number))
drives$manufacturer <- factor(drives$manufacturer)
drives$capacity_group <- factor(drives$capacity_group,
                                levels = c("1 TB", "2 TB", "3 TB", "4 TB"))
drives$log_power_hours <- log1p(drives$smart_9_first)
drives$temperature <- drives$smart_194_first
drives$log_reallocated <- log1p(drives$smart_5_first)
drives$pending <- as.integer(drives$smart_197_first > 0)
drives$entry_day <- drives$first_date_num - min(drives$first_date_num)
form <- Surv(time_days, event) ~ manufacturer + capacity_group +
        log_power_hours + temperature + log_reallocated + pending + entry_day

# The split is performed by drive and stratified by event. Test rows never
# enter tuning. The split is random, not chronological.
set.seed(20261022)
train_id <- integer()
for (status in c(0L, 1L)) {
  ids <- which(drives$event == status)
  train_id <- c(train_id, sample(ids, floor(0.8 * length(ids))))
}
train_id <- sort(train_id)
train <- drives[train_id, ]
test <- drives[-train_id, ]
write.csv(data.frame(serial_number = drives$serial_number,
  sample = ifelse(seq_len(nrow(drives)) %in% train_id, "training", "test")),
  "split.csv", row.names = FALSE)
summary_data <- data.frame(sample = c("Cohort", "Training", "Test"),
  n = c(nrow(drives), nrow(train), nrow(test)),
  events = c(sum(drives$event), sum(train$event), sum(test$event)),
  censored = c(sum(drives$event == 0), sum(train$event == 0), sum(test$event == 0)))
summary_data$censor_percent <- 100 * summary_data$censored / summary_data$n
write.csv(summary_data, "data_summary.csv", row.names = FALSE)
capacity <- aggregate(cbind(n = rep(1, nrow(drives)), events = drives$event,
                           drive_days = drives$time_days),
                      list(capacity = drives$capacity_group), sum)
capacity$capacity <- as.character(capacity$capacity)
capacity$capacity[capacity$capacity == "2 TB"] <- "1.5/2 TB"
write.csv(capacity, "capacity_summary.csv", row.names = FALSE)
capacity_exact <- aggregate(cbind(n = rep(1L, nrow(drives)), events = drives$event),
  list(capacity_bytes = drives$capacity_bytes, stored_group = drives$capacity_group), sum)
capacity_exact$display_group <- ifelse(capacity_exact$stored_group == "2 TB",
  "1.5/2 TB", as.character(capacity_exact$stored_group))
write.csv(capacity_exact, "capacity_exact_summary.csv", row.names = FALSE)
covariates <- data.frame(variable = c("Power-on hours", "Temperature",
  "Reallocated sectors", "Pending sectors", "Entry day"))
raw_x <- drives[c("smart_9_first", "smart_194_first", "smart_5_first",
                  "smart_197_first", "entry_day")]
covariates$median <- vapply(raw_x, median, numeric(1))
covariates$q1 <- vapply(raw_x, quantile, numeric(1), probs = 0.25)
covariates$q3 <- vapply(raw_x, quantile, numeric(1), probs = 0.75)
covariates$maximum <- vapply(raw_x, max, numeric(1))
write.csv(covariates, "covariate_summary.csv", row.names = FALSE)

# Each SVM objective/kernel is selected on the same three training folds.
# The three Gehan AFT variants are illustrated on the generated data only.
real_methods <- c(setdiff(names(grids)[1:15], c("aft_lasso", "aft_ridge",
  "aft_elasticnet", "svm")), "svm_linear", "svm_additive", "neural_cox",
  "svm_rank_linear", "svm_rank_additive", "svm_hybrid_linear", "svm_hybrid_additive",
  "svm_ipcw_linear", "svm_ipcw_additive")
real_models <- list()
real_results <- data.frame()
for (identifier in real_methods) {
  method <- if (startsWith(identifier, "svm_")) sub("_(linear|additive)$", "", identifier) else identifier
  cat("Backblaze: ", identifier, "\n", sep = "")
  start <- proc.time()[["elapsed"]]
  settings_fixed <- if (is.null(fixed[[method]])) list() else fixed[[method]]
  grid <- grids[[method]]
  if (startsWith(identifier, "svm_")) {
    settings_fixed$kernel <- sub(paste0(method, "_"), "", identifier, fixed = TRUE)
    grid$kernel <- NULL
    if (method == "svm") settings_fixed$solver <- "clarabel"
  }
  fit <- withCallingHandlers(
    surv_tune(form, train, method = method, grid = grid,
      params = settings_fixed, folds = 3, seed = 20261023),
    warning = function(w) {
      warnings_seen <<- c(warnings_seen, paste("Backblaze", method,
                                             conditionMessage(w), sep = ": "))
    })
  real_models[[identifier]] <- fit
  risk <- surv_predict(fit, test)
  cc <- concordance(Surv(time_days, event) ~ risk, test, reverse = TRUE)
  real_results <- rbind(real_results, data.frame(method = identifier,
    cv = max(fit$results$mean_cindex, na.rm = TRUE), test = cc$concordance,
    se = sqrt(cc$var), seconds = proc.time()[["elapsed"]] - start,
    failed_folds = sum(fit$results$failed_folds)))
  write.csv(real_results, "backblaze_results.csv", row.names = FALSE)
  saveRDS(real_models, "backblaze_models.rds")
}

saveRDS(lapply(real_models[grep("^svm_(rank|hybrid|ipcw)_", names(real_models))],
  function(x) x$best_params), "svm_learning_settings.rds")

# 4. Figures, obtained from the fits above (not from the earlier chapter).
colors <- c("#36456F", "#249685", "#BA505E", "#707070")
pdf("figure_km.pdf", width = 6.6, height = 3.8, useDingbats = FALSE)
par(mar = c(4, 4.5, 0.6, 0.6), las = 1)
km <- survfit(Surv(time_days, event) ~ capacity_group, data = drives)
plot(km, col = colors, lwd = 1.7, conf.int = FALSE, mark.time = FALSE,
     ylim = c(0.93, 1), xlab = "Days since first recorded observation",
     ylab = "Estimated survival probability")
legend("bottomleft", c("1 TB", "1.5/2 TB", "3 TB", "4 TB"), col = colors,
       lty = 1, lwd = 1.7, bty = "n", ncol = 2, cex = 0.9)
dev.off()

pdf("figure_concordance.pdf", width = 6.6, height = 7.0, useDingbats = FALSE)
par(mar = c(4, 11, 0.6, 0.8), las = 1)
o <- order(real_results$test)
rr <- real_results[o, ]
plot(rr$test, seq_len(nrow(rr)), xlim = c(0.35, 0.95), yaxt = "n",
     pch = 19, col = colors[1], xlab = "Test-set Harrell C-index", ylab = "")
segments(pmax(0, rr$test - 1.96 * rr$se), seq_len(nrow(rr)),
         pmin(1, rr$test + 1.96 * rr$se), seq_len(nrow(rr)), col = colors[1])
axis(2, seq_len(nrow(rr)), labels[rr$method], tick = FALSE, cex.axis = 0.85)
abline(v = 0.5, lty = 3, col = "gray60")
dev.off()

new_drives <- data.frame(manufacturer = factor(rep("Hitachi", 3),
  levels = levels(train$manufacturer)), capacity_group = factor(rep("3 TB", 3),
  levels = levels(train$capacity_group)), log_power_hours = log1p(c(5000, 15000, 30000)),
  temperature = c(25, 30, 35), log_reallocated = log1p(c(0, 10, 100)),
  pending = c(0L, 0L, 1L), entry_day = 0)
horizons <- c(90, 180)
new_results <- data.frame()
for (method in c("rsf", "xgboost_cox", "xgboost_aft", "mtlr", "neural_cox")) {
  ss <- surv_predict(real_models[[method]], new_drives,
                     type = "survival", times = horizons)
  for (i in seq_len(nrow(new_drives))) {
    new_results <- rbind(new_results, data.frame(method = method, profile = i,
      failure_90 = 1 - ss[i, 1], failure_180 = 1 - ss[i, 2]))
  }
}
write.csv(new_results, "new_profiles.csv", row.names = FALSE)
pdf("figure_profiles.pdf", width = 6.6, height = 3.7, useDingbats = FALSE)
par(mar = c(4, 4.5, 0.6, 0.7), las = 1)
tt <- seq(0, max(train$time_days), by = 1)
ss <- surv_predict(real_models$rsf, new_drives, type = "survival", times = tt)
matplot(tt, t(ss), type = "l", lty = 1:3, lwd = 1.7, col = colors[1:3],
        xlab = "Days since first recorded observation", ylab = "Predicted survival",
        ylim = c(min(ss), 1))
legend("bottomleft", paste("Profile", 1:3), col = colors[1:3],
       lty = 1:3, lwd = 1.7, bty = "n")
dev.off()

train_risk <- surv_predict(real_models$rsf, train)
test_risk <- surv_predict(real_models$rsf, test)
breaks <- c(-Inf, quantile(train_risk, c(0.25, 0.5, 0.75)), Inf)
test$risk_group <- cut(test_risk, breaks = breaks, labels = paste0("Q", 1:4))
groups <- aggregate(cbind(n = rep(1, nrow(test)), events = test$event),
                    list(group = test$risk_group), sum)
groups$crude_percent <- 100 * groups$events / groups$n
write.csv(groups, "rsf_groups.csv", row.names = FALSE)
pdf("figure_groups.pdf", width = 6.6, height = 3.8, useDingbats = FALSE)
par(mar = c(4, 4.5, 0.6, 0.6), las = 1)
plot(survfit(Surv(time_days, event) ~ risk_group, test), col = colors,
     lwd = 1.7, conf.int = FALSE, mark.time = FALSE,
     ylim = c(0.88, 1),
     xlab = "Days since first recorded observation", ylab = "Estimated survival")
legend("bottomleft", paste0("Q", 1:4), col = colors, lty = 1,
       lwd = 1.7, bty = "n", ncol = 2)
dev.off()

# 5. Machine-readable outputs, exact model settings, and manuscript tables.
settings <- data.frame()
for (study in c("simulation", "Backblaze")) {
  fits <- if (study == "simulation") sim_models else real_models
  for (method in names(fits)) {
    params <- fits[[method]]$best_params
    settings <- rbind(settings, data.frame(study = study, method = method,
      candidates = nrow(fits[[method]]$grid),
      selected = paste(names(params), unlist(params), sep = "=", collapse = "; ")))
    write.csv(fits[[method]]$fold_results,
      paste0("folds_", if (study == "simulation") "sim_" else "real_", method, ".csv"),
      row.names = FALSE)
  }
}
write.csv(settings, "selected_settings.csv", row.names = FALSE)
writeLines(unique(warnings_seen), "engine_warnings.txt")
writeLines(capture.output(sessionInfo()), "sessionInfo.txt")
versions <- data.frame(package = c("survlearning", engines),
  version = vapply(c("survlearning", engines), function(x)
    as.character(packageVersion(x)), character(1)))
write.csv(versions, "engine_versions.csv", row.names = FALSE)
# The supplied engines.bib records the cited works, including integrated code.
# Numerical replication does not regenerate citations from newer installations.

# These small formatting functions are only for manuscript outputs.
row <- function(x) paste0(paste(x, collapse = " & "), " \\\\")
tab <- character()
for (study in c("Simulation", "Backblaze")) {
  result <- if (study == "Simulation") sim_results else real_results
  tab <- c(tab, paste0("\\newcommand{\\", study, "Table}{%"),
    "\\begin{tabular}{lrrr}\\toprule",
    row(c("Method", "CV $C$", "Test $C$", "SE")), "\\midrule")
  for (i in seq_len(nrow(result))) {
    r <- result[i, ]
    tab <- c(tab, row(c(labels[r$method], sprintf("%.3f", c(r$cv, r$test, r$se)))))
  }
  tab <- c(tab, "\\bottomrule\\end{tabular}}")
}
tab <- c(tab, "\\newcommand{\\CohortTable}{%",
  "\\begin{tabular}{lrrrr}\\toprule",
  row(c("Sample", "Drives", "Failures", "Censored", "Censored (\\%)")), "\\midrule")
for (i in seq_len(nrow(summary_data))) {
  r <- summary_data[i, ]
  tab <- c(tab, row(c(r$sample, format(r$n, big.mark = ","),
    format(r$events, big.mark = ","), format(r$censored, big.mark = ","),
    sprintf("%.2f", r$censor_percent))))
}
tab <- c(tab, "\\bottomrule\\end{tabular}}",
  "\\newcommand{\\ProfileTable}{%", "\\begin{tabular}{llrr}\\toprule",
  row(c("Method", "Profile", "$\\widehat F(90)$", "$\\widehat F(180)$")), "\\midrule")
for (i in seq_len(nrow(new_results))) {
  r <- new_results[i, ]
  tab <- c(tab, row(c(labels[r$method], r$profile,
                     sprintf("%.4f", c(r$failure_90, r$failure_180)))))
}
tab <- c(tab, "\\bottomrule\\end{tabular}}",
  paste0("\\newcommand{\\SimTrainEvents}{", sum(sim_train$event), "}"),
  paste0("\\newcommand{\\SimTestEvents}{", sum(sim_test$event), "}"),
  paste0("\\newcommand{\\SimTrainCensor}{",
         sprintf("%.1f", 100 * mean(sim_train$event == 0)), "}"),
  paste0("\\newcommand{\\RealFailedFolds}{", sum(real_results$failed_folds), "}"),
  paste0("\\newcommand{\\SimFailedFolds}{", sum(sim_results$failed_folds), "}"))
for (key in c("svm", "neural_cox")) {
  name <- if (key == "svm") "SimSvmTest" else "SimNeuralTest"
  tab <- c(tab, paste0("\\newcommand{\\", name, "}{",
    sprintf("%.3f", sim_results$test[sim_results$method == key]), "}"))
}
for (key in c("neural_cox", "svm_linear", "svm_additive")) {
  name <- switch(key, neural_cox = "RealNeuralTest", svm_linear = "RealLinearTest",
    svm_additive = "RealAdditiveTest")
  tab <- c(tab, paste0("\\newcommand{\\", name, "}{",
    sprintf("%.3f", real_results$test[real_results$method == key]), "}"))
}
tab <- c(tab, paste0("\\newcommand{\\RealNeuralHidden}{",
  real_models$neural_cox$best_params$hidden, "}"),
  paste0("\\newcommand{\\RealLinearCost}{", real_models$svm_linear$best_params$cost, "}"),
  paste0("\\newcommand{\\RealAdditiveCost}{", real_models$svm_additive$best_params$cost, "}"))
# Separate cost paths for the two censored-regression kernels.
tab <- c(tab, "\\newcommand{\\SvmTuningTable}{%", "\\begin{tabular}{rrr}\\toprule",
  row(c("Cost", "Linear CV $C$", "Additive CV $C$")), "\\midrule")
for (i in seq_len(nrow(real_models$svm_linear$grid))) {
  tab <- c(tab, row(c(format(real_models$svm_linear$grid$cost[i], scientific = FALSE),
    sprintf("%.4f", real_models$svm_linear$results$mean_cindex[i]),
    sprintf("%.4f", real_models$svm_additive$results$mean_cindex[i]))))
}
tab <- c(tab, "\\bottomrule\\end{tabular}}")
writeLines(tab, "results.tex")
print(sim_results, row.names = FALSE)
print(real_results, row.names = FALSE)

# 6. Post-fit interpretation uses every held-out drive, without refitting.
importance <- data.frame()
for (method in c("cox", "rsf", "neural_cox")) {
  cat("Interpretation: ", method, "\n", sep = "")
  imp <- surv_importance(real_models[[method]], test,
    n_repeats = 5L, seed = 20261024L)
  importance <- rbind(importance, data.frame(model = method,
    as.data.frame(imp), row.names = NULL))
}
write.csv(importance, "workflow_importance.csv", row.names = FALSE)
ale <- surv_ale(real_models$rsf, test, variable = "temperature",
  bins = 10L, type = "failure", time = 180)
write.csv(as.data.frame(ale), "workflow_ale.csv", row.names = FALSE)
rsf_imp <- importance[importance$model == "rsf", ]
pdf("figure_interpretation.pdf", width = 7, height = 3.8, useDingbats = FALSE)
par(mfrow = c(1, 2), mar = c(4.3, 7.5, 1.6, .8), las = 1)
ii <- order(rsf_imp$importance)
bars <- barplot(rsf_imp$importance[ii], horiz = TRUE,
  names.arg = rsf_imp$variable[ii], col = colors[1], border = NA,
  cex.names = .72, xlab = "Decrease in Harrell C", main = "Permutation importance")
abline(v = 0, col = "gray70")
par(mar = c(4.3, 4.5, 1.6, .8))
plot(ale$upper, ale$ale, type = "b", pch = 19, col = colors[2],
  xlab = "Recorded SMART temperature", ylab = "Centered effect on F(180)",
  main = "Accumulated local effects", cex.main = .9)
abline(h = 0, col = "gray70", lty = 3)
dev.off()

# The same three illustrative profiles are conditioned on survival to day 30.
remaining <- surv_reliability(real_models$rsf, new_drives,
  horizons = c(60, 150), age = 30, probs = c(.01, .5), grid_points = 501L)
write.csv(remaining$summary, "workflow_reliability.csv", row.names = FALSE)
write.csv(remaining$quantiles, "workflow_quantiles.csv", row.names = FALSE)

# 7. A separate generated example has covariate-dependent censoring.
# Complete failure times are known only because this is a controlled example.
set.seed(20261025)
conditional_data <- data.frame(x1 = runif(4000, -1, 1),
  x2 = rbinom(4000, 1, .5))
conditional_data$true_time <- rexp(4000,
  rate = .02 * exp(.8 * conditional_data$x1 - .3 * conditional_data$x2))
conditional_data$censor_time <- pmin(40, rexp(4000,
  rate = .03 * exp(conditional_data$x1 + .2 * conditional_data$x2)))
conditional_data$time <- pmin(conditional_data$true_time, conditional_data$censor_time)
conditional_data$event <- as.integer(conditional_data$true_time <= conditional_data$censor_time)
ct_train <- conditional_data[1:2000, ]
ct_test <- conditional_data[2001:4000, ]
ct_formula <- Surv(time, event) ~ x1 + x2
ct_fit <- surv_fit(ct_formula, ct_train, "cox")
ct_g <- surv_censor_fit(ct_formula, ct_train, method = "cox")
ct_metrics <- c("harrell", "ipcw_c", "auc", "brier")
marginal <- surv_evaluate(ct_fit, ct_test, ct_metrics, times = 10, tau = 15)
conditional <- surv_evaluate(ct_fit, ct_test, ct_metrics, times = 10, tau = 15,
  censoring_model = ct_g)
complete_test <- ct_test
complete_test$time <- complete_test$true_time
complete_test$event <- 1L
complete_train <- ct_train
complete_train$time <- complete_train$true_time
complete_train$event <- 1L
complete <- surv_evaluate(ct_fit, complete_test, ct_metrics, times = 10, tau = 15,
  censoring_data = complete_train)
conditional_results <- data.frame(metric = complete$metric, time = complete$time,
  complete = complete$estimate, marginal = marginal$estimate,
  conditional = conditional$estimate)
write.csv(conditional_results, "workflow_conditional.csv", row.names = FALSE)

# 8. Full-cohort SVM tuning: serial, PSOCK, and completed-search resume.
# Fresh, explicitly owned checkpoint directories keep earlier runs separate.
checkpoint_root <- tempfile("workflow-tuning-", tmpdir = "tmp")
dir.create(checkpoint_root, recursive = TRUE)
serial_path <- file.path(checkpoint_root, "serial")
parallel_path <- file.path(checkpoint_root, "parallel")
tuning_grid <- list(cost = c(.01, .1))
tuning_params <- list(kernel = "linear", solver = "clarabel")
cat("Full-cohort tuning: serial\n")
serial_seconds <- system.time(serial_search <- surv_tune(form, train, "svm",
  grid = tuning_grid, params = tuning_params, folds = 3, seed = 20261023,
  workers = 1L, checkpoint = serial_path, progress = TRUE))[["elapsed"]]
cat("Full-cohort tuning: two workers\n")
parallel_seconds <- system.time(parallel_search <- surv_tune(form, train, "svm",
  grid = tuning_grid, params = tuning_params, folds = 3, seed = 20261023,
  workers = 2L, checkpoint = parallel_path, progress = TRUE))[["elapsed"]]
resume_seconds <- system.time(resumed_search <- surv_tune(form, train, "svm",
  grid = tuning_grid, params = tuning_params, folds = 3, seed = 20261023,
  workers = 2L, checkpoint = parallel_path))[["elapsed"]]
fold_difference <- max(abs(serial_search$fold_results$estimate -
  parallel_search$fold_results$estimate))
prediction_difference <- max(abs(surv_predict(serial_search, test) -
  surv_predict(parallel_search, test)))
stopifnot(fold_difference < 1e-10, prediction_difference < 1e-8,
  identical(serial_search$best_candidate, parallel_search$best_candidate),
  resumed_search$execution$computed_jobs == 0L,
  resumed_search$execution$refit_reused)
tuning_results <- data.frame(run = c("Serial", "Two workers", "Completed resume"),
  seconds = c(serial_seconds, parallel_seconds, resume_seconds),
  computed = c(serial_search$execution$computed_jobs,
    parallel_search$execution$computed_jobs, resumed_search$execution$computed_jobs),
  reused = c(serial_search$execution$resumed_jobs,
    parallel_search$execution$resumed_jobs, resumed_search$execution$resumed_jobs),
  refit_reused = c(FALSE, FALSE, resumed_search$execution$refit_reused))
write.csv(tuning_results, "workflow_tuning.csv", row.names = FALSE)
write.csv(data.frame(fold_difference = fold_difference,
  prediction_difference = prediction_difference,
  best_candidate = parallel_search$best_candidate,
  train_n = nrow(train), test_n = nrow(test)),
  "workflow_tuning_equivalence.csv", row.names = FALSE)

# 9. Extension tables are generated from these public API calls.
workflow <- c("\\newcommand{\\ImportanceTable}{%",
  "\\begin{tabular}{lrrr}\\toprule",
  row(c("Predictor", "Cox", "RSF", "Neural Cox")), "\\midrule")
for (variable in rsf_imp$variable) {
  values <- importance[importance$variable == variable, ]
  values <- values[match(c("cox", "rsf", "neural_cox"), values$model), ]
  workflow <- c(workflow, row(c(gsub("_", "\\\\_", variable),
    sprintf("%.4f (%.4f)", values$importance, values$sd))))
}
workflow <- c(workflow, "\\bottomrule\\end{tabular}}",
  "\\newcommand{\\RemainingTable}{%", "\\begin{tabular}{lrrrr}\\toprule",
  row(c("Profile", "$F_a(60)$", "$F_a(150)$", "$\\mu_{a,150}$", "$q_{a,.01}$")),
  "\\midrule")
for (i in 1:3) {
  values <- remaining$summary[remaining$summary$observation == i, ]
  quantile <- remaining$quantiles$remaining_time[
    remaining$quantiles$observation == i & remaining$quantiles$probability == .01]
  workflow <- c(workflow, row(c(i, sprintf("%.4f", values$failure),
    sprintf("%.2f", values$restricted_remaining_mean[values$horizon == 150]),
    if (is.na(quantile)) "Not reached" else sprintf("%.1f", quantile))))
}
workflow <- c(workflow, "\\bottomrule\\end{tabular}}",
  "\\newcommand{\\ConditionalTable}{%", "\\begin{tabular}{lrrr}\\toprule",
  row(c("Criterion", "Complete outcomes", "Marginal $G$", "Conditional $G$")),
  "\\midrule")
metric_labels <- c(harrell = "Harrell $C$", ipcw_c = "Pair-weighted $C(15)$",
  auc = "AUC(10)", brier = "Brier(10)")
for (i in seq_len(nrow(conditional_results))) {
  values <- conditional_results[i, ]
  workflow <- c(workflow, row(c(metric_labels[values$metric],
    sprintf("%.4f", unlist(values[c("complete", "marginal", "conditional")])))))
}
workflow <- c(workflow, "\\bottomrule\\end{tabular}}",
  "\\newcommand{\\TuningExecutionTable}{%", "\\begin{tabular}{lrrrl}\\toprule",
  row(c("Run", "Seconds", "New fits", "Reused folds", "Refit reused")), "\\midrule")
for (i in seq_len(nrow(tuning_results))) {
  values <- tuning_results[i, ]
  workflow <- c(workflow, row(c(values$run, sprintf("%.2f", values$seconds),
    values$computed, values$reused, if (values$refit_reused) "Yes" else "No")))
}
workflow <- c(workflow, "\\bottomrule\\end{tabular}}",
  paste0("\\newcommand{\\ConditionalCensorPercent}{",
    sprintf("%.1f", 100 * mean(ct_train$event == 0)), "}"),
  paste0("\\newcommand{\\ParallelFoldDifference}{",
    sprintf("%.2g", fold_difference), "}"),
  paste0("\\newcommand{\\ParallelPredictionDifference}{",
    sprintf("%.2g", prediction_difference), "}"))
writeLines(workflow, "workflow_results.tex")

# 10. Probability assessment has a prespecified administrative-support target.
# Event models above still use every eligible training drive, without subsampling.
# For 180-day outcomes, restrict assessment/reference to entry by 2013-07-04;
# later entrants cannot have 180 days before the known end of the archive.
limit <- as.numeric(as.Date("2013-12-31")) - 180
prob_train <- train[train$first_date_num <= limit, ]
prob_test <- test[test$first_date_num <= limit, ]
prob_train$entry_band <- factor(floor(prob_train$entry_day / 30))
prob_test$entry_band <- factor(floor(prob_test$entry_day / 30),
  levels = levels(prob_train$entry_band))
prob_g <- surv_censor_fit(Surv(time_days, event) ~ entry_band,
  prob_train, method = "stratified")
prob_models <- real_models[c("aft", "cox", "cox_lasso", "cox_ridge", "cox_elasticnet",
  "rsf", "xgboost_cox", "xgboost_aft", "mtlr", "neural_cox")]
prob_results <- data.frame()
for (method in names(prob_models)) {
  value <- surv_evaluate(prob_models[[method]], prob_test,
    metrics = c("brier", "ibs"), times = seq(30, 180, by = 30), censoring_model = prob_g)
  prob_results <- rbind(prob_results, data.frame(model = method, as.data.frame(value)))
}
write.csv(prob_results, "probability_results.csv", row.names = FALSE)
calibration <- surv_calibrate(real_models$rsf, prob_test, times = c(90, 180),
  groups = 4, censoring_model = prob_g, n_boot = 200L, seed = 20261027)
write.csv(as.data.frame(calibration), "calibration_results.csv", row.names = FALSE)
write.csv(data.frame(reference_n = nrow(prob_train), assessment_n = nrow(prob_test),
  assessment_events = sum(prob_test$event), latest_entry = as.character(as.Date(limit, origin = "1970-01-01"))),
  "probability_target.csv", row.names = FALSE)
pdf("figure_calibration.pdf", width = 6.6, height = 3.6, useDingbats = FALSE)
par(mfrow = c(1, 2), mar = c(4.2, 4.2, 1.7, .8), las = 1)
cal_range <- range(c(calibration$predicted, calibration$observed,
  calibration$lower, calibration$upper), finite = TRUE)
cal_range <- range(c(max(0, cal_range[1] - .01), 1))
plot(calibration, time = 90, main = "90 days", xlim = cal_range, ylim = cal_range)
plot(calibration, time = 180, main = "180 days", xlim = cal_range, ylim = cal_range)
dev.off()
prob_table <- c("\\newcommand{\\ProbabilityTable}{%", "\\begin{tabular}{lrrr}\\toprule",
  row(c("Method", "Brier(90)", "Brier(180)", "IBS(30--180)")), "\\midrule")
for (method in names(prob_models)) {
  values <- prob_results[prob_results$model == method, ]
  b90 <- values$estimate[values$metric == "brier" & !is.na(values$time) & values$time == 90]
  b180 <- values$estimate[values$metric == "brier" & !is.na(values$time) & values$time == 180]
  ibs <- values$estimate[values$metric == "ibs"]
  label <- labels[method]
  prob_table <- c(prob_table, row(c(label, sprintf("%.5f", c(b90, b180, ibs)))))
}
prob_table <- c(prob_table, "\\bottomrule\\end{tabular}}",
  paste0("\\newcommand{\\ProbabilityAssessmentN}{", nrow(prob_test), "}"),
  paste0("\\newcommand{\\ProbabilityReferenceN}{", nrow(prob_train), "}"))
writeLines(prob_table, "probability_results.tex")

# 11. Native-engine agreement demonstrates the wrapper's calling convention.
native_cox <- coxph(form, train, ties = "efron", x = TRUE, y = TRUE)
agreement <- max(abs(surv_predict(real_models$cox, test) -
  as.numeric(predict(native_cox, test, type = "lp", reference = "zero"))))
stopifnot(agreement < 1e-10)
write.csv(data.frame(comparison = "Unified versus direct survival::coxph",
  maximum_risk_difference = agreement, training_n = nrow(train), assessment_n = nrow(test)),
  "native_interface_agreement.csv", row.names = FALSE)
writeLines(capture.output(summary(real_models$cox)), "example_model_summary.txt")
writeLines(capture.output(sessionInfo()), "sessionInfo.txt")
cat("Replication completed.\n")
