# Replication: survlearning 0.3.5

Use this folder as the R working directory. The supplied source archive and
the versions in replication-requirements.csv identify the numerical environment.

## Installation

~~~r
install.packages("remotes")
remotes::install_local("survlearning_0.3.5.tar.gz",
                      dependencies = NA, upgrade = "never")
install.packages(c("censored", "parsnip"))
~~~

The two additional packages support the matched interface comparison; they
are not modeling requirements for ordinary survlearning use. The integrated
engines do not require installing penAFT, randomForestSRC, flexsurv or
survivalsvm. The supplied engines.bib preserves their citations.
Source installation needs a
compiler toolchain appropriate to the installed R version. Torch and Python
are not used.

## Execution

From a terminal in this directory:

~~~text
Rscript --vanilla code.R
~~~

This entry point runs replication.R, extensions.R, comparison.R, verify_svm.R,
svm_learning.R and the fresh-process benchmarks. The predictive experiment
fits 25 covariate-based identifiers on the generated example and 20
configurations on all 23,246 eligible
Backblaze training drives. The same 5,812 test drives are kept out of tuning.
Each original regression SVM kernel has a separate seven-cost search with
the same folds. Ranking, hybrid and IPCW objectives each tune linear and
additive kernels separately. Their 112 candidates retain every training row
and use the same three folds; these searches use max_iter = 5000.

extensions.R fits a Cox--RSF survival stack using all training drives.
Three out-of-fold partitions provide predictions for learning the weights;
the RSF grid is tuned within each partition using three inner folds. The
script then computes paired concordance differences on the full test sample
and IPCW calibration intercepts and slopes on the same early-entry target
used for probability assessment. Bootstrap intervals resample test drives,
holding the event and censoring models fixed. Stacking uses established
convex weighting, not a new survival estimator or a guarantee of improvement.

The censored-SVR objective is solved by its exact sparse primal. Additive
ranges and knots are fixed in training. The default prediction resolution
is 1e-8 times maximum training follow-up; it prevents numerical near ties
from producing artificial concordance. Older conditioned-QP SVM objects
must be refitted. The additional objectives return risk scores only.
They are not alternative solvers for the original absolute-loss estimator.

Outputs include partition IDs, candidate-fold records, numerical diagnostics,
selected settings, fitted objects, tables, figures, probability assessment
and session information. The serial/parallel/resume example creates owned
checkpoint folders under tmp. Timing workers write benchmark_runs.

## Computational checks

verify_svm.R independently compares a dense dual with the sparse primal.
svm_learning.R checks selected settings, numerical tolerance, censoring
support and a paired ranking-additive versus RSF bootstrap comparison.
benchmark.ps1 starts three fresh Windows processes for each of eight SVM
configurations and two neural-Cox tie specifications. benchmark.R summary combines
their outputs. code.R orchestrates these steps automatically; on other
platforms it runs the workers and leaves process memory unmeasured.

The benchmark uses fixed costs for the original regression SVMs, frozen
training-CV choices for the additional objectives, and fixed neural training
budgets. No configuration is chosen from test outcomes. Fitting time excludes startup; process peak
memory includes libraries, data, fitting and prediction.

## Data and scope

The supplied baseline CSV is sufficient for the statistical analysis.
DATA.md describes reconstruction from the original annual Backblaze archive.
No script downloads data or installs packages automatically.

All distributed source files are flat. Working folders created during execution
contain intermediate results, not additional required source modules.
The numerical experiments were run with R 4.6.0 on Windows. Exact-version
external release checks are a separate requirement before publication.

The numerical examples and 30 fresh-process benchmark fits use the supplied
0.3.5 release. The entry script checks its checksum and refits every method
from the beginning. All data rows and the stated parameter grids are retained.
The complete run can take substantially longer than fitting the selected
models alone. Time and memory depend on the computer and the other work
running on it. Software versions and process status are saved with the
results; timings do not measure predictive performance.

The predictive tables report concordance and its conditional standard error.
The `seconds` column in the CSV files is operational elapsed time, which can
include other work or computer suspension; it is not used in those tables.
Reported time and memory instead come from the separate fresh-process
measurements. A process interrupted by the resource limit is not a completed fit.
