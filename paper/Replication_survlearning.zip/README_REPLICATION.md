# Replication: survlearning 0.3.4

Use this folder as the R working directory. The supplied source archive and
the versions in replication-requirements.csv identify the numerical environment.

## Installation

~~~r
install.packages("remotes")
remotes::install_local("survlearning_0.3.4.tar.gz",
                      dependencies = NA, upgrade = "never")
install.packages(c("penAFT", "randomForestSRC", "survivalsvm", "RSpectra",
                   "flexsurv", "censored", "parsnip"))
~~~

The additional packages above support external comparisons and reference
citations in the complete article workflow; they are not additional modeling
requirements for ordinary survlearning use. Source installation needs a
compiler toolchain appropriate to the installed R version. Torch and Python
are not used.

## Execution

From a terminal in this directory:

~~~text
Rscript --vanilla code.R
~~~

This entry point runs replication.R, comparison.R, verify_svm.R,
svm_learning.R and the fresh-process benchmarks. The predictive experiment
fits 25 covariate-based identifiers on the generated example and 20
configurations on all 23,246 eligible
Backblaze training drives. The same 5,812 test drives are kept out of tuning.
Each original regression SVM kernel has a separate seven-cost search with
the same folds. Ranking, hybrid and IPCW objectives each tune linear and
additive kernels separately. Their 112 candidates retain every training row
and use the same three folds; these searches use max_iter = 5000.

The censored-SVR objective is solved by its exact sparse primal. Additive
ranges and knots are fixed in training. The default prediction resolution
is 1e-8 times maximum training follow-up; it prevents numerical near ties
from producing artificial concordance. Older conditioned-QP SVM objects
must be refitted. The additional objectives return risk scores only.
They are not alternative solvers for the original absolute-loss estimator.

Outputs include partition IDs, candidate-fold records, numerical diagnostics,
selected settings, fitted objects, tables, figures, probability assessment
and session information. The serial/parallel/resume example creates owned
checkpoint folders under tmp. Timing workers write benchmark_runs.

## Computational checks

verify_svm.R independently compares a dense dual with the sparse primal.
svm_learning.R checks selected settings, numerical tolerance, censoring
support and a paired ranking-additive versus RSF bootstrap comparison.
benchmark.ps1 starts three fresh Windows processes for each of eight SVM
configurations and two neural-Cox tie specifications. benchmark.R summary combines
their outputs. code.R orchestrates these steps automatically; on other
platforms it runs the workers and leaves process memory unmeasured.

The benchmark uses fixed costs for the original regression SVMs, frozen
training-CV choices for the additional objectives, and fixed neural training
budgets. No configuration is chosen from test outcomes. Fitting time excludes startup; process peak
memory includes libraries, data, fitting and prediction.

## Data and scope

The supplied baseline CSV is sufficient for the statistical analysis.
DATA.md describes reconstruction from the original annual Backblaze archive.
No script downloads data or installs packages automatically.

All distributed source files are flat. Working folders created during execution
contain intermediate results, not additional required source modules.
The numerical experiments were run with R 4.6.0 on Windows. Exact-version
external release checks are a separate requirement before publication.

The recorded numerical experiment and all 30 fresh-process benchmark fits
used development snapshot 0.3.3.9001. The six full-cohort SVM settings were
refitted with the supplied 0.3.4 release, reproducing test concordance within
1e-12; tuning eligibility is unchanged. The release distinguishes an
independently accuracy-verified line-search exit from optimizer success,
without changing objectives or numerical tolerances. Benchmark CSV files
retain their original version labels. Previously verified fits for
unchanged methods were retained and re-evaluated on the original assessment
rows, with concordance agreement within 1e-12. The supplied code.R pipeline
refits all methods when run from the beginning; its full execution can take
substantially longer than the SVM searches alone.
