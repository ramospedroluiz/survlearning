# Run after replication.R, using its unchanged training and assessment samples.
# Weights and all base-model tuning use training observations only.
stopifnot(as.character(packageVersion("survlearning")) == "0.3.5")
stack_fit <- surv_stack(form, train, methods = c("cox", "rsf"),
  grids = list(rsf = grids$rsf), params = list(rsf = fixed$rsf),
  times = c(30, 90, 180), folds = 3, inner_folds = 3, seed = 20261104)
stopifnot(stack_fit$n == 23246L, all(vapply(stack_fit$models,
  function(x) x$n == 23246L, logical(1))))
saveRDS(stack_fit, "extension_stack_model.rds")
write.csv(data.frame(method = names(stack_fit$weights), weight = stack_fit$weights),
  "extension_weights.csv", row.names = FALSE)
write.csv(data.frame(n = stack_fit$n, events = stack_fit$events,
  oof_brier = stack_fit$diagnostics$loss, gap = stack_fit$diagnostics$gap_bound,
  seconds = stack_fit$fit_seconds), "extension_stack_summary.csv", row.names = FALSE)

models <- c(real_models[c("cox", "rsf", "svm_rank_additive", "svm_hybrid_additive")],
  list(stack = stack_fit))
paired <- surv_compare(models, test, reference = "cox", n_boot = 1000, seed = 20261104)
write.csv(paired, "extension_comparison.csv", row.names = FALSE)

# Keep the probability target already specified in the main analysis.
# Event models and the stack use all training drives. Administrative support
# limits probability assessment/reference to the existing early-entry target.
calibration_metrics <- do.call(rbind, lapply(c("cox", "stack"), function(name) {
  fit <- if (name == "stack") stack_fit else real_models[[name]]
  result <- surv_calibrate(fit, prob_test, times = 180, type = "metrics",
    censoring_model = prob_g, n_boot = 500, seed = 20261104)
  data.frame(model = name, result)
}))
write.csv(calibration_metrics, "extension_calibration.csv", row.names = FALSE)
probabilities <- do.call(rbind, lapply(c("cox", "rsf", "stack"), function(name) {
  fit <- if (name == "stack") stack_fit else real_models[[name]]
  result <- surv_evaluate(fit, prob_test, c("brier", "ibs"),
    times = seq(30, 180, by = 30), censoring_model = prob_g)
  data.frame(model = name, result)
}))
write.csv(probabilities, "extension_probability.csv", row.names = FALSE)

fmt <- function(x, digits = 3) ifelse(is.finite(x), sprintf(paste0("%.", digits, "f"), x), "NA")
interval <- function(lower, upper) paste0("[", fmt(lower), ", ", fmt(upper), "]")
names_table <- c(rsf = "RSF", svm_rank_additive = "Additive ranking SVM",
  svm_hybrid_additive = "Additive hybrid SVM", stack = "Cox--RSF stack")
comparison_rows <- paste(names_table[paired$model], fmt(paired$estimate),
  fmt(paired$difference), interval(paired$lower, paired$upper), sep = " & ")
calibration_rows <- vapply(c("cox", "stack"), function(name) {
  r <- calibration_metrics[calibration_metrics$model == name, ]
  b <- probabilities[probabilities$model == name & probabilities$metric == "brier" &
    !is.na(probabilities$time) & probabilities$time == 180, ]
  paste(if (name == "cox") "Cox" else "Cox--RSF stack",
    paste(fmt(r$estimate[1]), interval(r$lower[1], r$upper[1])),
    paste(fmt(r$estimate[2]), interval(r$lower[2], r$upper[2])),
    fmt(b$estimate, 5), sep = " & ")
}, character(1))
writeLines(c("\\newcommand{\\ExtensionComparisonTable}{%",
  "\\begin{tabular}{lrrr}\\toprule",
  "Model & Test $C$ & $\\Delta C$ vs. Cox & 95\\% interval \\\\", "\\midrule",
  paste0(comparison_rows, " \\\\"), "\\bottomrule\\end{tabular}}",
  "\\newcommand{\\ExtensionCalibrationTable}{%",
  "\\begin{tabular}{lrrr}\\toprule",
  "Model & Intercept [95\\% interval] & Slope [95\\% interval] & Brier(180) \\\\",
  "\\midrule", paste0(calibration_rows, " \\\\"), "\\bottomrule\\end{tabular}}",
  paste0("\\newcommand{\\StackCoxWeight}{", fmt(stack_fit$weights["cox"]), "}"),
  paste0("\\newcommand{\\StackRsfWeight}{", fmt(stack_fit$weights["rsf"]), "}"),
  paste0("\\newcommand{\\StackTrainingBrier}{", fmt(stack_fit$diagnostics$loss, 5), "}"),
  paste0("\\newcommand{\\StackTestC}{", fmt(paired$estimate[paired$model == "stack"]), "}")),
  "extension_results.tex")
writeLines(capture.output(sessionInfo()), "extension_sessionInfo.txt")
