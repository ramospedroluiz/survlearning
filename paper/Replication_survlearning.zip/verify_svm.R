# Independent dense dual versus the fitted sparse censored-regression primal.
library(survlearning)
stopifnot(as.character(packageVersion("survlearning"))=="0.3.5")
out <- data.frame()
for(seed in 1:12) for(kernel in c("linear","additive")) {
 set.seed(seed); n <- 24L
 x <- cbind(rnorm(n),rep(0:3,6),rep(0:1,12))
 if(seed==3) x[,1] <- x[,2]
 y <- cbind(runif(n,1,8),rbinom(n,1,if(seed%%2) .15 else .8))
 if(seed==12) y[,2] <- 1
 if(!any(y[,2]==1)) y[1,2] <- 1
 cost <- .7
 params <- survlearning:::.parameters("svm",
  list(kernel=kernel,cost=cost,prediction_tolerance=0),ncol(x))
 fit <- survlearning:::.svm_fit(x,y,params)
 k <- if(kernel=="linear") tcrossprod(x) else {
  result <- matrix(0,n,n)
  for(j in seq_len(ncol(x))) result <- result+1-abs(outer(x[,j],x[,j],`-`))/diff(range(x[,j]))
  result
 }
 a <- rbind(Matrix::Matrix(1,1,n,sparse=TRUE),-Matrix::Diagonal(n),Matrix::Diagonal(n))
 dual <- clarabel::clarabel(A=as(a,"CsparseMatrix"),
  b=c(0,cost*y[,2],rep(cost,n)),q=-y[,1],
  P=as(as(Matrix::Matrix(k,sparse=TRUE),"symmetricMatrix"),"CsparseMatrix"),
  cones=list(z=1L,l=as.integer(2*n)),control=clarabel::clarabel_control(verbose=FALSE,
   max_threads=1L,tol_gap_abs=1e-10,tol_gap_rel=1e-10,tol_feas=1e-10))
 predicted <- survlearning:::.svm_primal_predict(fit,x,raw=TRUE)
 reference <- as.vector(k%*%fit$dual)
 gap <- abs(fit$diagnostics$objective+dual$obj_val)/max(1,abs(dual$obj_val))
 error <- max(abs((predicted-mean(predicted))-(reference-mean(reference))))
 stopifnot(dual$status==2L,gap<1e-7,error<1e-6)
 out <- rbind(out,data.frame(seed,kernel,n,events=sum(y[,2]),relative_objective_difference=gap,
  centered_representer_error=error,primal_dual_gap=fit$diagnostics$relative_gap))
}
write.csv(out,"svm_verification.csv",row.names=FALSE)
print(aggregate(cbind(relative_objective_difference,centered_representer_error)~kernel,out,max))
