#' # survlearning: complete article replication
#'
#' Run `Rscript --vanilla code.R` from this folder after explicitly installing
#' the supplied package and the versions in replication-requirements.csv.
#' No packages are installed and no data are downloaded by this script.
#' For an executable HTML record, use `rmarkdown::render("code.R")`.
#' The named companion scripts are included in the same flat archive.
local({
  started <- Sys.time()
  previous <- options(width = 100, useFancyQuotes = FALSE)
  on.exit(options(previous), add = TRUE)
  computational <- c("survlearning", "withr", "survival", "penAFT", "glmnet",
    "rpart", "randomForestSRC", "gbm", "survivalsvm", "xgboost", "MTLR", "RSpectra",
    "clarabel", "flexsurv", "CoxBoost", "ranger", "aorsf", "nnet", "Matrix", "censored", "parsnip")
  available <- vapply(computational, requireNamespace, logical(1), quietly = TRUE)
  if (any(!available)) stop("Missing replication packages: ",
    paste(computational[!available], collapse = ", "), ". See README_REPLICATION.md.")
  if (isTRUE(getOption("knitr.in.progress"))) {
    stopifnot(requireNamespace("knitr", quietly = TRUE),
      requireNamespace("rmarkdown", quietly = TRUE), rmarkdown::pandoc_available())
  }
  stopifnot(as.character(utils::packageVersion("survlearning")) == "0.2.4")
  packages <- c(computational, "knitr", "rmarkdown")
  installed <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  manifest <- data.frame(package = packages, required = packages %in% computational,
    installed = installed, version = vapply(seq_along(packages), function(i) {
      if (installed[i]) as.character(utils::packageVersion(packages[i])) else NA_character_
    }, character(1)))
  artifact <- data.frame(package = "survlearning", version = "0.2.4",
    source_md5 = unname(tools::md5sum("survlearning_0.2.4.tar.gz")))
  stopifnot(!is.na(artifact$source_md5))
  utils::write.csv(artifact, "replication-artifact.csv", row.names = FALSE)
  print(artifact)
  source("replication.R", local = TRUE)
  source("comparison.R", local = TRUE)
  rscript <- file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
  status <- system2(rscript, c("--vanilla", "benchmark.R"))
  stopifnot(status == 0L)
  cat("\nHeld-out predictive results\n")
  print(read.csv("backblaze_results.csv"))
  cat("\nMatched framework comparison\n")
  print(read.csv("framework_comparison.csv"))
  cat("\nFixed-setting split sensitivity\n")
  print(read.csv("split_sensitivity.csv"))
  cat("\nFresh-process computational results\n")
  print(read.csv("benchmark_summary.csv"))
  utils::write.csv(manifest, "replication-requirements.csv", row.names = FALSE)
  utils::write.csv(data.frame(started_utc = format(started, tz = "UTC", usetz = TRUE),
    finished_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
    elapsed_seconds = as.numeric(difftime(Sys.time(), started, units = "secs"))),
    "replication-run.csv", row.names = FALSE)
  print(manifest)
  print(sessionInfo())
})
