# Computational protocol

Version: survlearning 0.2.4. Execute code.R for the complete sequence.
The supplied code computes the manuscript's numerical and computational results.
No Torch or Python runtime is required.

## Independent numerical fixtures

A deterministic 24-row fixture (seed 19) constructs the reference dense
conditioned SVM Hessian with Matrix::nearPD and checks compact reconstructions
for linear and additive kernels. Clarabel/Newton objectives and centered scores
are compared. Stated tolerances are executable assertions. This small numerical
fixture is not a subset used instead of the full application.

A 40-row tied-time fixture (seed 707), two inputs and four hidden units compares
the native neural loss to independently enumerated risk sets for Efron and
Breslow. Central differences with step 1e-5 check gradients including L2 penalty.
No grouped native loss is called by the independent reference calculation.
Output: benchmark_numerical_audit.csv.

## Full-training measurements

All 23,246 training drives and 5,812 test drives use the article's reconstructed
baseline and fixed split. Cases: linear Clarabel SVM, additive Newton SVM,
native neural Cox with Efron, native neural Cox with Breslow. Each uses three
fresh processes. The additive Clarabel comparison also uses three fresh
processes, for 15 processes in total. SVM cost is .1. Neural settings: 16 hidden tanh units,
100 full-batch Adam updates, learning rate .001, decay .0001, seeds 901/902/903.
No tuning or test-directed early stopping occurs here. The main predictive
table reports separately tuned configurations.

Windows 11 x64, R 4.6.0, default BLAS, Intel Core Ultra 7 155H, about 15.6 GiB
usable RAM. Fit seconds exclude process startup. Peak working set includes the
process, libraries, data, fitting and prediction; it is not object size or a
baseline-subtracted allocation. Private bytes are sampled every 100 ms by the
supplied PowerShell launcher. A 900-second or 3,500-MiB private-memory termination
is a failed/incomplete experiment, never a valid successful fitting time.
Do not run other computational jobs concurrently for the profiling step.
On non-Windows platforms, time is measured but process memory is NA.

benchmark_measurements.csv retains individual runs and status;
Newton's certified relative gap is exported from relative_duality_gap.
Other solvers retain NA for this specifically
defined certificate. Status, convergence basis and source/data/split MD5 values
are recorded for each worker; aggregation requires all 15 distinct case/repetition
keys and matching identities. Missing certificates are errors for Newton workers.
benchmark_summary.csv contains medians and largest process peaks.
benchmark_full_equivalence.csv compares the additive solvers on full training
and held-out scores. computational_results.tex is generated from these files.
The worker ledgers are created under benchmark_runs; all worker code is in
benchmark.R and all profiling code is in benchmark.ps1.

## Other measured workflows

The main predictive-table times in replication.R include search, winning refit, held-out prediction
and concordance. Its separate workflow experiments record interpretation and
remaining-duration summaries, a separate conditional-censoring example, and
serial/two-worker/completed-resume SVM searches. Those search times include
checkpoint I/O, worker startup, candidate fits and final refit. No claim of
worker-aggregate process memory is made. A completed resume is not a timed
partial-crash recovery; partial recovery is covered separately by tests.

These experiments establish only the stated fixture agreement and local resource
cost. They do not demonstrate universal scaling, predictive superiority, or
cross-platform performance.
