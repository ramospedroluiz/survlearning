# Computational protocol

The distributed source version is survlearning 0.3.4. Recorded resource
measurements used snapshot 0.3.3.9001; no timings are relabeled as new runs.
The six full-cohort SVM settings were independently refitted with 0.3.4 and
reproduce the recorded test C-indices within 1e-12. Predictive selection and resource
measurements have separate roles.

The generated example uses 360 training and 1,200 test observations.
The Backblaze analysis retains the original 29,058 eligible drives:
23,246 training and 5,812 test. Eligibility, entry-day covariates, outcomes
and partition IDs are unchanged. Neither SVM kernel uses a training subset.

Each original regression kernel tunes cost over 10^(-3:3) with the same three training folds.
The default numerical prediction resolution is fixed in training, before
assessment. These original models minimize censored absolute loss, not a ranking loss.

The additional svm_rank, svm_hybrid and svm_ipcw objectives tune lambda over
10^(-5:1), separately for linear and additive kernels. Hybrid also searches
rank_weight in 0.25, 0.5 and 0.75; IPCW searches horizons 90 and 180 days and
epsilon 0 and 0.02. All 112 candidate configurations use the same three
folds, with max_iter = 5000. Censoring weights and feature maps are learned
within each training fold. These methods return risk scores, not curves.
svm_learning.R checks numerical tolerance and censoring support, and reports
a paired bootstrap comparison conditional on the fitted models.

The dense-dual verification in verify_svm.R has twelve 24-row fixtures per
kernel. These fixtures check mathematics and do not replace the application.
Relative objective differences must be below 1e-7 and centered representer
differences below 1e-6. The package test suite additionally compares solvers,
cache/resume behavior, duplicates, rare levels, time units and numerical ties.

Fresh-process measurements use three repetitions for each of ten configurations:
the original linear and additive SVMs, both kernels for each of the three
additional objectives, and neural Cox with Efron and Breslow ties. The original
SVMs use cost 0.1 and Clarabel. Additional SVM settings are frozen from training
CV in svm_learning_settings.rds. Neural configurations use
16 hidden units, 100 epochs, learning rate 0.001, decay 0.0001 and seeds
901, 902 and 903. Every fit uses the full training sample.

The Windows launcher samples private bytes every 100 milliseconds and reads
the process peak working set. A run exceeding 900 seconds or 3,500 MiB
private bytes is marked unsuccessful. Reported fitting seconds exclude
startup; process memory includes libraries, data, fitting and prediction.
Median and maximum peaks are empirical process measurements, not workspace
estimates or fitted-object sizes. Other platforms leave memory unavailable.

The measurements describe one machine and one design. They do not establish
a universal speedup, statistical superiority, or equivalence to the former
conditioned quadratic program. Solver certificates and predictive concordance
are reported separately.
