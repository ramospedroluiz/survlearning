param([Parameter(Mandatory=$true)][string]$Rscript, [int]$TimeoutSeconds=900)
$ErrorActionPreference = 'Stop'
[Threading.Thread]::CurrentThread.CurrentCulture = [Globalization.CultureInfo]::InvariantCulture
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath $Rscript -PathType Leaf)) { throw 'Rscript was not found.' }
$output = Join-Path $PSScriptRoot 'benchmark_runs'
New-Item -ItemType Directory -Path $output -Force | Out-Null
foreach ($case in @('svm_linear','svm_additive','neural_efron','neural_breslow','svm_rank_linear','svm_rank_additive','svm_hybrid_linear','svm_hybrid_additive','svm_ipcw_linear','svm_ipcw_additive')) {
    $count = 3
    foreach ($i in 1..$count) {
        $prefix = Join-Path $output ($case + '_' + $i)
        $script = '"' + (Join-Path $PSScriptRoot 'benchmark.R') + '"'
        $timer = [Diagnostics.Stopwatch]::StartNew()
        $p = Start-Process -FilePath $Rscript -ArgumentList @('--vanilla',$script,'worker',$case,$i) -WindowStyle Hidden -PassThru -RedirectStandardOutput ($prefix + '.stdout.txt') -RedirectStandardError ($prefix + '.stderr.txt')
        # Retain the native handle so Windows PowerShell can read ExitCode after exit.
        $null = $p.Handle
        $peakRss = 0L
        $peakPrivate = 0L
        $reason = ''
        while (-not $p.HasExited) {
            $p.Refresh()
            $peakRss = [Math]::Max($peakRss,$p.PeakWorkingSet64)
            $peakPrivate = [Math]::Max($peakPrivate,$p.PrivateMemorySize64)
            if ($peakPrivate -gt 3500MB -or $timer.Elapsed.TotalSeconds -gt $TimeoutSeconds) {
                $reason = if ($peakPrivate -gt 3500MB) { 'memory_limit' } else { 'timeout' }
                Stop-Process -Id $p.Id -Force
                break
            }
            Start-Sleep -Milliseconds 100
        }
        $p.WaitForExit()
        $timer.Stop()
        [pscustomobject]@{case=$case;repetition=$i;wall_seconds=$timer.Elapsed.TotalSeconds;peak_working_set_mib=$peakRss/1MB;sampled_peak_private_mib=$peakPrivate/1MB;exit_code=$p.ExitCode;termination=$reason} | Export-Csv -LiteralPath ($prefix + '.memory.csv') -NoTypeInformation
        if ($p.ExitCode -ne 0 -or $reason) { throw "Unsuccessful benchmark: $case repetition $i. Inspect its stderr file." }
        Write-Output ($case + ' repetition ' + $i + ': ' + [Math]::Round($timer.Elapsed.TotalSeconds,2) + ' s wall time; process peak ' + [Math]::Round($peakRss/1MB,1) + ' MiB')
    }
}
