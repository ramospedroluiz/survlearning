# Matched survival/censored workflows and a small fixed-setting split sensitivity.
# Run from this folder after replication.R. censored is a replication-only
# comparator: it is not an Import or Suggest of survlearning.
library(survlearning)
library(survival)
stopifnot(requireNamespace("censored", quietly = TRUE),
  requireNamespace("parsnip", quietly = TRUE))
d <- read.csv("backblaze_2013_baseline.csv", stringsAsFactors = FALSE)
d <- d[d$eligible, ]
d$manufacturer <- factor(d$manufacturer)
d$capacity_group <- factor(d$capacity_group, levels = c("1 TB", "2 TB", "3 TB", "4 TB"))
d$log_power_hours <- log1p(d$smart_9_first)
d$temperature <- d$smart_194_first
d$log_reallocated <- log1p(d$smart_5_first)
d$pending <- as.integer(d$smart_197_first > 0)
d$entry_day <- d$first_date_num - min(d$first_date_num)
split <- read.csv("split.csv", stringsAsFactors = FALSE)
stopifnot(identical(d$serial_number, split$serial_number))
train <- d[split$sample == "training", ]
test <- d[split$sample == "test", ]
form <- Surv(time_days, event) ~ manufacturer + capacity_group + log_power_hours +
  temperature + log_reallocated + pending + entry_day
plan <- surv_resamples(form, train, folds = 3, seed = 20261023)
horizons <- c(30, 90, 180)
comparison <- folds <- data.frame()
warnings_seen <- character()
for (method in c("cox", "aft")) {
  specification <- if (method == "cox") {
    parsnip::set_engine(parsnip::proportional_hazards(), "survival", ties = "efron")
  } else parsnip::set_engine(parsnip::survival_reg(dist = "weibull"), "survival")
  for (i in 0:length(plan$splits)) {
    analysis <- if (i == 0L) train else train[plan$splits[[i]]$analysis, ]
    assessment <- if (i == 0L) test else train[plan$splits[[i]]$assessment, ]
    ours <- withCallingHandlers(surv_fit(form, analysis, method, seed = 20261023),
      warning = function(w) warnings_seen <<- c(warnings_seen, conditionMessage(w)))
    other <- withCallingHandlers(parsnip::fit(specification, form, data = analysis),
      warning = function(w) warnings_seen <<- c(warnings_seen, conditionMessage(w)))
    risk <- surv_predict(ours, assessment)
    # censored 0.3.5 orients linear_pred toward longer survival for BOTH models.
    other_risk <- -as.numeric(predict(other, assessment, type = "linear_pred")$.pred_linear_pred)
    centered <- max(abs((risk - mean(risk)) - (other_risk - mean(other_risk))))
    c_ours <- surv_score(ours, assessment)
    c_other <- unname(concordance(Surv(time_days, event) ~ other_risk,
      data = assessment, reverse = TRUE)$concordance)
    stopifnot(centered < 1e-8, abs(c_ours - c_other) < 1e-10)
    if (i == 0L) {
      probability <- surv_predict(ours, assessment, "survival", horizons)
      nested <- predict(other, assessment, type = "survival", eval_time = horizons)$.pred
      other_probability <- t(vapply(nested, function(x) x$.pred_survival, numeric(length(horizons))))
      difference <- max(abs(probability - other_probability))
      stopifnot(difference < 1e-8)
      comparison <- rbind(comparison, data.frame(method = method, training_n = nrow(analysis),
        assessment_n = nrow(assessment), centered_risk_difference = centered,
        survival_difference = difference, c_survlearning = c_ours, c_censored = c_other))
    } else folds <- rbind(folds, data.frame(method = method, fold = i,
      centered_risk_difference = centered, c_survlearning = c_ours, c_censored = c_other))
  }
}
write.csv(comparison, "framework_comparison.csv", row.names = FALSE)
write.csv(folds, "framework_comparison_folds.csv", row.names = FALSE)
writeLines(unique(warnings_seen), "framework_comparison_warnings.txt")

# Three independent stratified 80/20 splits, no tuning in this sensitivity.
# Fixed defaults are specified before fitting; all eligible rows contribute
# to training or assessment in each split. These are dependent historical
# splits, not independent repetitions or prospective validation.
sensitivity <- data.frame()
for (seed in c(20261022L, 20261028L, 20261029L)) {
  set.seed(seed)
  index <- unlist(lapply(c(0, 1), function(event) {
    rows <- which(d$event == event)
    sample(rows, floor(.8 * length(rows)))
  }), use.names = FALSE)
  for (method in c("cox", "rsf", "neural_cox")) {
    params <- switch(method, cox = list(), rsf = list(trees = 200L, min_node = 15L,
      mtry = 3L, threads = 1L), neural_cox = list(hidden = 16L, epochs = 100L))
    fit <- surv_fit(form, d[index, ], method, params, seed = 20261023)
    sensitivity <- rbind(sensitivity, data.frame(seed = seed, method = method,
      training_n = length(index), assessment_n = nrow(d) - length(index),
      assessment_events = sum(d$event[-index]), cindex = surv_score(fit, d[-index, ])))
  }
}
write.csv(sensitivity, "split_sensitivity.csv", row.names = FALSE)
row <- function(x) paste0(paste(x, collapse = " & "), " \\\\")
table <- c("\\newcommand{\\FrameworkTable}{%", "\\begin{tabular}{lrrrr}\\toprule",
  row(c("Model", "Centered score", "Survival", "$C$ (ours)", "$C$ (censored)")), "\\midrule")
for (i in seq_len(nrow(comparison))) {
  z <- comparison[i, ]
  table <- c(table, row(c(if (z$method == "cox") "Cox, Efron" else "Weibull AFT",
    sprintf("%.2g", z$centered_risk_difference), sprintf("%.2g", z$survival_difference),
    sprintf("%.4f", z$c_survlearning), sprintf("%.4f", z$c_censored))))
}
table <- c(table, "\\bottomrule\\end{tabular}}", "\\newcommand{\\SplitSensitivityTable}{%",
  "\\begin{tabular}{lrrr}\\toprule", row(c("Fixed configuration", "Minimum $C$", "Median $C$", "Maximum $C$")), "\\midrule")
for (method in c("cox", "rsf", "neural_cox")) {
  z <- sensitivity$cindex[sensitivity$method == method]
  table <- c(table, row(c(c(cox = "Cox", rsf = "RSF", neural_cox = "Native neural Cox")[method],
    sprintf("%.4f", c(min(z), median(z), max(z))))))
}
writeLines(c(table, "\\bottomrule\\end{tabular}}"), "comparison_results.tex")
writeLines(capture.output(sessionInfo()), "comparison_sessionInfo.txt")
cat("Matched framework and fixed-setting split comparisons completed.\n")
