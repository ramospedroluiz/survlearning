# Reproduce the manuscript's numerical audits and fresh-process benchmarks.
# Run replication.R first, then run this file from the same folder.
# Windows: benchmark.ps1 samples process memory; other systems report time only.
# No Python, Torch, or additional R package is needed beyond the stated engines.
# Rscript benchmark.R tables only re-aggregates an already complete worker ledger.

library(survlearning)
library(survival)
stopifnot(as.character(packageVersion("survlearning")) == "0.2.4")
options(width = 75, useFancyQuotes = FALSE)
args <- commandArgs(trailingOnly = TRUE)
dir.create("benchmark_runs", showWarnings = FALSE)

if (length(args) && args[1] == "worker") {
  case <- args[2]
  repetition <- as.integer(args[3])
  d <- read.csv("backblaze_2013_baseline.csv", stringsAsFactors = FALSE)
  d <- d[d$eligible, ]
  split <- read.csv("split.csv", stringsAsFactors = FALSE)
  stopifnot(identical(d$serial_number, split$serial_number))
  d$manufacturer <- factor(d$manufacturer)
  d$capacity_group <- factor(d$capacity_group, levels = c("1 TB", "2 TB", "3 TB", "4 TB"))
  d$log_power_hours <- log1p(d$smart_9_first)
  d$temperature <- d$smart_194_first
  d$log_reallocated <- log1p(d$smart_5_first)
  d$pending <- as.integer(d$smart_197_first > 0)
  d$entry_day <- d$first_date_num - min(d$first_date_num)
  train <- d[split$sample == "training", ]
  test <- d[split$sample == "test", ]
  f <- Surv(time_days, event) ~ manufacturer + capacity_group + log_power_hours +
    temperature + log_reallocated + pending + entry_day
  if (startsWith(case, "svm")) {
    method <- "svm"
    params <- list(kernel = if (case == "svm_linear") "linear" else "additive",
      solver = if (case == "svm_additive") "newton" else "clarabel", cost = .1)
  } else {
    method <- "neural_cox"
    params <- list(hidden = 16L, epochs = 100L, learning_rate = .001,
      decay = .0001, ties = if (case == "neural_efron") "efron" else "breslow")
  }
  elapsed <- system.time(fit <- surv_fit(f, train, method, params,
    seed = 900L + repetition))[["elapsed"]]
  risk <- surv_predict(fit, test)
  diagnostics <- fit$engine$diagnostics
  gap <- diagnostics[["relative_duality_gap", exact = TRUE]]
  if (identical(params$solver, "newton")) {
    stopifnot(length(gap) == 1L, is.finite(gap), gap <= fit$params$tolerance,
      identical(diagnostics[["convergence_basis", exact = TRUE]], "primal_dual_certificate"))
  }
  write.csv(data.frame(case = case, repetition = repetition,
    train_n = nrow(train), train_events = sum(train$event), test_n = nrow(test),
    seconds = elapsed, cindex = surv_score(fit, test),
    objective = diagnostics$objective,
    violation = if (is.null(diagnostics$constraint_violation)) NA_real_ else diagnostics$constraint_violation,
    relative_gap = if (is.null(gap)) NA_real_ else gap,
    solver = if (method == "svm") params$solver else "Adam",
    convergence_basis = if (is.null(diagnostics[["convergence_basis", exact = TRUE]]))
      "solver_reported_status" else diagnostics[["convergence_basis", exact = TRUE]],
    status = if (method == "svm") diagnostics[["status", exact = TRUE]] else "fixed_epoch_budget",
    package_version = as.character(packageVersion("survlearning")),
    source_md5 = unname(tools::md5sum("survlearning_0.2.4.tar.gz")),
    baseline_md5 = unname(tools::md5sum("backblaze_2013_baseline.csv")),
    split_md5 = unname(tools::md5sum("split.csv"))),
    file.path("benchmark_runs", paste0(case, "_", repetition, ".fit.csv")), row.names = FALSE)
  write.csv(data.frame(risk = risk),
    file.path("benchmark_runs", paste0(case, "_", repetition, ".prediction.csv")), row.names = FALSE)
  writeLines(capture.output(sessionInfo()),
    file.path("benchmark_runs", paste0(case, "_", repetition, ".session.txt")))
  quit(save = "no", status = 0)
}

# 1. Small independent QP audits use deterministic fixtures, not an application subset.
internal <- function(name) getFromNamespace(name, "survlearning")
audits <- data.frame()
set.seed(19)
fixture <- data.frame(time = runif(24, 1, 4), event = rep(c(0, 1), 12),
  x = rnorm(24), z = rnorm(24))
f <- Surv(time, event) ~ x + z
for (kernel in c("linear", "additive")) {
  a <- surv_fit(f, fixture, "svm", list(kernel = kernel, solver = "clarabel", tolerance = 1e-10))
  b <- surv_fit(f, fixture, "svm", list(kernel = kernel, solver = "newton", tolerance = 1e-8))
  design <- internal(".prepare_design")(f, fixture)
  x <- internal(".scaled_design")(design$x, design$design)
  delta <- fixture$event
  k <- internal(".svm_kernel")(x, kernel)
  raw <- rbind(cbind(k, -delta * k), cbind(-delta * k, k))
  dense <- as.matrix(Matrix::nearPD(raw)$mat)
  compact <- if (kernel == "linear") internal(".svm_linear_hessian")(x, delta) else
    internal(".svm_additive_hessian")(x, delta, a$params)
  actual <- tcrossprod(compact$factor) + diag(compact$diagonal)
  pa <- surv_predict(a, fixture)
  pb <- surv_predict(b, fixture)
  audits <- rbind(audits, data.frame(audit = paste(kernel, "dense/compact Hessian"),
    difference = max(abs(dense - actual)), tolerance = 1e-9),
    data.frame(audit = paste(kernel, "Clarabel/Newton objective"),
      difference = abs(a$engine$diagnostics$objective - b$engine$diagnostics$objective), tolerance = 1e-5),
    data.frame(audit = paste(kernel, "centered score"),
      difference = max(abs((pa - mean(pa)) - (pb - mean(pb)))), tolerance = 1e-3))
}

# 2. Independent direct risk-set likelihood, without native grouped sums.
set.seed(707)
x <- matrix(rnorm(80), 40, 2)
y <- cbind(time = sample(1:8, 40, TRUE), event = rep(c(1, 1, 0, 0), 10))
theta <- internal(".neural_cox_initial")(2, 4)
direct <- function(parameters, ties) {
  w <- matrix(parameters[1:8], 2, 4)
  h <- tanh(sweep(x %*% w, 2, parameters[9:12], "+"))
  lp <- as.vector(h %*% parameters[13:16] + parameters[17])
  loss <- 0
  for (time in sort(unique(y[y[, 2] == 1, 1]))) {
    deaths <- which(y[, 1] == time & y[, 2] == 1)
    risk <- which(y[, 1] >= time)
    top <- max(lp[risk])
    denominator <- sum(exp(lp[risk] - top))
    event_mass <- sum(exp(lp[deaths] - top))
    fractions <- if (ties == "efron") (seq_along(deaths) - 1) / length(deaths) else rep(0, length(deaths))
    loss <- loss - sum(lp[deaths] - top) + sum(log(denominator - fractions * event_mass))
  }
  loss / sum(y[, 2]) + .0001 * sum(parameters^2) / 2
}
for (ties in c("efron", "breslow")) {
  groups <- internal(".neural_cox_groups")(y, ties)
  analytic <- internal(".neural_cox_objective")(theta, x, groups, 4, .0001)
  numeric_gradient <- numeric(length(theta))
  for (j in seq_along(theta)) {
    hi <- lo <- theta
    hi[j] <- hi[j] + 1e-5
    lo[j] <- lo[j] - 1e-5
    numeric_gradient[j] <- (direct(hi, ties) - direct(lo, ties)) / 2e-5
  }
  audits <- rbind(audits, data.frame(audit = paste(ties, "direct neural loss"),
    difference = abs(analytic$value - direct(theta, ties)), tolerance = 1e-10),
    data.frame(audit = paste(ties, "finite-difference gradient"),
      difference = max(abs(analytic$gradient - numeric_gradient)), tolerance = 1e-7))
}
stopifnot(all(audits$difference < audits$tolerance))
write.csv(audits, "benchmark_numerical_audit.csv", row.names = FALSE)

# 3. Fresh-process fitting. Do not run other computational jobs concurrently.
rscript <- file.path(R.home("bin"), "Rscript")
if (!"tables" %in% args && .Platform$OS.type == "windows") {
  rscript <- file.path(R.home("bin"), "Rscript.exe")
  candidate <- file.path(R.home(), "bin", "x64", "Rscript.exe")
  if (file.exists(candidate)) rscript <- candidate
  status <- system2("powershell.exe", c("-NoProfile", "-ExecutionPolicy", "Bypass",
    "-File", shQuote(normalizePath("benchmark.ps1")), "-Rscript", shQuote(rscript)))
  stopifnot(status == 0L)
} else if (!"tables" %in% args) {
  for (case in c("svm_linear", "svm_additive", "neural_efron", "neural_breslow", "svm_additive_clarabel")) {
    for (repetition in seq_len(3L)) {
      status <- system2(rscript, c("--vanilla", "benchmark.R", "worker", case, repetition))
      stopifnot(status == 0L)
      write.csv(data.frame(case = case, repetition = repetition,
        peak_working_set_mib = NA_real_, sampled_peak_private_mib = NA_real_,
        exit_code = status, termination = "not_profiled_on_this_platform"),
        file.path("benchmark_runs", paste0(case, "_", repetition, ".memory.csv")), row.names = FALSE)
    }
  }
}
fits <- do.call(rbind, lapply(list.files("benchmark_runs", "fit.csv$", full.names = TRUE), read.csv))
memory <- do.call(rbind, lapply(list.files("benchmark_runs", "memory.csv$", full.names = TRUE), read.csv))
expected <- expand.grid(case = c("svm_linear", "svm_additive", "neural_efron",
  "neural_breslow", "svm_additive_clarabel"), repetition = 1:3)
keys <- function(x) paste(x$case, x$repetition, sep = ":")
stopifnot(nrow(fits) == 15L, nrow(memory) == 15L,
  !anyDuplicated(keys(fits)), !anyDuplicated(keys(memory)),
  setequal(keys(fits), keys(expected)), setequal(keys(memory), keys(expected)),
  all(memory$exit_code == 0L), all(fits$train_n == 23246L),
  all(fits$train_events == 574L), all(fits$test_n == 5812L),
  all(fits$package_version == "0.2.4"),
  all(fits$source_md5 == unname(tools::md5sum("survlearning_0.2.4.tar.gz"))),
  all(fits$baseline_md5 == unname(tools::md5sum("backblaze_2013_baseline.csv"))),
  all(fits$split_md5 == unname(tools::md5sum("split.csv"))))
newton <- fits[fits$solver == "newton", ]
stopifnot(nrow(newton) == 3L, all(is.finite(newton$relative_gap)),
  all(newton$convergence_basis == "primal_dual_certificate"),
  all(newton$status == "reported_success"))
measurements <- merge(fits, memory, by = c("case", "repetition"))
write.csv(measurements, "benchmark_measurements.csv", row.names = FALSE)
metrics <- c("seconds", "peak_working_set_mib", "cindex")
results <- aggregate(measurements[metrics], list(case = measurements$case),
  function(v) if (all(is.na(v))) NA_real_ else median(v, na.rm = TRUE))
results$repetitions <- as.integer(table(measurements$case)[results$case])
results$max_mib <- vapply(results$case, function(k) {
  z <- measurements$peak_working_set_mib[measurements$case == k]
  if (all(is.na(z))) NA_real_ else max(z, na.rm = TRUE)
}, numeric(1))
write.csv(results, "benchmark_summary.csv", row.names = FALSE)
pa <- read.csv("benchmark_runs/svm_additive_1.prediction.csv")$risk
pb <- read.csv("benchmark_runs/svm_additive_clarabel_1.prediction.csv")$risk
aa <- fits[fits$case == "svm_additive" & fits$repetition == 1, ]
bb <- fits[fits$case == "svm_additive_clarabel" & fits$repetition == 1, ]
equivalence <- data.frame(objective_difference = abs(aa$objective - bb$objective),
  centered_score_difference = max(abs((pa - mean(pa)) - (pb - mean(pb)))),
  cindex_difference = abs(aa$cindex - bb$cindex), training_n = aa$train_n)
stopifnot(equivalence$objective_difference < 1e-4,
  equivalence$centered_score_difference < 1e-4, equivalence$cindex_difference < 1e-7)
write.csv(equivalence, "benchmark_full_equivalence.csv", row.names = FALSE)

# 4. Generate the article tables from the measured files, not typed constants.
row <- function(v) paste0(paste(v, collapse = " & "), " \\\\")
scientific <- function(value) {
  if (value == 0) return("$0$")
  exponent <- floor(log10(abs(value)))
  sprintf("$%.2f\\times10^{%d}$", value / 10^exponent, exponent)
}
table <- c("\\newcommand{\\NumericalAuditTable}{%", "\\begin{tabular}{lrr}\\toprule",
  row(c("Audit", "Maximum difference", "Tolerance")), "\\midrule")
for (i in seq_len(nrow(audits))) table <- c(table,
  row(c(audits$audit[i], scientific(audits$difference[i]), scientific(audits$tolerance[i]))))
table <- c(table, "\\bottomrule\\end{tabular}}", "\\newcommand{\\ComputationalTable}{%",
  "\\begin{tabular}{lrrrrr}\\toprule", row(c("Configuration", "$R$", "Seconds", "MiB", "Max MiB", "Test $C$")), "\\midrule")
labels <- c(svm_linear = "Linear SVM, Clarabel", svm_additive = "Additive SVM, Newton",
  svm_additive_clarabel = "Additive SVM, Clarabel", neural_efron = "Neural Cox, Efron", neural_breslow = "Neural Cox, Breslow")
for (i in seq_len(nrow(results))) {
  z <- results[i, ]
  table <- c(table, row(c(labels[z$case], z$repetitions, sprintf("%.2f", z$seconds),
    if (is.na(z$peak_working_set_mib)) "Not measured" else sprintf("%.1f", z$peak_working_set_mib),
    if (is.na(z$max_mib)) "Not measured" else sprintf("%.1f", z$max_mib), sprintf("%.4f", z$cindex))))
}
table <- c(table, "\\bottomrule\\end{tabular}}",
  paste0("\\newcommand{\\AdditiveObjectiveDifference}{", scientific(equivalence$objective_difference), "}"),
  paste0("\\newcommand{\\AdditiveScoreDifference}{", scientific(equivalence$centered_score_difference), "}"),
  paste0("\\newcommand{\\NewtonMaxRelativeGap}{", scientific(max(newton$relative_gap)), "}"))
writeLines(table, "computational_results.tex")
writeLines(capture.output(sessionInfo()), "benchmark_sessionInfo.txt")
cat("Numerical audits and all fresh-process fits completed.\n")
