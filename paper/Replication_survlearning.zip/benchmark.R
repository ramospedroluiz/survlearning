# Run benchmark.ps1 for three fresh processes per configuration, then:
# Rscript --vanilla benchmark.R summary
library(survlearning)
library(survival)
stopifnot(as.character(packageVersion("survlearning")) == "0.3.5")
args <- commandArgs(TRUE)
mode <- if(length(args)) args[1] else "summary"
dir.create("benchmark_runs",showWarnings=FALSE)
if(mode == "worker") {
  case <- args[2]; repetition <- as.integer(args[3])
  cohort <- read.csv("backblaze_2013_baseline.csv",stringsAsFactors=FALSE)
  drives <- cohort[cohort$eligible,]
  drives$manufacturer <- factor(drives$manufacturer)
  drives$capacity_group <- factor(drives$capacity_group,levels=c("1 TB","2 TB","3 TB","4 TB"))
  drives$log_power_hours <- log1p(drives$smart_9_first)
  drives$temperature <- drives$smart_194_first
  drives$log_reallocated <- log1p(drives$smart_5_first)
  drives$pending <- as.integer(drives$smart_197_first>0)
  drives$entry_day <- drives$first_date_num-min(drives$first_date_num)
  split <- read.csv("split.csv",stringsAsFactors=FALSE)
  stopifnot(identical(drives$serial_number,split$serial_number))
  train <- drives[split$sample=="training",]; test <- drives[split$sample=="test",]
  stopifnot(nrow(train)==23246L,nrow(test)==5812L)
  f <- Surv(time_days,event)~manufacturer+capacity_group+log_power_hours+
    temperature+log_reallocated+pending+entry_day
  if(grepl("^svm_(rank|hybrid|ipcw)_", case)) {
    method <- sub("_(linear|additive)$", "", case)
    params <- readRDS("svm_learning_settings.rds")[[case]]
    stopifnot(is.list(params), length(params) > 0L)
  } else if(startsWith(case,"svm")) {
    method <- "svm"
    params <- list(kernel=sub("svm_","",case),cost=.1)
  } else {
    method <- "neural_cox"
    params <- list(hidden=16L,epochs=100L,learning_rate=.001,decay=.0001,
      ties=sub("neural_","",case),threads=1L)
  }
  t0 <- proc.time()[["elapsed"]]
  fit <- surv_fit(f,train,method,params=params,seed=900L+repetition)
  fit_seconds <- proc.time()[["elapsed"]]-t0
  t0 <- proc.time()[["elapsed"]]
  risk <- surv_predict(fit,test)
  predict_seconds <- proc.time()[["elapsed"]]-t0
  cc <- concordance(Surv(time_days,event)~risk,test,reverse=TRUE)$concordance
  gap <- if(method=="svm") fit$engine$diagnostics$relative_gap else NA_real_
  stopifnot(all(is.finite(risk)),fit$n==23246L)
  write.csv(data.frame(case,repetition,fit_seconds,predict_seconds,test_C=cc,
    relative_gap=gap,train_n=fit$n,test_n=nrow(test),version=as.character(packageVersion("survlearning"))),
    file.path("benchmark_runs",paste0(case,"_",repetition,".result.csv")),row.names=FALSE)
} else {
  cases <- c("svm_linear","svm_additive","neural_efron","neural_breslow",
    "svm_rank_linear","svm_rank_additive","svm_hybrid_linear","svm_hybrid_additive",
    "svm_ipcw_linear","svm_ipcw_additive")
  rows <- data.frame()
  for(case in cases) for(repetition in 1:3) {
    stem <- file.path("benchmark_runs",paste0(case,"_",repetition))
    r <- read.csv(paste0(stem,".result.csv"))
    m <- read.csv(paste0(stem,".memory.csv"))
    stopifnot(r$version=="0.3.5",m$exit_code==0,is.na(m$termination)||!nzchar(m$termination))
    rows <- rbind(rows,cbind(r,wall_seconds=m$wall_seconds,
      peak_mib=m$peak_working_set_mib))
  }
  write.csv(rows,"benchmark_measurements.csv",row.names=FALSE)
  summary <- do.call(rbind,lapply(cases,function(case) {
    z <- rows[rows$case==case,]
    data.frame(case,repetitions=nrow(z),seconds=median(z$fit_seconds),
      predict_seconds=median(z$predict_seconds),peak_mib=median(z$peak_mib),
      max_mib=max(z$peak_mib),test_C=median(z$test_C))
  }))
  write.csv(summary,"benchmark_summary.csv",row.names=FALSE)
  labels <- c(svm_linear="Linear SVM, Clarabel",svm_additive="Additive SVM, Clarabel",
    neural_efron="Neural Cox, Efron",neural_breslow="Neural Cox, Breslow",
    svm_rank_linear="Ranking SVM, linear",svm_rank_additive="Ranking SVM, additive",
    svm_hybrid_linear="Hybrid SVM, linear",svm_hybrid_additive="Hybrid SVM, additive",
    svm_ipcw_linear="IPCW SVR, linear",svm_ipcw_additive="IPCW SVR, additive")
  tab <- c("\\newcommand{\\ComputationalTable}{%",
    "\\begin{tabular}{lrrrrr}\\toprule",
    "Configuration & $R$ & Seconds & MiB & Max MiB & Test $C$ \\\\","\\midrule")
  for(i in seq_len(nrow(summary))) {
    z <- summary[i,]
    tab <- c(tab,paste0(paste(c(labels[z$case],z$repetitions,sprintf("%.2f",z$seconds),
      sprintf("%.1f",z$peak_mib),sprintf("%.1f",z$max_mib),sprintf("%.4f",z$test_C)),
      collapse=" & ")," \\\\"))
  }
  tab <- c(tab,"\\bottomrule\\end{tabular}}")
  audit <- read.csv("svm_verification.csv")
  tab <- c(tab,"\\newcommand{\\NumericalAuditTable}{%",
   "\\begin{tabular}{lrr}\\toprule","Check & Maximum difference & Tolerance \\\\","\\midrule")
  for(kernel in c("linear","additive")) {
   z <- audit[audit$kernel==kernel,]
   tab <- c(tab,sprintf("%s primal/dense dual (relative) & %.2e & $10^{-7}$ \\\\",kernel,max(z$relative_objective_difference)),
    sprintf("%s centered representer & %.2e & $10^{-6}$ \\\\",kernel,max(z$centered_representer_error)))
  }
  tab <- c(tab,"\\bottomrule\\end{tabular}}")
  writeLines(tab,"computational_results.tex")
  writeLines(capture.output(sessionInfo()),"benchmark_sessionInfo.txt")
  print(summary)
}
