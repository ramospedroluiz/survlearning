# Additional SVM diagnostics after replication.R, using its frozen CV choices.
library(survlearning)
library(survival)
stopifnot(as.character(packageVersion("survlearning")) == "0.3.4")
fits <- readRDS("backblaze_models.rds")
ids <- grep("^svm_(rank|hybrid|ipcw)_", names(fits), value = TRUE)
stopifnot(length(ids) == 6L)
saveRDS(lapply(fits[ids], function(x) x$best_params), "svm_learning_settings.rds")
cohort <- read.csv("backblaze_2013_baseline.csv", stringsAsFactors = FALSE)
drives <- cohort[cohort$eligible, ]
drives$manufacturer <- factor(drives$manufacturer)
drives$capacity_group <- factor(drives$capacity_group, levels = c("1 TB", "2 TB", "3 TB", "4 TB"))
drives$log_power_hours <- log1p(drives$smart_9_first)
drives$temperature <- drives$smart_194_first
drives$log_reallocated <- log1p(drives$smart_5_first)
drives$pending <- as.integer(drives$smart_197_first > 0)
drives$entry_day <- drives$first_date_num - min(drives$first_date_num)
split <- read.csv("split.csv")
stopifnot(identical(drives$serial_number, split$serial_number))
train <- drives[split$sample == "training", ]
test <- drives[split$sample == "test", ]
stopifnot(nrow(train) == 23246L, nrow(test) == 5812L)
settings <- precision <- conditional <- data.frame()
for (id in ids) {
  fit <- fits[[id]]$best_model
  p <- fit$params
  d <- fit$engine$diagnostics
  settings <- rbind(settings, data.frame(method = fit$method, kernel = p$kernel,
    lambda = p$lambda, rank_weight = if (is.null(p$rank_weight)) NA_real_ else p$rank_weight,
    horizon = if (is.null(p$horizon)) NA_real_ else p$horizon,
    epsilon = if (is.null(p$epsilon)) NA_real_ else p$epsilon,
    comparable_pairs = d$comparable_pairs, gradient_norm = d$gradient_norm,
    n_train = fit$n, events = fit$events, test_C = surv_score(fit, test)))
  p$tolerance <- 1e-7
  p$max_iter <- 10000L
  precise <- tryCatch(surv_fit(fit$formula, train, fit$method, p), error = identity)
  failed <- inherits(precise, "error")
  precision <- rbind(precision, data.frame(identifier = id, original_C = surv_score(fit, test),
    tighter_C = if (failed) NA_real_ else surv_score(precise, test),
    error = if (failed) conditionMessage(precise) else ""))
  if (fit$method == "svm_ipcw") {
    p <- fit$params
    p$censoring_method <- "cox"
    adjusted <- tryCatch(surv_fit(fit$formula, train, fit$method, p), error = identity)
    conditional <- rbind(conditional, data.frame(kernel = p$kernel, horizon = p$horizon,
      status = if (inherits(adjusted, "error")) conditionMessage(adjusted) else
        "Fitted under conditional Cox assumptions"))
  }
}
stopifnot(all(settings$n_train == 23246L), all(settings$events == 574L))
write.csv(settings, "svm_learning_selected.csv", row.names = FALSE)
write.csv(precision, "svm_learning_precision.csv", row.names = FALSE)
write.csv(conditional, "svm_learning_support.csv", row.names = FALSE)

rank_risk <- surv_predict(fits$svm_rank_additive, test)
rsf_risk <- surv_predict(fits$rsf, test)
set.seed(202610241)
differences <- rep(NA_real_, 1000)
for (b in seq_along(differences)) {
  index <- sample.int(nrow(test), replace = TRUE)
  observed <- test[index, ]
  r1 <- rank_risk[index]; r2 <- rsf_risk[index]
  differences[b] <- concordance(Surv(time_days, event) ~ r1, observed,
    reverse = TRUE, timefix = FALSE)$concordance -
    concordance(Surv(time_days, event) ~ r2, observed, reverse = TRUE, timefix = FALSE)$concordance
}
paired <- data.frame(comparison = "Ranking additive minus RSF",
  estimate = surv_score(fits$svm_rank_additive, test) - surv_score(fits$rsf, test),
  lower = quantile(differences, .025, na.rm = TRUE),
  upper = quantile(differences, .975, na.rm = TRUE))
write.csv(paired, "svm_learning_paired.csv", row.names = FALSE)

labels <- c(svm_rank = "Ranking", svm_hybrid = "Hybrid", svm_ipcw = "IPCW")
row_end <- paste0(intToUtf8(92), intToUtf8(92))
table <- c("\\newcommand{\\SvmLearningSettings}{%",
  "\\begin{tabular}{llrrrr}\\toprule",
  paste("Objective & Kernel & $\\lambda$ & $\\eta$ & $\\tau$ & $\\epsilon$", row_end), "\\midrule")
for (i in seq_len(nrow(settings))) {
  z <- settings[i, ]
  fields <- c(labels[z$method], z$kernel, format(z$lambda, scientific = TRUE),
    ifelse(is.na(z$rank_weight), "--", format(z$rank_weight)),
    ifelse(is.na(z$horizon), "--", format(z$horizon)),
    ifelse(is.na(z$epsilon), "--", format(z$epsilon)))
  table <- c(table, paste(paste(fields, collapse = " & "), row_end))
}
table <- c(table, "\\bottomrule\\end{tabular}}",
  sprintf("\\newcommand{\\SvmPairDifference}{%.4f}", paired$estimate),
  sprintf("\\newcommand{\\SvmPairLower}{%.4f}", paired$lower),
  sprintf("\\newcommand{\\SvmPairUpper}{%.4f}", paired$upper),
  paste0("\\newcommand{\\SvmTrainingPairs}{", format(settings$comparable_pairs[1], big.mark = ",", scientific = FALSE), "}"))
writeLines(table, "svm_learning_results.tex")
print(settings)
print(precision)
print(conditional)
print(paired)
