# Derived from randomForestSRC 3.9.0 (GPL >= 3); see inst/COPYRIGHTS.
# Extracted by dev/vendor_rsf.R and adapted locally; private fit/predict core.
.rsf_core <- local({
  as.formula <- stats::as.formula
  formula <- stats::formula
  na.omit <- stats::na.omit
  predict <- stats::predict
  quantile <- stats::quantile
  runif <- stats::runif
  tail <- utils::tail
  rfsrc <- function(formula, data, ntree = 500, mtry = NULL, ytry = NULL, nodesize = NULL, nodedepth = NULL, 
      splitrule = NULL, nsplit = NULL, importance = c(FALSE, TRUE, "none", "anti", "permute", "random"), 
      block.size = if (any(is.element(as.character(importance), c("none", "FALSE")))) NULL else 10, bootstrap = c("by.root", 
          "none", "by.user"), samptype = c("swor", "swr"), samp = NULL, membership = FALSE, sampsize = if (samptype == 
          "swor") function(x) {
          x * 0.632
      } else function(x) {
          x
      }, na.action = c("na.omit", "na.impute"), nimpute = 1, ntime = 150, cause, perf.type = NULL, proximity = FALSE, 
      distance = FALSE, forest.wt = FALSE, xvar.wt = NULL, yvar.wt = NULL, split.wt = NULL, case.wt = NULL, 
      case.depth = FALSE, forest = TRUE, use.uno = TRUE, save.memory = FALSE, var.used = c(FALSE, "all.trees", 
          "by.tree"), split.depth = c(FALSE, "all.trees", "by.tree"), seed = NULL, do.trace = FALSE, ...) {
      univariate.nomenclature = TRUE
      user.option <- list(...)
      impute.only <- is.hidden.impute.only(user.option)
      terminal.qualts <- is.hidden.terminal.qualts(user.option)
      terminal.quants <- is.hidden.terminal.quants(user.option, save.memory)
      big.data <- FALSE
      if (!forest) {
          terminal.qualts <- FALSE
          terminal.quants <- FALSE
          big.data <- TRUE
      }
      cse <- is.hidden.cse(user.option)
      csv <- is.hidden.csv(user.option)
      experimental <- is.hidden.experimental(user.option)
      data.pass <- is.hidden.data.pass(user.option)
      rfq <- is.hidden.rfq(user.option)
      gk.quantile <- is.hidden.gk.quantile(user.option)
      quantile.regr <- is.hidden.quantile.regr(user.option)
      prob <- is.hidden.prob(user.option)
      prob.epsilon <- is.hidden.prob.epsilon(user.option)
      mahalanobis.sigma <- is.hidden.mahalanobis.sigma(user.option)
      vtry <- is.hidden.vtry(user.option)
      holdout.array <- is.hidden.holdout.array(user.option)
      holdout.specs <- is.hidden.holdout.specs(user.option)
      tdc.rule <- is.hidden.tdc.rule(user.option)
      vimp.threshold <- is.hidden.vimp.threshold(user.option)
      ensemble <- "all"
      bootstrap <- match.arg(bootstrap, c("by.root", "none", "by.user"))
      if (bootstrap == "none") {
          ensemble <- "inbag"
      }
      importance <- match.arg(as.character(importance), c(FALSE, TRUE, "none", "anti", "permute", "random"))
      na.action <- match.arg(na.action, c("na.omit", "na.impute"))
      proximity <- match.arg(as.character(proximity), c(FALSE, TRUE, "inbag", "oob", "all"))
      distance <- match.arg(as.character(distance), c(FALSE, TRUE, "inbag", "oob", "all"))
      var.used <- match.arg(as.character(var.used), c("FALSE", "all.trees", "by.tree"))
      split.depth <- match.arg(as.character(split.depth), c("FALSE", "all.trees", "by.tree"))
      if (var.used == "FALSE") 
          var.used <- FALSE
      if (split.depth == "FALSE") 
          split.depth <- FALSE
      if (missing(data)) 
          stop("data is missing")
      if (!identical(class(data), "data.frame")) {
          data <- as.data.frame(data, optional = TRUE)
      }
      if (missing(formula) | (!missing(formula) && is.null(formula))) {
          if (is.null(ytry)) {
              formula <- as.formula("Unsupervised() ~ .")
          }
          else {
              formula <- as.formula(paste("Unsupervised(", ytry, ")~."))
          }
      }
      formulaPrelim <- parseFormula(formula, data, ytry)
      my.call <- match.call()
      my.call$formula <- eval(formula)
      if (data.pass == TRUE) {
          miss.flag = FALSE
      }
      else {
          if (any(is.na(data))) {
              data <- parseMissingData(formulaPrelim, data)
              miss.flag <- TRUE
          }
          else {
              miss.flag <- FALSE
          }
      }
      if (miss.flag == FALSE) {
          data.pass = TRUE
      }
      formulaDetail <- finalizeFormula(formulaPrelim, data)
      ntree <- round(ntree)
      if (ntree < 1) 
          stop("Invalid choice of 'ntree'.  Cannot be less than 1.")
      if (!is.null(nodesize) && nodesize < 1) 
          stop("Invalid choice of 'nodesize'. Cannot be less than 1.")
      if (!is.null(nodedepth)) 
          nodedepth = round(nodedepth)
      else nodedepth = -1
      nimpute <- round(nimpute)
      if (nimpute < 1) 
          stop("Invalid choice of 'nimpute'.  Cannot be less than 1.")
      seed <- get.seed(seed)
      family <- formulaDetail$family
      xvar.names <- formulaDetail$xvar.names
      yvar.names <- formulaDetail$yvar.names
      subj.names <- formulaDetail$subj.names
      if (length(xvar.names) == 0) {
          stop("something seems wrong: your formula did not define any x-variables")
      }
      if (family != "unsupv" && length(yvar.names) == 0) {
          stop("something seems wrong: your formula did not define any y-variables")
      }
      if (family == "class") {
          if (length(setdiff(levels(data[, yvar.names]), unique(data[, yvar.names]))) > 0) {
              warning("empty classes found when implementing classification\n")
          }
      }
      data <- rm.na.levels(data, xvar.names)
      data <- rm.na.levels(data, yvar.names)
      yfactor <- extract.factor(data, yvar.names)
      yfactor$types <- yvar.types <- get.yvar.type(family, yfactor$generic.types, yvar.names)
      yfactor$nlevels <- yvar.nlevels <- get.yvar.nlevels(family, yfactor$nlevels, yvar.names, data)
      xfactor <- extract.factor(data, xvar.names)
      xfactor$types <- xvar.types <- xfactor$generic.types
      xvar.nlevels <- xfactor$nlevels
      data <- finalizeData(c(subj.names, yvar.names, xvar.names), data, na.action, miss.flag)
      data.row.names <- rownames(data)
      xvar <- as.matrix(data[, xvar.names, drop = FALSE])
      rownames(xvar) <- colnames(xvar) <- NULL
      xfactor$numeric.levels <- xvar.numeric.levels <- get.numeric.levels(family, xfactor$nlevels, xvar)
      n <- nrow(xvar)
      n.xvar <- length(xvar.names)
      mtry <- get.grow.mtry(mtry, n.xvar, family, splitrule)
      samptype <- match.arg(samptype, c("swor", "swr"))
      subj.unique.count <- n
      subj <- NULL
      xvar.time <- NULL
      subj.time <- NULL
      if (bootstrap == "by.root") {
          if (!is.function(sampsize) && !is.numeric(sampsize)) {
              stop("sampsize must be a function or number specifying size of subsampled data")
          }
          if (is.function(sampsize)) {
              sampsize.function <- sampsize
          }
          else {
              sampsize.function <- make.samplesize.function(sampsize/subj.unique.count)
          }
          sampsize <- round(sampsize.function(subj.unique.count))
          if (sampsize < 1) {
              stop("sampsize must be greater than zero")
          }
          if (samptype == "swor" && (sampsize > subj.unique.count)) {
              sampsize.function <- function(x) {
                  x
              }
              sampsize <- subj.unique.count
          }
          samp <- NULL
          case.wt <- get.weight(case.wt, subj.unique.count)
      }
      else if (bootstrap == "by.user") {
          if (is.null(samp)) {
              stop("samp must not be NULL when bootstrapping by user")
          }
          ntree <- ncol(samp)
          sampsize <- colSums(samp)
          if (sum(sampsize == sampsize[1]) != ntree) {
              stop("sampsize must be identical for each tree")
          }
          sampsize <- sampsize[1]
          sampsize.function <- make.samplesize.function(sampsize[1]/subj.unique.count)
          case.wt <- get.weight(NULL, subj.unique.count)
      }
      else {
          sampsize <- subj.unique.count
          sampsize.function <- function(x) {
              x
          }
          case.wt <- get.weight(case.wt, sampsize)
      }
      split.wt <- get.weight(split.wt, n.xvar)
      forest.wt <- match.arg(as.character(forest.wt), c(FALSE, TRUE, "inbag", "oob", "all"))
      if (family == "unspv") {
          yvar.wt <- NULL
      }
      else {
          yvar.wt <- get.weight(yvar.wt, length(yvar.types))
      }
      xvar.wt <- get.weight(xvar.wt, n.xvar)
      yvar <- as.matrix(data[, yvar.names, drop = FALSE])
      if (dim(yvar)[2] == 0) {
          yvar <- yvar.nlevels <- yvar.numeric.levels <- yfactor <- NULL
      }
      else {
          yfactor$numeric.levels <- yvar.numeric.levels <- get.numeric.levels(family, yfactor$nlevels, 
              yvar)
      }
      if (miss.flag) {
          n.miss <- get.nmiss(xvar, yvar)
      }
      else {
          n.miss <- 0
      }
      if (impute.only && n.miss == 0) {
          return(data)
      }
      remove(data)
      event.info <- get.grow.event.info(yvar, family, ntime = ntime)
      splitinfo <- get.grow.splitinfo(formulaDetail, splitrule, nsplit, event.info)
      if (family == "surv" || family == "surv-CR") {
          if (length(event.info$event.type) > 1) {
              if (missing(cause) || is.null(cause)) {
                  cause <- NULL
                  cause.wt <- rep(1, length(event.info$event.type))
              }
              else {
                  if (length(cause) == 1) {
                    if (cause >= 1 && cause <= length(event.info$event.type)) {
                      cause.wt <- rep(0, length(event.info$event.type))
                      cause.wt[cause] <- 1
                    }
                    else {
                      cause.wt <- rep(1, length(event.info$event.type))
                    }
                  }
                  else {
                    if (length(cause) == length(event.info$event.type) && all(cause >= 0) && !all(cause == 
                      0)) {
                      cause.wt <- cause/sum(cause)
                    }
                    else {
                      cause.wt <- rep(1, length(event.info$event.type))
                    }
                  }
              }
          }
          else {
              cause <- NULL
              cause.wt = 1
          }
          family <- get.coerced.survival.fmly(family, subj, event.info$event.type, splitinfo$name)
      }
      else {
          cause <- cause.wt <- NULL
      }
      uno.weights <- NULL
      if (use.uno && (family == "surv" || family == "surv-CR")) {
          uno.weights <- get.uno.weights.train(event.info$time, event.info$cens)
      }
      nodesize <- get.grow.nodesize(family, nodesize)
      if ((bootstrap != "by.root") && (bootstrap != "by.user")) {
          importance <- "none"
          perf.type <- "none"
      }
      if (family == "unsupv") {
          importance <- "none"
          perf.type <- "none"
      }
      if (impute.only) {
          forest <- FALSE
          big.data <- FALSE
          proximity <- FALSE
          distance <- FALSE
          var.used <- FALSE
          split.depth <- FALSE
          membership <- FALSE
          perf.type <- "none"
          importance <- "none"
          case.depth <- FALSE
          terminal.qualts <- FALSE
          terminal.quants <- FALSE
          cse <- FALSE
          csv <- FALSE
      }
      if (!is.null(holdout.array)) {
          if (nrow(holdout.array) != n.xvar | ncol(holdout.array) != ntree) {
              stop("dimension of holdout.array does not conform to p x ntree")
          }
          vtry <- 1
      }
      gk.quantile <- get.gk.quantile(gk.quantile)
      prob.assign <- global.prob.assign(prob, prob.epsilon, gk.quantile, quantile.regr, splitinfo$name, 
          n)
      prob <- prob.assign$prob
      prob.epsilon <- prob.assign$prob.epsilon
      if (splitinfo$name == "mahalanobis" && !is.null(mahalanobis.sigma)) {
          if (length(yvar.names) != nrow(mahalanobis.sigma) || length(yvar.names) != ncol(mahalanobis.sigma)) {
              stop("dimension of mahalanobis sigma matrix is incorrect: must match dimension of y response")
          }
      }
      if (terminal.qualts | terminal.quants) {
          forest <- TRUE
      }
      perf.type <- get.perf(perf.type, impute.only, family)
      perf.bits <- get.perf.bits(perf.type)
      rfq <- get.rfq(rfq)
      rfq.bits <- get.rfq.bits(rfq, family)
      gk.quantile.bits <- get.gk.quantile.bits(gk.quantile)
      tdc.rule.bits <- get.tdc.rule.bits(tdc.rule)
      ensemble.bits <- get.ensemble.bits(ensemble)
      impute.only.bits <- get.impute.only.bits(impute.only, n.miss)
      var.used.bits <- get.var.used.bits(var.used)
      split.depth.bits <- get.split.depth.bits(split.depth)
      importance.value <- get.importance(importance, perf.type)
      importance.bits <- get.importance.bits(importance, perf.type)
      bootstrap.bits <- get.bootstrap.bits(bootstrap)
      forest.bits <- get.forest.bits(forest)
      proximity.bits <- get.proximity.bits(TRUE, proximity)
      distance.bits <- get.distance.bits(TRUE, distance)
      membership.bits <- get.membership.bits(membership)
      split.cust.bits <- get.split.cust.bits(splitinfo$cust)
      case.depth.bits <- get.case.depth.bits(case.depth)
      samptype.bits <- get.samptype.bits(samptype)
      forest.wt.bits <- get.forest.wt.bits(TRUE, bootstrap, forest.wt)
      na.action.bits <- get.na.action.bits(na.action)
      block.size <- get.block.size.bits(block.size, ntree)
      terminal.qualts.bits <- get.terminal.qualts.bits(terminal.qualts)
      terminal.quants.bits <- get.terminal.quants.bits(terminal.quants)
      cse.bits = get.cse.bits(cse)
      csv.bits = get.csv.bits(csv)
      data.pass.bits <- get.data.pass.bits(data.pass)
      experimental.bits <- get.experimental.bits(experimental)
      max.class.levels <- 0
      do.trace <- get.trace.bits(do.trace)
      ctime.external.start <- proc.time()
      nativeOutput <- tryCatch({
          .Call("sl_rfsrcGrow", as.integer(do.trace), as.integer(seed), as.integer(ensemble.bits + impute.only.bits + 
              var.used.bits + split.depth.bits + importance.bits + bootstrap.bits + forest.bits + proximity.bits + 
              perf.bits + rfq.bits + gk.quantile.bits + case.depth.bits), as.integer(samptype.bits + forest.wt.bits + 
              distance.bits + na.action.bits + split.cust.bits + membership.bits + terminal.qualts.bits + 
              terminal.quants.bits + tdc.rule.bits + cse.bits + csv.bits + data.pass.bits), as.integer(experimental.bits), 
              as.integer(splitinfo$index), as.integer(splitinfo$nsplit), as.integer(mtry), NULL, NULL, 
              as.integer(vtry), as.integer(holdout.array), holdout.specs, as.integer(formulaDetail$ytry), 
              as.integer(nodesize), as.integer(nodedepth), as.integer(length(cause.wt)), as.double(cause.wt), 
              as.double(vimp.threshold), as.integer(ntree), as.integer(n), list(as.integer(length(yvar.types)), 
                  if (is.null(yvar.types)) NULL else as.character(yvar.types), if (is.null(yvar.types)) NULL else as.integer(sapply(1:length(yvar.nlevels), 
                    function(nn) {
                      if (yvar.nlevels[nn] > 0) max(max.class.levels, yvar.nlevels[nn]) else 0
                    })), if (is.null(yvar.numeric.levels)) NULL else sapply(1:length(yvar.numeric.levels), 
                    function(nn) {
                      as.integer(length(yvar.numeric.levels[[nn]]))
                    }), if (is.null(subj)) NULL else as.integer(subj), if (is.null(event.info)) NULL else as.integer(length(event.info$event.type)), 
                  if (is.null(event.info)) NULL else as.integer(event.info$event.type)), if (is.null(yvar.numeric.levels)) {
                  NULL
              } else {
                  lapply(1:length(yvar.numeric.levels), function(nn) {
                    as.integer(yvar.numeric.levels[[nn]])
                  })
              }, if (is.null(yvar)) NULL else as.double(as.vector(yvar)), list(as.integer(n.xvar), as.character(xvar.types), 
                  if (is.null(xvar.types)) NULL else as.integer(xvar.nlevels), if (is.null(xvar.numeric.levels)) NULL else sapply(1:length(xvar.numeric.levels), 
                    function(nn) {
                      as.integer(length(xvar.numeric.levels[[nn]]))
                    }), if (is.null(xvar.time)) NULL else as.integer(xvar.time), if (is.null(subj.time)) NULL else as.integer(subj.time)), 
              if (is.null(xvar.numeric.levels)) {
                  NULL
              } else {
                  lapply(1:length(xvar.numeric.levels), function(nn) {
                    as.integer(xvar.numeric.levels[[nn]])
                  })
              }, as.double(as.vector(xvar)), list(as.integer(length(case.wt)), if (is.null(case.wt)) NULL else as.double(case.wt), 
                  as.integer(sampsize), if (is.null(samp)) NULL else as.integer(samp)), as.double(split.wt), 
              if (is.null(yvar.wt)) NULL else as.double(yvar.wt), as.double(xvar.wt), list(if (is.null(event.info$time.interest)) as.integer(0) else as.integer(length(event.info$time.interest)), 
                  if (is.null(event.info$time.interest)) NULL else as.double(event.info$time.interest)), 
              as.integer(nimpute), as.integer(block.size), list(if (is.null(prob)) as.integer(0) else as.integer(length(prob)), 
                  if (is.null(prob)) NULL else as.double(prob), if (is.null(prob.epsilon)) as.double(0) else as.double(prob.epsilon)), 
              if (is.null(mahalanobis.sigma)) NULL else as.double(as.vector(mahalanobis.sigma)), if (is.null(uno.weights)) NULL else as.double(uno.weights$weight), 
              as.integer(get.rf.cores()), PACKAGE = "survlearning")
      }, error = function(e) {
          stop(e)
      })
      ctime.external.stop <- proc.time()
      if (is.null(nativeOutput)) {
          if (impute.only) {
              return(NULL)
          }
          else {
              stop("An error has occurred in the grow algorithm.  Please turn trace on for further analysis.")
          }
      }
      if (n.miss > 0) {
          imputed.data <- matrix(nativeOutput$imputation, nrow = n.miss, byrow = FALSE)
          imputed.indv <- imputed.data[, 1]
          imputed.data <- as.matrix(imputed.data[, -1, drop = FALSE])
          nativeOutput$imputation <- NULL
          if (nimpute > 1) {
              if (grepl("surv", family)) {
                  yvar[imputed.indv, 1] <- imputed.data[, 1]
                  yvar[imputed.indv, 2] <- imputed.data[, 2]
                  xvar[imputed.indv, ] <- imputed.data[, -c(1:2), drop = FALSE]
              }
              else {
                  if (!is.null(yvar.types)) {
                    yvar[imputed.indv, ] <- imputed.data[, 1:length(yvar.types), drop = FALSE]
                    xvar[imputed.indv, ] <- imputed.data[, -c(1:length(yvar.types)), drop = FALSE]
                  }
                  else {
                    xvar[imputed.indv, ] <- imputed.data
                  }
              }
              imputed.indv <- NULL
              imputed.data <- NULL
              na.action = "na.omit"
          }
          else {
              colnames(imputed.data) <- c(yvar.names, xvar.names)
              imputed.data <- as.data.frame(imputed.data)
          }
      }
      xvar <- as.data.frame(xvar)
      rownames(xvar) <- data.row.names
      colnames(xvar) <- xvar.names
      xvar <- map.factor(xvar, xfactor)
      if (family != "unsupv") {
          yvar <- as.data.frame(yvar)
          colnames(yvar) <- yvar.names
      }
      else {
          yvar <- NULL
      }
      if (family != "unsupv") {
          if (family == "regr+" | family == "class+" | family == "mix+") {
              yvar <- map.factor(yvar, yfactor)
          }
          else {
              yvar <- amatrix.remove.names(map.factor(yvar, yfactor))
          }
      }
      class.relfrq <- NULL
      if (family == "class" && rfq) {
          class.relfrq <- prop.table(table(yvar))
      }
      if ((n.miss > 0) & (nimpute < 2)) {
          imputed.data <- map.factor(imputed.data, xfactor)
          if (family != "unsupv") {
              imputed.data <- map.factor(imputed.data, yfactor)
          }
      }
      if (forest) {
          nativeArraySize = 0
          mwcpCountSummary <- rep(0, 1)
          nativeFactorArray <- vector("list", 1)
          pivot <- which(names(nativeOutput) == "treeID")
          offset = 0
          nullO <- lapply(1:ntree, function(b) {
              if (nativeOutput$leafCount[b] > 0) {
                  nativeArraySize <<- nativeArraySize + (2 * nativeOutput$leafCount[b]) - 1
                  mwcpCountSummary[1] <<- mwcpCountSummary[1] + nativeOutput$mwcpCT[b]
              }
              else {
                  nativeArraySize <<- nativeArraySize + 1
              }
              NULL
          })
          rm(nullO)
          nativeArray <- as.data.frame(cbind(nativeOutput$treeID[1:nativeArraySize], nativeOutput$nodeID[1:nativeArraySize], 
              nativeOutput$nodeSZ[1:nativeArraySize], nativeOutput$brnodeID[1:nativeArraySize]))
          nativeArrayHeader <- c("treeID", "nodeID", "nodeSZ", "brnodeID")
          nativeArray <- as.data.frame(cbind(nativeArray, nativeOutput$parmID[1:nativeArraySize], nativeOutput$contPT[1:nativeArraySize], 
              nativeOutput$mwcpSZ[1:nativeArraySize], nativeOutput$fsrecID[1:nativeArraySize]))
          nativeArrayHeader <- c(nativeArrayHeader, "parmID", "contPT", "mwcpSZ", "fsrecID")
          if (mwcpCountSummary[1] > 0) {
              nativeFactorArray[[1]] <- nativeOutput$mwcpPT[1:mwcpCountSummary[1]]
          }
          nativeFactorArrayHeader <- "mwcpPT"
          names(nativeArray) <- nativeArrayHeader
          names(nativeFactorArray) <- nativeFactorArrayHeader
          if (terminal.qualts | terminal.quants) {
              totalLeafCount <- sum(nativeOutput$leafCount)
              valid.mcnt.indices <- 1:totalLeafCount
              if (terminal.quants) {
                  if (grepl("surv", family)) {
                    valid.2D.surv.indices <- 1:(totalLeafCount * length(event.info$event.type) * length(event.info$time.interest))
                    valid.1D.surv.indices <- 1:(totalLeafCount * length(event.info$time.interest))
                    valid.mort.indices <- 1:(totalLeafCount * length(event.info$event.type))
                  }
                  else {
                    class.index <- which(yvar.types != "R")
                    class.count <- length(class.index)
                    regr.index <- which(yvar.types == "R")
                    regr.count <- length(regr.index)
                    if (class.count > 0) {
                      levels.count <- array(0, class.count)
                      counter <- 0
                      for (i in class.index) {
                        counter <- counter + 1
                        levels.count[counter] <- yvar.nlevels[i]
                      }
                      valid.clas.indices <- 1:(totalLeafCount * sum(levels.count))
                    }
                    if (regr.count > 0) {
                      valid.regr.indices <- 1:(totalLeafCount * regr.count)
                    }
                  }
              }
              nativeArrayTNDS <- list(if (!is.null(nativeOutput$tnSURV)) nativeOutput$tnSURV[valid.1D.surv.indices] else NULL, 
                  if (!is.null(nativeOutput$tnMORT)) nativeOutput$tnMORT[valid.mort.indices] else NULL, 
                  if (!is.null(nativeOutput$tnNLSN)) nativeOutput$tnNLSN[valid.1D.surv.indices] else NULL, 
                  if (!is.null(nativeOutput$tnCSHZ)) nativeOutput$tnCSHZ[valid.2D.surv.indices] else NULL, 
                  if (!is.null(nativeOutput$tnCIFN)) nativeOutput$tnCIFN[valid.2D.surv.indices] else NULL, 
                  if (!is.null(nativeOutput$tnREGR)) nativeOutput$tnREGR[valid.regr.indices] else NULL, 
                  if (!is.null(nativeOutput$tnCLAS)) nativeOutput$tnCLAS[valid.clas.indices] else NULL, 
                  nativeOutput$rmbrMembership, nativeOutput$ambrMembership, nativeOutput$ombrMembership, 
                  nativeOutput$imbrMembership, nativeOutput$tnRCNT[valid.mcnt.indices], nativeOutput$tnACNT[valid.mcnt.indices], 
                  nativeOutput$tnOCNT[valid.mcnt.indices], nativeOutput$tnICNT[valid.mcnt.indices], nativeOutput$oobSZ, 
                  nativeOutput$ibgSZ)
              names(nativeArrayTNDS) <- c("tnSURV", "tnMORT", "tnNLSN", "tnCSHZ", "tnCIFN", "tnREGR", "tnCLAS", 
                  "tnRMBR", "tnAMBR", "tnOMBR", "tnIMBR", "tnRCNT", "tnACNT", "tnOCNT", "tnICNT", "oobSZ", 
                  "ibgSZ")
          }
          else {
              nativeArrayTNDS <- NULL
          }
          forest.out <- list(forest = TRUE, nativeArray = nativeArray, nativeFactorArray = nativeFactorArray, 
              leafCount = nativeOutput$leafCount, totalNodeCount = dim(nativeArray)[1], nodesize = nodesize, 
              nodedepth = nodedepth, ntree = ntree, family = family, n = n, splitrule = splitinfo$name, 
              xvar = xvar, xvar.names = xvar.names, xvar.factor = xfactor, yvar = yvar, yvar.names = yvar.names, 
              yvar.factor = yfactor, block.size = block.size, bootstrap = bootstrap, case.wt = case.wt, 
              event.info = event.info, uno.weights = uno.weights, gk.quantile = gk.quantile, na.action = na.action, 
              nativeArrayTNDS = nativeArrayTNDS, optLoGrow = nativeOutput$optLoGrow, experimental = experimental, 
              data.pass = data.pass, perf.type = perf.type, prob = prob, prob.epsilon = prob.epsilon, quantile.regr = quantile.regr, 
              rfq = rfq, sampsize = sampsize.function, samptype = samptype, samp = samp, subj = subj, subj.names = subj.names, 
              seed = nativeOutput$seed, seedVimp = if (importance == FALSE) NULL else nativeOutput$seedVimp, 
              terminal.qualts = terminal.qualts, terminal.quants = terminal.quants, importance = importance.value, 
              vimp.threshold = vimp.threshold, version = "3.9.0")
          if (grepl("surv", family)) {
              forest.out$time.interest <- event.info$time.interest
          }
          class(forest.out) <- c("rfsrc", "forest", family)
          if (big.data) {
              class(forest.out) <- c(class(forest.out), "bigdata")
          }
      }
      else {
          forest.out <- list(forest = FALSE, nodesize = nodesize, nodedepth = nodedepth, ntree = ntree, 
              family = family, n = n, splitrule = splitinfo$name, yvar = yvar, yvar.names = yvar.names, 
              xvar.names = xvar.names, subj = subj, subj.names = subj.names, bootstrap = bootstrap, sampsize = sampsize.function, 
              samptype = samptype, samp = samp, case.wt = case.wt, version = "3.9.0", na.action = na.action, 
              perf.type = perf.type, rfq = rfq, gk.quantile = gk.quantile, quantile.regr = quantile.regr, 
              prob = prob, prob.epsilon = prob.epsilon, block.size = block.size)
      }
      if (proximity != FALSE) {
          proximity.out <- matrix(0, n, n)
          count <- 0
          for (k in 1:n) {
              proximity.out[k, 1:k] <- nativeOutput$proximity[(count + 1):(count + k)]
              proximity.out[1:k, k] <- proximity.out[k, 1:k]
              count <- count + k
          }
          nativeOutput$proximity <- NULL
      }
      else {
          proximity.out <- NULL
      }
      if (distance != FALSE) {
          distance.out <- matrix(0, n, n)
          count <- 0
          for (k in 1:n) {
              distance.out[k, 1:k] <- nativeOutput$distance[(count + 1):(count + k)]
              distance.out[1:k, k] <- distance.out[k, 1:k]
              count <- count + k
          }
          nativeOutput$distance <- NULL
      }
      else {
          distance.out <- NULL
      }
      if (forest.wt != FALSE) {
          forest.wt.out <- matrix(nativeOutput$weight, c(n, n), byrow = TRUE)
          nativeOutput$weight <- NULL
      }
      else {
          forest.wt.out <- NULL
      }
      if (case.depth != FALSE) {
          case.depth.out <- matrix(nativeOutput$caseDepth, c(ntree, n), byrow = TRUE)
          nativeOutput$caseDepth <- NULL
      }
      else {
          case.depth.out <- NULL
      }
      if (membership) {
          membership.out <- matrix(nativeOutput$nodeMembership, c(n, ntree))
          inbag.out <- matrix(nativeOutput$bootMembership, c(n, ntree))
          nativeOutput$nodeMembership <- NULL
          nativeOutput$bootMembership <- NULL
          if (!is.null(subj)) {
              tdc.membership.cnt <- matrix(nativeOutput$nodeMembershipTDC[[1]], c(n, ntree))
              tdc.membership.out <- vector("list", ntree)
              begin.indx <- 0
              end.indx <- 0
              for (i in 1:ntree) {
                  temp <- vector("list", n)
                  for (j in 1:n) {
                    begin.indx <- end.indx + 1
                    end.indx <- end.indx + tdc.membership.cnt[j, i]
                    temp[[j]] <- nativeOutput$nodeMembershipTDC[[2]][begin.indx:end.indx]
                  }
                  tdc.membership.out[[i]] <- temp
              }
          }
          else {
              tdc.membership.out <- NULL
          }
      }
      else {
          membership.out <- NULL
          inbag.out <- NULL
          tdc.membership.out <- NULL
      }
      if (var.used != FALSE) {
          if (var.used == "all.trees") {
              var.used.out <- nativeOutput$varUsed
              names(var.used.out) <- xvar.names
          }
          else {
              var.used.out <- matrix(nativeOutput$varUsed, nrow = ntree, byrow = TRUE)
              colnames(var.used.out) <- xvar.names
          }
          nativeOutput$varUsed <- NULL
      }
      else {
          var.used.out <- NULL
      }
      if (split.depth != FALSE) {
          if (split.depth == "all.trees") {
              split.depth.out <- array(nativeOutput$splitDepth, c(n, n.xvar))
          }
          else {
              split.depth.out <- array(nativeOutput$splitDepth, c(n, n.xvar, ntree))
          }
          nativeOutput$splitDepth <- NULL
      }
      else {
          split.depth.out <- NULL
      }
      empr.risk <- NULL
      empr.risk.oob <- NULL
      if (!is.null(holdout.specs)) {
          holdout.blk <- nativeOutput$holdoutBlk
          nativeOutput$holdoutBlk <- NULL
      }
      else {
          holdout.blk = NULL
      }
      rfsrcOutput <- list(call = my.call, family = family, n = n, ntree = ntree, nimpute = nimpute, mtry = mtry, 
          nodesize = nodesize, nodedepth = nodedepth, nsplit = splitinfo$nsplit, yvar = yvar, yvar.names = yvar.names, 
          xvar = if (big.data) NULL else xvar, xvar.names = xvar.names, event.info = event.info, subj = subj, 
          subj.names = subj.names, xvar.wt = xvar.wt, split.wt = split.wt, cause.wt = cause.wt, leaf.count = nativeOutput$leafCount, 
          proximity = proximity.out, forest = forest.out, forest.wt = forest.wt.out, case.depth = case.depth.out, 
          distance = distance.out, membership = membership.out, tdc.membership = tdc.membership.out, splitrule = splitinfo$name, 
          inbag = inbag.out, var.used = var.used.out, imputed.indv = (if (n.miss > 0) imputed.indv else NULL), 
          imputed.data = (if (n.miss > 0) imputed.data else NULL), split.depth = split.depth.out, ensemble = ensemble, 
          holdout.array = holdout.array, block.size = block.size, holdout.blk = holdout.blk, empr.risk = empr.risk, 
          empr.risk.oob = empr.risk.oob, ctime.internal = nativeOutput$cTimeInternal, ctime.external = ctime.external.stop - 
              ctime.external.start)
      remove(yvar)
      remove(xvar)
      remove(proximity.out)
      remove(forest.out)
      remove(forest.wt.out)
      remove(case.depth.out)
      remove(distance.out)
      remove(membership.out)
      remove(inbag.out)
      remove(var.used.out)
      if (n.miss > 0) 
          remove(imputed.indv)
      if (n.miss > 0) 
          remove(imputed.data)
      remove(split.depth.out)
      remove(holdout.array)
      remove(empr.risk)
      remove(empr.risk.oob)
      survOutput <- NULL
      classOutput <- NULL
      regrOutput <- NULL
      if (!impute.only) {
          if (grepl("surv", family)) {
              if ((length(event.info$event.type) > 1) && (splitinfo$name != "l2.impute") && (splitinfo$name != 
                  "logrankscore")) {
                  coerced.event.count <- length(event.info$event.type)
              }
              else {
                  coerced.event.count <- 1
              }
              if (family == "surv") {
                  ens.names <- list(NULL, NULL)
                  mortality.names <- list(NULL, NULL)
                  err.names <- list(NULL, NULL)
                  vimp.names <- list(NULL, xvar.names)
              }
              else if (family == "surv-CR") {
                  ens.names <- list(NULL, NULL, c(paste("condCHF.", 1:length(event.info$event.type), sep = "")))
                  mortality.names <- list(NULL, paste("event.", 1:length(event.info$event.type), sep = ""))
                  cif.names <- list(NULL, NULL, c(paste("CIF.", 1:length(event.info$event.type), sep = "")))
                  err.names <- list(c(paste("event.", 1:length(event.info$event.type), sep = "")), NULL)
                  vimp.names <- list(paste("event.", 1:length(event.info$event.type), sep = ""), xvar.names)
              }
              else {
                  ens.names <- list(NULL, NULL)
              }
              chf <- (if (!is.null(nativeOutput$allEnsbCHF)) 
                  adrop3d.last(array(nativeOutput$allEnsbCHF, c(n, length(event.info$time.interest), length(event.info$event.type)), 
                    dimnames = ens.names), coerced.event.count)
              else NULL)
              nativeOutput$allEnsbCHF <- NULL
              survOutput <- list(chf = chf)
              remove(chf)
              chf.oob <- (if (!is.null(nativeOutput$oobEnsbCHF)) 
                  adrop3d.last(array(nativeOutput$oobEnsbCHF, c(n, length(event.info$time.interest), length(event.info$event.type)), 
                    dimnames = ens.names), coerced.event.count)
              else NULL)
              nativeOutput$oobEnsbCHF <- NULL
              survOutput = c(survOutput, chf.oob = list(chf.oob))
              remove(chf.oob)
              predicted <- (if (!is.null(nativeOutput$allEnsbMRT)) 
                  adrop2d.last(array(nativeOutput$allEnsbMRT, c(n, length(event.info$event.type)), dimnames = mortality.names), 
                    coerced.event.count)
              else NULL)
              nativeOutput$allEnsbMRT <- NULL
              survOutput = c(survOutput, predicted = list(predicted))
              remove(predicted)
              predicted.oob <- (if (!is.null(nativeOutput$oobEnsbMRT)) 
                  adrop2d.last(array(nativeOutput$oobEnsbMRT, c(n, length(event.info$event.type)), dimnames = mortality.names), 
                    coerced.event.count)
              else NULL)
              nativeOutput$oobEnsbMRT <- NULL
              survOutput <- c(survOutput, predicted.oob = list(predicted.oob))
              remove(predicted.oob)
              hazard <- (if (!is.null(nativeOutput$allEnsbKHZ)) 
                  matrix(nativeOutput$allEnsbKHZ, c(subj.unique.count, length(event.info$time.interest)))
              else NULL)
              nativeOutput$allEnsbKHZ <- NULL
              survOutput <- c(survOutput, hazard = list(hazard))
              remove(hazard)
              hazard.oob <- (if (!is.null(nativeOutput$oobEnsbKHZ)) 
                  matrix(nativeOutput$oobEnsbKHZ, c(subj.unique.count, length(event.info$time.interest)))
              else NULL)
              nativeOutput$oobEnsbKHZ <- NULL
              survOutput <- c(survOutput, hazard.oob = list(hazard.oob))
              remove(hazard.oob)
              survival <- (if (!is.null(nativeOutput$allEnsbSRV)) 
                  matrix(nativeOutput$allEnsbSRV, c(n, length(event.info$time.interest)))
              else NULL)
              nativeOutput$allEnsbSRV <- NULL
              survOutput <- c(survOutput, survival = list(survival))
              remove(survival)
              survival.oob <- (if (!is.null(nativeOutput$oobEnsbSRV)) 
                  matrix(nativeOutput$oobEnsbSRV, c(n, length(event.info$time.interest)))
              else NULL)
              nativeOutput$oobEnsbSRV <- NULL
              survOutput <- c(survOutput, survival.oob = list(survival.oob))
              remove(survival.oob)
              cif <- (if (!is.null(nativeOutput$allEnsbCIF)) 
                  array(nativeOutput$allEnsbCIF, c(n, length(event.info$time.interest), length(event.info$event.type)), 
                    dimnames = cif.names)
              else NULL)
              nativeOutput$allEnsbCIF <- NULL
              survOutput <- c(survOutput, cif = list(cif))
              remove(cif)
              cif.oob <- (if (!is.null(nativeOutput$oobEnsbCIF)) 
                  array(nativeOutput$oobEnsbCIF, c(n, length(event.info$time.interest), length(event.info$event.type)), 
                    dimnames = cif.names)
              else NULL)
              nativeOutput$oobEnsbCIF <- NULL
              survOutput = c(survOutput, cif.oob = list(cif.oob))
              remove(cif.oob)
              if (!is.null(nativeOutput$perfSurv)) {
                  err.rate <- adrop2d.first(array(nativeOutput$perfSurv, c(length(event.info$event.type), 
                    ntree), dimnames = err.names), coerced.event.count)
                  nativeOutput$perfSurv <- NULL
                  if (family == "surv-CR") {
                    survOutput = c(survOutput, err.rate = list(t(err.rate)))
                  }
                  else {
                    survOutput = c(survOutput, err.rate = list(err.rate))
                  }
                  remove(err.rate)
              }
              if (!is.null(nativeOutput$blockSurv)) {
                  err.block.rate <- adrop2d.first(array(nativeOutput$blockSurv, c(length(event.info$event.type), 
                    floor(ntree/block.size)), dimnames = err.names), coerced.event.count)
                  nativeOutput$blockSurv <- NULL
                  if (family == "surv-CR") {
                    survOutput = c(survOutput, err.block.rate = list(t(err.block.rate)))
                  }
                  else {
                    survOutput = c(survOutput, err.block.rate = list(err.block.rate))
                  }
                  remove(err.block.rate)
              }
              if (!is.null(nativeOutput$vimpSurv)) {
                  importance <- adrop2d.first(array(nativeOutput$vimpSurv, c(length(event.info$event.type), 
                    n.xvar), dimnames = vimp.names), coerced.event.count)
                  nativeOutput$vimpSurv <- NULL
                  if (family == "surv-CR") {
                    survOutput = c(survOutput, importance = list(t(importance)))
                  }
                  else {
                    survOutput = c(survOutput, importance = list(importance))
                  }
                  remove(importance)
              }
              survOutput = c(survOutput, list(time.interest = event.info$time.interest, ndead = sum(na.omit(event.info$cens) != 
                  0)))
              if (!is.null(nativeOutput$holdoutSurv)) {
                  holdout.vimp <- vector("list", length(rfsrcOutput$holdout.blk))
                  names(holdout.vimp) <- xvar.names
                  holdout.offset <- rfsrcOutput$holdout.blk * length(event.info$event.type)
                  holdout.offset.sum <- c(0, cumsum(holdout.offset))
                  for (i in 1:length(holdout.vimp)) {
                    if (rfsrcOutput$holdout.blk[i] > 0) {
                      if (length(event.info$event.type) > 1) {
                        holdout.vimp[[i]] <- array(nativeOutput$holdoutSurv[(holdout.offset.sum[i] + 1):holdout.offset.sum[i + 
                          1]], c(length(event.info$event.type), rfsrcOutput$holdout.blk[i]))
                      }
                      else {
                        holdout.vimp[[i]] <- nativeOutput$holdoutSurv[(holdout.offset.sum[i] + 1):holdout.offset.sum[i + 
                          1]]
                      }
                    }
                    else {
                      holdout.vimp[[i]] = NA
                    }
                  }
                  survOutput = c(survOutput, holdout.vimp = list(holdout.vimp))
                  remove(holdout.vimp)
              }
              if (univariate.nomenclature) {
                  rfsrcOutput <- c(rfsrcOutput, survOutput)
              }
              else {
                  rfsrcOutput <- c(rfsrcOutput, survOutput = list(survOutput))
              }
          }
          else {
              class.index <- which(yvar.types != "R")
              resp.clas.count <- length(class.index)
              regr.index <- which(yvar.types == "R")
              resp.regr.count <- length(regr.index)
              if (resp.clas.count > 0) {
                  classOutput <- vector("list", resp.clas.count)
                  names(classOutput) <- yvar.names[class.index]
                  levels.count <- array(0, resp.clas.count)
                  levels.names <- vector("list", resp.clas.count)
                  counter <- 0
                  for (i in class.index) {
                    counter <- counter + 1
                    levels.count[counter] <- yvar.nlevels[i]
                    if (yvar.types[i] == "C") {
                      levels.names[[counter]] <- yfactor$levels[[which(yfactor$factor == yvar.names[i])]]
                    }
                    else {
                      levels.names[[counter]] <- yfactor$order.levels[[which(yfactor$order == yvar.names[i])]]
                    }
                  }
                  tree.offset <- array(1, ntree)
                  if (ntree > 1) {
                    tree.offset[2:ntree] <- sum(1 + levels.count)
                  }
                  tree.offset <- cumsum(tree.offset)
                  block.offset <- array(1, floor(ntree/block.size))
                  if (floor(ntree/block.size) > 1) {
                    block.offset[2:floor(ntree/block.size)] <- sum(1 + levels.count)
                  }
                  block.offset <- cumsum(block.offset)
                  vimp.offset <- array(1, n.xvar)
                  if (n.xvar > 1) {
                    vimp.offset[2:n.xvar] <- sum(1 + levels.count)
                  }
                  vimp.offset <- cumsum(vimp.offset)
                  iter.ensb.start <- 0
                  iter.ensb.end <- 0
                  if (!is.null(nativeOutput$holdoutClas)) {
                    holdout.offset.x <- rfsrcOutput$holdout.blk * (sum(1 + levels.count))
                    holdout.offset.sum.x <- c(0, cumsum(holdout.offset.x))
                    holdout.offset.r <- 0
                  }
                  for (i in 1:resp.clas.count) {
                    iter.ensb.start <- iter.ensb.end
                    iter.ensb.end <- iter.ensb.end + (levels.count[i] * n)
                    ens.names <- list(NULL, levels.names[[i]])
                    err.names <- c("all", levels.names[[i]])
                    vimp.names <- list(c("all", levels.names[[i]]), xvar.names)
                    predicted <- (if (!is.null(nativeOutput$allEnsbCLS)) 
                      array(nativeOutput$allEnsbCLS[(iter.ensb.start + 1):iter.ensb.end], c(n, levels.count[i]), 
                        dimnames = ens.names)
                    else NULL)
                    classOutput[[i]] <- list(predicted = predicted)
                    response <- (if (!is.null(predicted)) 
                      get.bayes.rule(predicted, class.relfrq)
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], class = list(response))
                    remove(predicted)
                    remove(response)
                    predicted.oob <- (if (!is.null(nativeOutput$oobEnsbCLS)) 
                      array(nativeOutput$oobEnsbCLS[(iter.ensb.start + 1):iter.ensb.end], c(n, levels.count[i]), 
                        dimnames = ens.names)
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], predicted.oob = list(predicted.oob))
                    response.oob <- (if (!is.null(predicted.oob)) 
                      get.bayes.rule(predicted.oob, class.relfrq)
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], class.oob = list(response.oob))
                    remove(predicted.oob)
                    remove(response.oob)
                    cse.num <- (if (!is.null(nativeOutput$cseClas)) 
                      array(nativeOutput$cseClas[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], cse.num = list(cse.num))
                    remove(cse.num)
                    cse.den <- (if (!is.null(nativeOutput$cseDen)) 
                      array(nativeOutput$cseDen[1:n], n)
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], cse.den = list(cse.den))
                    if (!is.null(nativeOutput$perfClas)) {
                      err.rate <- array(0, c(1 + levels.count[i], ntree))
                      for (j in 1:(1 + levels.count[i])) {
                        err.rate[j, ] <- nativeOutput$perfClas[tree.offset]
                        tree.offset <- tree.offset + 1
                      }
                      row.names(err.rate) <- err.names
                      classOutput[[i]] <- c(classOutput[[i]], err.rate = list(t(err.rate)))
                      remove(err.rate)
                    }
                    if (!is.null(nativeOutput$blockClas)) {
                      err.block.rate <- array(0, c(1 + levels.count[i], floor(ntree/block.size)))
                      for (j in 1:(1 + levels.count[i])) {
                        err.block.rate[j, ] <- nativeOutput$blockClas[block.offset]
                        block.offset <- block.offset + 1
                      }
                      row.names(err.block.rate) <- err.names
                      classOutput[[i]] <- c(classOutput[[i]], err.block.rate = list(t(err.block.rate)))
                      remove(err.block.rate)
                    }
                    csv.idx <- array(0, n * n.xvar)
                    for (j in 1:n.xvar) {
                      csv.idx[(((j - 1) * n) + 1):(((j - 1) * n) + n)] <- (((i - 1) * n) + ((j - 1) * n * 
                        resp.clas.count) + 1):(((i - 1) * n) + ((j - 1) * n * resp.clas.count) + n)
                    }
                    csv.num <- (if (!is.null(nativeOutput$csvClas)) 
                      array(nativeOutput$csvClas[csv.idx], c(n, n.xvar))
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], csv.num = list(csv.num))
                    remove(csv.num)
                    csv.den <- (if (!is.null(nativeOutput$csvDen)) 
                      array(nativeOutput$csvDen, c(n, n.xvar))
                    else NULL)
                    classOutput[[i]] <- c(classOutput[[i]], csv.den = list(csv.den))
                    remove(csv.den)
                    if (!is.null(nativeOutput$vimpClas)) {
                      importance <- array(0, c(1 + levels.count[i], n.xvar), dimnames = vimp.names)
                      for (j in 1:(1 + levels.count[i])) {
                        importance[j, ] <- nativeOutput$vimpClas[vimp.offset]
                        vimp.offset <- vimp.offset + 1
                      }
                      classOutput[[i]] <- c(classOutput[[i]], importance = list(t(importance)))
                      remove(importance)
                    }
                    if (!is.null(nativeOutput$holdoutClas)) {
                      holdout.vimp <- vector("list", length(rfsrcOutput$holdout.blk))
                      names(holdout.vimp) <- xvar.names
                      if (i > 1) {
                        holdout.offset.r <- holdout.offset.r + (1 + levels.count[i - 1])
                      }
                      for (k in 1:length(holdout.vimp)) {
                        if (rfsrcOutput$holdout.blk[k] > 0) {
                          offset.x <- holdout.offset.sum.x[k]
                          offset.b <- 0
                          index.m <- NULL
                          for (m in 1:rfsrcOutput$holdout.blk[k]) {
                            if (m > 1) {
                              offset.b <- offset.b + (sum(1 + levels.count))
                            }
                            index.m <- c(index.m, seq(from = offset.x + offset.b + holdout.offset.r + 1, 
                              by = 1, length.out = levels.count[i] + 1))
                          }
                          holdout.vimp[[k]] = array(nativeOutput$holdoutClas[index.m], c(levels.count[i] + 
                            1, rfsrcOutput$holdout.blk[k]))
                        }
                        else {
                          holdout.vimp[[k]] = NA
                        }
                      }
                      classOutput[[i]] = c(classOutput[[i]], holdout.vimp = list(holdout.vimp))
                      remove(holdout.vimp)
                    }
                  }
                  nativeOutput$allEnsbCLS <- NULL
                  nativeOutput$oobEnsbCLS <- NULL
                  nativeOutput$perfClas <- NULL
                  nativeOutput$blockClas <- NULL
                  nativeOutput$vimpClas <- NULL
                  nativeOutput$holdoutClas <- NULL
                  if (univariate.nomenclature) {
                    if ((resp.clas.count == 1) & (resp.regr.count == 0)) {
                      names(classOutput) <- NULL
                      rfsrcOutput <- c(rfsrcOutput, unlist(classOutput, recursive = FALSE))
                    }
                    else {
                      rfsrcOutput <- c(rfsrcOutput, classOutput = list(classOutput))
                    }
                  }
                  else {
                    rfsrcOutput <- c(rfsrcOutput, classOutput = list(classOutput))
                  }
              }
              if (resp.regr.count > 0) {
                  regrOutput <- vector("list", resp.regr.count)
                  names(regrOutput) <- yvar.names[regr.index]
                  tree.offset <- array(1, ntree)
                  if (ntree > 1) {
                    tree.offset[2:ntree] <- length(regr.index)
                  }
                  tree.offset <- cumsum(tree.offset)
                  block.offset <- array(1, floor(ntree/block.size))
                  if (floor(ntree/block.size) > 1) {
                    block.offset[2:floor(ntree/block.size)] <- length(regr.index)
                  }
                  block.offset <- cumsum(block.offset)
                  vimp.offset <- array(1, n.xvar)
                  if (n.xvar > 1) {
                    vimp.offset[2:n.xvar] <- length(regr.index)
                  }
                  vimp.offset <- cumsum(vimp.offset)
                  iter.ensb.start <- 0
                  iter.ensb.end <- 0
                  iter.qntl.start <- 0
                  iter.qntl.end <- 0
                  if (!is.null(nativeOutput$holdoutRegr)) {
                    holdout.offset.x <- rfsrcOutput$holdout.blk * resp.regr.count
                    holdout.offset.sum.x <- c(0, cumsum(holdout.offset.x))
                    holdout.offset.r <- 0
                  }
                  for (i in 1:resp.regr.count) {
                    iter.ensb.start <- iter.ensb.end
                    iter.ensb.end <- iter.ensb.end + n
                    iter.qntl.start <- iter.qntl.end
                    iter.qntl.end <- iter.qntl.end + (length(prob) * n)
                    vimp.names <- xvar.names
                    predicted <- (if (!is.null(nativeOutput$allEnsbRGR)) 
                      array(nativeOutput$allEnsbRGR[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    regrOutput[[i]] <- list(predicted = predicted)
                    remove(predicted)
                    predicted.oob <- (if (!is.null(nativeOutput$oobEnsbRGR)) 
                      array(nativeOutput$oobEnsbRGR[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], predicted.oob = list(predicted.oob))
                    remove(predicted.oob)
                    cse.num <- (if (!is.null(nativeOutput$cseRegr)) 
                      array(nativeOutput$cseRegr[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], cse.num = list(cse.num))
                    remove(cse.num)
                    cse.den <- (if (!is.null(nativeOutput$cseDen)) 
                      array(nativeOutput$cseDen[1:n], n)
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], cse.den = list(cse.den))
                    quantile <- (if (!is.null(nativeOutput$allEnsbQNT)) 
                      array(nativeOutput$allEnsbQNT[(iter.qntl.start + 1):iter.qntl.end], c(n, length(prob)))
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], quantile = list(quantile))
                    remove(quantile)
                    quantile.oob <- (if (!is.null(nativeOutput$oobEnsbQNT)) 
                      array(nativeOutput$oobEnsbQNT[(iter.qntl.start + 1):iter.qntl.end], c(n, length(prob)))
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], quantile.oob = list(quantile.oob))
                    remove(quantile.oob)
                    if (!is.null(nativeOutput$perfRegr)) {
                      err.rate <- nativeOutput$perfRegr[tree.offset]
                      tree.offset <- tree.offset + 1
                      regrOutput[[i]] <- c(regrOutput[[i]], err.rate = list(err.rate))
                      remove(err.rate)
                    }
                    if (!is.null(nativeOutput$blockRegr)) {
                      err.block.rate <- nativeOutput$blockRegr[block.offset]
                      block.offset <- block.offset + 1
                      regrOutput[[i]] <- c(regrOutput[[i]], err.block.rate = list(err.block.rate))
                      remove(err.block.rate)
                    }
                    if (!is.null(nativeOutput$vimpRegr)) {
                      importance <- nativeOutput$vimpRegr[vimp.offset]
                      names(importance) <- xvar.names
                      vimp.offset <- vimp.offset + 1
                      regrOutput[[i]] <- c(regrOutput[[i]], importance = list(importance))
                      remove(importance)
                    }
                    csv.idx <- array(0, n * n.xvar)
                    for (j in 1:n.xvar) {
                      csv.idx[(((j - 1) * n) + 1):(((j - 1) * n) + n)] <- (((i - 1) * n) + ((j - 1) * n * 
                        resp.regr.count) + 1):(((i - 1) * n) + ((j - 1) * n * resp.regr.count) + n)
                    }
                    csv.num <- (if (!is.null(nativeOutput$csvRegr)) 
                      array(nativeOutput$csvRegr[csv.idx], c(n, n.xvar))
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], csv.num = list(csv.num))
                    remove(csv.num)
                    csv.den <- (if (!is.null(nativeOutput$csvDen)) 
                      array(nativeOutput$csvDen, c(n, n.xvar))
                    else NULL)
                    regrOutput[[i]] <- c(regrOutput[[i]], csv.den = list(csv.den))
                    remove(csv.den)
                    if (!is.null(nativeOutput$holdoutRegr)) {
                      holdout.vimp <- vector("list", length(rfsrcOutput$holdout.blk))
                      names(holdout.vimp) <- xvar.names
                      if (i > 1) {
                        holdout.offset.r <- holdout.offset.r + 1
                      }
                      for (k in 1:length(holdout.vimp)) {
                        if (rfsrcOutput$holdout.blk[k] > 0) {
                          offset.x <- holdout.offset.sum.x[k]
                          offset.b <- 0
                          index.m <- NULL
                          for (m in 1:rfsrcOutput$holdout.blk[k]) {
                            if (m > 1) {
                              offset.b <- offset.b + resp.regr.count
                            }
                            index.m <- c(index.m, offset.x + offset.b + holdout.offset.r + 1)
                          }
                          holdout.vimp[[k]] <- nativeOutput$holdoutRegr[index.m]
                        }
                        else {
                          holdout.vimp[[k]] <- NA
                        }
                      }
                      regrOutput[[i]] <- c(regrOutput[[i]], holdout.vimp = list(holdout.vimp))
                    }
                  }
                  nativeOutput$allEnsbRGR <- NULL
                  nativeOutput$oobEnsbRGR <- NULL
                  nativeOutput$allEnsbQNT <- NULL
                  nativeOutput$oobEnsbQNT <- NULL
                  nativeOutput$perfRegr <- NULL
                  nativeOutput$blockRegr <- NULL
                  nativeOutput$vimpRegr <- NULL
                  nativeOutput$holdoutRegr <- NULL
                  if (univariate.nomenclature) {
                    if ((resp.clas.count == 0) & (resp.regr.count == 1)) {
                      names(regrOutput) <- NULL
                      rfsrcOutput <- c(rfsrcOutput, unlist(regrOutput, recursive = FALSE))
                    }
                    else {
                      rfsrcOutput <- c(rfsrcOutput, regrOutput = list(regrOutput))
                    }
                  }
                  else {
                    rfsrcOutput <- c(rfsrcOutput, regrOutput = list(regrOutput))
                  }
              }
          }
      }
      class(rfsrcOutput) <- c("rfsrc", "grow", family)
      return(rfsrcOutput)
  }
  predict.rfsrc <- function(object, newdata, importance = c(FALSE, TRUE, "none", "anti", "permute", "random"), 
      get.tree = NULL, block.size = if (any(is.element(as.character(importance), c("none", "FALSE")))) NULL else 10, 
      na.action = c("na.omit", "na.impute", "na.random"), outcome = c("train", "test"), perf.type = NULL, 
      proximity = FALSE, forest.wt = FALSE, ptn.count = 0, distance = FALSE, var.used = c(FALSE, "all.trees", 
          "by.tree"), split.depth = c(FALSE, "all.trees", "by.tree"), case.depth = FALSE, seed = NULL, 
      do.trace = FALSE, membership = FALSE, marginal.xvar = NULL, ...) {
      dots <- list(...)
      m.target <- dots$m.target
      dots$m.target <- NULL
      importance.xvar <- dots$importance.xvar
      dots$importance.xvar <- NULL
      args <- c(list(object = object, m.target = m.target, importance = importance, get.tree = get.tree, 
          block.size = block.size, importance.xvar = importance.xvar, na.action = na.action, outcome = outcome, 
          perf.type = perf.type, proximity = proximity, forest.wt = forest.wt, ptn.count = ptn.count, distance = distance, 
          var.used = var.used, split.depth = split.depth, case.depth = case.depth, seed = seed, do.trace = do.trace, 
          membership = membership, marginal.xvar = marginal.xvar), dots)
      if (!missing(newdata)) {
          args$newdata <- newdata
      }
      return(do.call("generic.predict.rfsrc", args))
  }
  distance <- function(x, method = "euclidean", rowI = NULL, rowJ = NULL, do.trace = FALSE) {
      n = dim(x)[1]
      p = dim(x)[2]
      if (n < 2) {
          stop("matrix must have more than one (1) row")
      }
      if (length(rowI) > 0) {
          if (length(rowI) != length(rowJ)) {
              stop("rowI and rowJ identifiers must have the same length")
          }
      }
      method.names <- c("euclidean", "canberra", "maximum")
      if (is.null(method)) {
          method.idx <- which(method.names == "euclidean")
      }
      else {
          method.idx <- which(method.names == method)
      }
      if (length(method.idx) != 1) {
          stop("distance metric invalid")
      }
      nativeOutput <- .Call("sl_rfsrcDistance", as.integer(method.idx), as.integer(n), as.integer(p), as.double(x), 
          as.integer(length(rowI)), as.integer(rowI), as.integer(rowJ), as.integer(get.rf.cores()), as.integer(do.trace), 
          PACKAGE = "survlearning")
      if (is.null(nativeOutput)) {
          stop("An error has occurred in rfsrcDistance.  Please turn trace on for further analysis.")
      }
      if (length(rowI) > 0) {
          result <- list(rowI = rowI, rowJ = rowJ, distance = nativeOutput$distance)
      }
      else {
          result <- matrix(0, n, n)
          count <- 0
          for (k in 2:n) {
              result[k, 1:(k - 1)] <- nativeOutput$distance[(count + 1):(count + k - 1)]
              result[1:(k - 1), k] <- result[k, 1:(k - 1)]
              count <- count + (k - 1)
          }
      }
      return(result)
  }
  generic.predict.rfsrc <- function(object, newdata, m.target = NULL, importance = FALSE, get.tree = NULL, 
      block.size = NULL, importance.xvar, na.action = c("na.omit", "na.impute", "na.random"), outcome = c("train", 
          "test"), perf.type = NULL, proximity = FALSE, forest.wt = FALSE, ptn.count = 0, distance = FALSE, 
      var.used = c(FALSE, "all.trees", "by.tree"), split.depth = c(FALSE, "all.trees", "by.tree"), case.depth = FALSE, 
      seed = NULL, do.trace = FALSE, membership = FALSE, marginal.xvar = NULL, ...) {
      univariate.nomenclature <- TRUE
      user.option <- list(...)
      if (missing(object)) {
          stop("object is missing!")
      }
      if (sum(inherits(object, c("rfsrc", "grow"), TRUE) == c(1, 2)) != 2 & sum(inherits(object, c("rfsrc", 
          "forest"), TRUE) == c(1, 2)) != 2) 
          stop("this function only works for objects of class `(rfsrc, grow)' or '(rfsrc, forest)'")
      if (sum(inherits(object, c("rfsrc", "grow"), TRUE) == c(1, 2)) == 2) {
          if (is.forest.missing(object)) {
              stop("Forest information for prediction is missing.  Re-run rfsrc (grow call) with forest=TRUE")
          }
      }
      cse <- is.hidden.cse(user.option)
      csv <- is.hidden.csv(user.option)
      importance <- match.arg(as.character(importance)[1], c(FALSE, TRUE, "none", "anti", "permute", "random", 
          "anti.joint", "permute.joint", "random.joint"))
      if (grepl("joint", importance)) {
          vimp.joint <- TRUE
      }
      else {
          vimp.joint <- FALSE
      }
      na.action <- match.arg(na.action, c("na.omit", "na.impute", "na.random"))
      if (inherits(object, "anonymous") && na.action == "na.impute") {
          na.action <- "na.mean"
      }
      outcome <- match.arg(outcome, c("train", "test"))
      proximity <- match.arg(as.character(proximity), c(FALSE, TRUE, "inbag", "oob", "all", "hybrid"))
      forest.wt <- match.arg(as.character(forest.wt), c(FALSE, TRUE, "inbag", "oob", "all"))
      distance <- match.arg(as.character(distance), c(FALSE, TRUE, "inbag", "oob", "all", "hybrid"))
      if (missing(newdata)) {
          restore.mode <- TRUE
          outcome <- "train"
          ensemble <- "all"
      }
      else {
          restore.mode <- FALSE
          if (outcome == "test") {
              ensemble <- "all"
          }
          else {
              ensemble <- "inbag"
          }
      }
      if (inherits(object, "anonymous")) {
          anonymize.bits <- 2^26
          outcome <- "train"
          if (restore.mode) {
              stop("in order to predict with anonymous forests please provide a test data set")
          }
      }
      else {
          anonymize.bits <- 0
      }
      jitt <- is.hidden.jitt(user.option, importance, na.action, inherits(object, "anonymous"), partial = FALSE)
      rfq <- is.hidden.rfq(user.option)
      gk.quantile <- is.hidden.gk.quantile(user.option)
      prob <- is.hidden.prob(user.option)
      prob.epsilon <- is.hidden.prob.epsilon(user.option)
      vimp.threshold <- is.hidden.vimp.threshold(user.option)
      family <- object$family
      xvar.names <- object$xvar.names
      yvar.names <- object$yvar.names
      subj.names <- object$subj.names
      importance.xvar <- get.importance.xvar(importance.xvar, importance, object)
      importance.xvar.idx <- match(importance.xvar, xvar.names)
      marginal.xvar <- get.marginal.xvar(marginal.xvar, object)
      marginal.xvar.idx <- NULL
      if (length(marginal.xvar) > 0) {
          marginal.xvar.idx <- match(marginal.xvar, xvar.names)
      }
      var.used <- match.arg(as.character(var.used), c("FALSE", "all.trees", "by.tree"))
      if (var.used == "FALSE") 
          var.used <- FALSE
      split.depth <- match.arg(as.character(split.depth), c("FALSE", "all.trees", "by.tree"))
      if (split.depth == "FALSE") 
          split.depth <- FALSE
      split.depth = FALSE
      seed <- get.seed(seed)
      big.data <- FALSE
      if (sum(inherits(object, c("rfsrc", "grow"), TRUE) == c(1, 2)) == 2) {
          if (inherits(object, "bigdata")) {
              big.data <- TRUE
          }
          object <- object$forest
      }
      else {
          if (inherits(object, "bigdata")) {
              big.data <- TRUE
          }
      }
      if (is.null(object$version)) {
          stop("Prediction requires RF-SRC engine version 2.3.0 or later; ",
               "the fitted object's engine version is unknown.", call. = FALSE)
      }
      else {
          object.version <- as.integer(unlist(strsplit(object$version, "[.]")))
          installed.version <- as.integer(unlist(strsplit("3.9.0", "[.]")))
          minimum.version <- as.integer(unlist(strsplit("2.3.0", "[.]")))
          object.version.adj <- object.version[1] + (object.version[2]/10) + (object.version[3]/100)
          installed.version.adj <- installed.version[1] + (installed.version[2]/10) + (installed.version[3]/100)
          minimum.version.adj <- minimum.version[1] + (minimum.version[2]/10) + (minimum.version[3]/100)
          if (object.version.adj >= minimum.version.adj) {
          }
          else {
              stop("Prediction requires RF-SRC engine version 2.3.0 or later; ",
                   "the fitted object's engine version is ", object$version, ".",
                   call. = FALSE)
          }
      }
      class.relfrq <- NULL
      if (family == "class") {
          if (!is.null(rfq)) {
              if (!rfq) {
              }
              else {
                  class.relfrq <- prop.table(table(object$yvar))
              }
          }
          if (is.null(rfq)) {
              if (!object$rfq) {
              }
              else {
                  class.relfrq <- prop.table(table(object$yvar))
                  rfq <- TRUE
              }
          }
          if (is.null(perf.type) && !is.null(object$perf.type)) {
              perf.type <- object$perf.type
          }
      }
      splitrule <- object$splitrule
      if (!is.null(gk.quantile) || object$gk.quantile) {
          if (is.null(gk.quantile)) {
              gk.quantile <- object$gk.quantile
          }
      }
      gk.quantile <- get.gk.quantile(gk.quantile)
      prob.assign <- global.prob.assign(if (is.null(prob)) 
          object$prob
      else prob, if (is.null(prob.epsilon)) 
          object$prob.epsilon
      else prob.epsilon, gk.quantile, object$quantile.regr, splitrule, object$n)
      prob <- prob.assign$prob
      prob.epsilon <- prob.assign$prob.epsilon
      yfactor <- object$yvar.factor
      m.target.idx <- get.outcome.target(family, yvar.names, m.target)
      yvar.types <- yfactor$types
      yvar.nlevels <- yfactor$nlevels
      yvar.numeric.levels <- yfactor$numeric.levels
      subj <- object$subj
      event.info <- object$event.info
      event.type <- event.info$event.type
      cr.bits <- get.cr.bits(family)
      xfactor <- object$xvar.factor
      any.xvar.factor <- (length(xfactor$factor) + length(xfactor$order)) > 0
      xvar.types <- xfactor$types
      xvar.nlevels <- xfactor$nlevels
      xvar.numeric.levels <- xfactor$numeric.levels
      n.xvar <- length(xvar.names)
      n <- object$n
      r.dim <- event.info$rdim
      if (family == "unsupv") {
          outcome <- "train"
          perf.type <- "none"
          importance <- "none"
      }
      if (grepl("surv", family)) {
          ptn.count <- 0
      }
      uno.weights.test <- NULL
      use.uno <- !is.null(object$uno.weights)
      if (!is.null(user.option$use.uno) && isFALSE(user.option$use.uno)) {
          use.uno <- FALSE
      }
      if (!is.null(user.option$use.uno) && isTRUE(user.option$use.uno)) {
          use.uno <- TRUE
      }
      if (!restore.mode) {
          if (!identical(class(newdata), "data.frame")) {
              newdata <- as.data.frame(newdata, optional = TRUE)
          }
          newdata <- newdata[, is.element(names(newdata), c(yvar.names, xvar.names)), drop = FALSE]
          if (inherits(object, "anonymous") && na.action == "na.mean") {
              newdata <- assign.impute.mean(newdata, object$impute.mean)
              na.action <- "na.omit"
          }
          newdata <- rm.na.levels(newdata, xvar.names)
          any.outcome.factor <- family == "class"
          if (family == "class+" | family == "mix+") {
              if (length(intersect("R", yfactor$generic.types[m.target.idx])) == 0) {
                  any.outcome.factor <- TRUE
              }
          }
          if (any.outcome.factor) {
              if (sum(is.element(names(newdata), yvar.names)) > 0) {
                  newdata <- rm.na.levels(newdata, yvar.names)
              }
          }
          if (length(xvar.names) != sum(is.element(xvar.names, names(newdata)))) {
              stop("x-variables in test data do not match original training data")
          }
          yvar.present <- sum(is.element(yvar.names, names(newdata))) > 0
          if (yvar.present && length(yvar.names) != sum(is.element(yvar.names, names(newdata)))) {
              stop("y-variables in test data do not match original training data")
          }
          if (any.xvar.factor) {
              newdata <- check.factor(newdata, xfactor)
          }
          if (any.outcome.factor) {
              if (yvar.present) {
                  newdata <- check.factor(newdata, yfactor, ignore = TRUE)
              }
          }
          if (yvar.present) {
              fnames <- c(yvar.names, xvar.names)
          }
          else {
              fnames <- xvar.names
          }
          newdata <- finalizeData(fnames, newdata, na.action)
          xvar.newdata <- as.matrix(newdata[, xvar.names, drop = FALSE])
          n.newdata <- nrow(newdata)
          newdata.row.names <- rownames(xvar.newdata)
          if (yvar.present) {
              yvar.newdata <- as.matrix(newdata[, yvar.names, drop = FALSE])
              event.info.newdata <- get.grow.event.info(yvar.newdata, family, need.deaths = FALSE)
              r.dim.newdata <- event.info.newdata$r.dim
              if (grepl("surv", family) && all(na.omit(event.info.newdata$cens) == 0)) {
                  perf.type <- "none"
                  importance <- "none"
              }
              if (grepl("surv", family) && length(setdiff(na.omit(event.info.newdata$cens), na.omit(event.info$cens))) > 
                  1) {
                  stop("survival events in test data do not match training data")
              }
              if (!is.null(object$uno.weights) && isTRUE(use.uno)) {
                  uno.weights.test <- uno.prepare.test(yvar.newdata[, 1], yvar.newdata[, 2], object$uno.weights$fit)$weight
              }
              if (is.null(object$uno.weights) && isTRUE(use.uno)) {
                  uno.weights.fit <- get.uno.weights.train(object$event.info$time, object$event.info$cens)$fit
                  uno.weights.test <- uno.prepare.test(yvar.newdata[, 1], yvar.newdata[, 2], uno.weights.fit)$weight
              }
          }
          else {
              if (outcome == "test") {
                  stop("outcome=TEST, but the test data has no y values, which is not permitted")
              }
              r.dim.newdata <- 0
              yvar.newdata <- NULL
              perf.type <- "none"
              importance <- "none"
          }
          if (outcome != "test") {
              rownames(xvar.newdata) <- colnames(xvar.newdata) <- NULL
          }
          remove(newdata)
      }
      else {
          n.newdata <- 0
          r.dim.newdata <- 0
          xvar.newdata <- NULL
          yvar.newdata <- NULL
          outcome <- "train"
          if (object$bootstrap == "none" || object$bootstrap == "by.node" || family == "unsupv") {
              importance <- "none"
              perf.type <- "none"
          }
          else {
          }
          if (is.null(user.option$vimp.threshold)) {
              vimp.threshold <- object$vimp.threshold
          }
          if (!is.null(object$uno.weights) && isTRUE(use.uno)) {
              uno.weights.test <- object$uno.weights$weight
          }
          if (is.null(object$uno.weights) && isTRUE(use.uno)) {
              uno.weights.test <- get.uno.weights.train(object$event.info$time, object$event.info$cens)$weight
          }
      }
      if (outcome == "train") {
          yvar <- as.matrix(data.matrix(data.frame(object$yvar)))
          sampsize <- round(object$sampsize(n))
          case.wt <- object$case.wt
          samp <- object$samp
          if (anonymize.bits == 0) {
              xvar <- as.matrix(data.matrix(object$xvar))
              rownames(xvar) <- colnames(xvar) <- NULL
          }
          else {
              xvar <- NULL
          }
      }
      if (outcome == "test") {
          xvar <- xvar.newdata
          yvar <- yvar.newdata
          rownames(xvar) <- colnames(xvar) <- NULL
          restore.mode <- TRUE
          n <- nrow(xvar)
          r.dim <- r.dim.newdata
          n.newdata <- 0
          r.dim.newdata <- 0
          sampsize <- round(object$sampsize(n))
          case.wt <- get.weight(NULL, n)
          samp <- NULL
      }
      ntree <- object$ntree
      get.tree <- get.tree.index(get.tree, ntree)
      perf.type <- get.perf(perf.type, FALSE, family)
      perf.bits <- get.perf.bits(perf.type)
      rfq <- get.rfq(rfq)
      rfq.bits <- get.rfq.bits(rfq, family)
      gk.quantile.bits <- get.gk.quantile.bits(gk.quantile)
      bootstrap.bits <- get.bootstrap.bits(object$bootstrap)
      ensemble.bits <- get.ensemble.bits(ensemble)
      importance.bits <- get.importance.bits(importance, perf.type)
      proximity.bits <- get.proximity.bits(restore.mode, proximity)
      distance.bits <- get.distance.bits(restore.mode, distance)
      split.depth.bits <- get.split.depth.bits(split.depth)
      var.used.bits <- get.var.used.bits(var.used)
      outcome.bits <- get.outcome.bits(outcome)
      case.depth.bits <- get.case.depth.bits(case.depth)
      samptype.bits <- get.samptype.bits(object$samptype)
      forest.wt.bits <- get.forest.wt.bits(restore.mode, object$bootstrap, forest.wt)
      membership.bits <- get.membership.bits(membership)
      terminal.qualts.bits <- get.terminal.qualts.predict.bits(object$terminal.qualts)
      terminal.quants.bits <- get.terminal.quants.predict.bits(object$terminal.quants)
      cse.bits = get.cse.bits(cse)
      csv.bits = get.csv.bits(csv)
      jitt.bits <- get.jitt.bits(jitt)
      data.pass.bits <- get.data.pass.bits(object$data.pass)
      if (restore.mode == FALSE) {
          if (na.action == "na.omit") {
              data.pass.predict.bits <- get.data.pass.predict.bits(TRUE)
          }
          else {
              data.pass.predict.bits <- get.data.pass.predict.bits(FALSE)
          }
      }
      else {
          data.pass.predict.bits <- get.data.pass.predict.bits(FALSE)
      }
      block.size <- min(get.block.size.bits(block.size, ntree), sum(get.tree))
      partial.bits <- get.partial.bits(0)
      if (restore.mode) {
          na.action = object$na.action
      }
      na.action.bits <- get.na.action.bits(na.action)
      do.trace <- get.trace.bits(do.trace)
      pivot = 0
      chunk = 0
      max.class.levels <- 0
      ctime.external.start <- proc.time()
      nativeOutput <- tryCatch({
          .Call("sl_rfsrcPredict", as.integer(do.trace), as.integer(seed), as.integer(ensemble.bits + importance.bits + 
              bootstrap.bits + proximity.bits + split.depth.bits + var.used.bits + outcome.bits + perf.bits + 
              rfq.bits + cr.bits + gk.quantile.bits + anonymize.bits + case.depth.bits), as.integer(forest.wt.bits + 
              distance.bits + samptype.bits + na.action.bits + membership.bits + terminal.qualts.bits + 
              terminal.quants.bits + cse.bits + csv.bits + data.pass.bits + data.pass.predict.bits + jitt.bits), 
              as.double(vimp.threshold), as.integer(ntree), as.integer(n), list(as.integer(length(yvar.types)), 
                  if (is.null(yvar.types)) NULL else as.character(yvar.types), if (is.null(yvar.types)) NULL else as.integer(sapply(1:length(yvar.nlevels), 
                    function(nn) {
                      if (yvar.nlevels[nn] > 0) max(max.class.levels, yvar.nlevels[nn]) else 0
                    })), if (is.null(yvar.numeric.levels)) NULL else sapply(1:length(yvar.numeric.levels), 
                    function(nn) {
                      as.integer(length(yvar.numeric.levels[[nn]]))
                    }), if (is.null(subj)) NULL else as.integer(subj), if (is.null(event.type)) NULL else as.integer(length(event.type)), 
                  if (is.null(event.type)) NULL else as.integer(event.type)), if (is.null(yvar.numeric.levels)) {
                  NULL
              } else {
                  lapply(1:length(yvar.numeric.levels), function(nn) {
                    as.integer(yvar.numeric.levels[[nn]])
                  })
              }, if (is.null(yvar.types)) NULL else as.double(as.vector(yvar)), list(as.integer(n.xvar), 
                  as.character(xvar.types), if (is.null(xvar.types)) NULL else as.integer(xvar.nlevels), 
                  if (is.null(xvar.numeric.levels)) NULL else sapply(1:length(xvar.numeric.levels), function(nn) {
                    as.integer(length(xvar.numeric.levels[[nn]]))
                  }), NULL, NULL), if (is.null(xvar.numeric.levels)) {
                  NULL
              } else {
                  lapply(1:length(xvar.numeric.levels), function(nn) {
                    as.integer(xvar.numeric.levels[[nn]])
                  })
              }, if (is.null(xvar)) NULL else as.double(as.vector(xvar)), list(as.integer(length(case.wt)), 
                  if (is.null(case.wt)) NULL else as.double(case.wt), as.integer(sampsize), if (is.null(samp)) NULL else as.integer(samp)), 
              list(if (is.null(event.info$time.interest)) as.integer(0) else as.integer(length(event.info$time.interest)), 
                  if (is.null(event.info$time.interest)) NULL else as.double(event.info$time.interest)), 
              as.integer(object$totalNodeCount), as.integer(object$leafCount), list(as.integer(object$seed), 
                  if (is.null(object$seedVimp)) NULL else as.integer(object$seedVimp), as.integer(object$optLoGrow)), 
              as.integer(0), NULL, as.integer((object$nativeArray)$treeID), as.integer((object$nativeArray)$nodeID), 
              as.integer((object$nativeArray)$nodeSZ), as.integer((object$nativeArray)$brnodeID), list(as.integer((object$nativeArray)$parmID), 
                  as.double((object$nativeArray)$contPT), as.integer((object$nativeArray)$mwcpSZ), as.integer((object$nativeArray)$fsrecID), 
                  if (is.null((object$nativeFactorArray)$mwcpPT)) NULL else as.integer((object$nativeFactorArray)$mwcpPT)), 
              NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, as.integer(object$nativeArrayTNDS$tnRMBR), 
              as.integer(object$nativeArrayTNDS$tnAMBR), as.integer(object$nativeArrayTNDS$tnRCNT), as.integer(object$nativeArrayTNDS$tnACNT), 
              as.double((object$nativeArrayTNDS$tnSURV)), as.double((object$nativeArrayTNDS$tnMORT)), as.double((object$nativeArrayTNDS$tnNLSN)), 
              as.double((object$nativeArrayTNDS$tnCSHZ)), as.double((object$nativeArrayTNDS$tnCIFN)), as.double((object$nativeArrayTNDS$tnREGR)), 
              as.integer((object$nativeArrayTNDS$tnCLAS)), list(if (is.null(m.target.idx)) as.integer(0) else as.integer(length(m.target.idx)), 
                  if (is.null(m.target.idx)) NULL else as.integer(m.target.idx)), as.integer(ptn.count), 
              list(if (is.null(marginal.xvar.idx)) as.integer(0) else as.integer(length(marginal.xvar.idx)), 
                  if (is.null(marginal.xvar.idx)) NULL else as.integer(marginal.xvar.idx)), list(if (is.null(importance.xvar.idx)) as.integer(0) else as.integer(length(importance.xvar.idx)), 
                  if (is.null(importance.xvar.idx)) NULL else as.integer(importance.xvar.idx)), list(as.integer(0), 
                  as.integer(0), as.integer(0), NULL, as.integer(0), NULL, NULL), as.integer(n.newdata), 
              as.integer(r.dim.newdata), as.double(if (outcome != "test") yvar.newdata else NULL), as.double(if (outcome != 
                  "test") xvar.newdata else NULL), as.integer(block.size), list(if (is.null(prob.assign$prob)) as.integer(0) else as.integer(length(prob.assign$prob)), 
                  if (is.null(prob.assign$prob)) NULL else as.double(prob.assign$prob), if (is.null(prob.assign$prob.epsilon)) as.double(0) else as.double(prob.assign$prob.epsilon)), 
              as.integer(get.tree), if (is.null(uno.weights.test)) NULL else as.double(uno.weights.test), 
              as.integer(get.rf.cores()), PACKAGE = "survlearning")
      }, error = function(e) {
          stop(e)
      })
      ctime.external.stop <- proc.time()
      if (is.null(nativeOutput)) {
          stop("An error has occurred in prediction.  Please turn trace on for further analysis.")
      }
      if (!inherits(object, "anonymous") && na.action != "na.random") {
          if (restore.mode) {
              n.miss <- get.nmiss(xvar, yvar)
          }
          else {
              n.miss <- get.nmiss(xvar.newdata, yvar.newdata)
          }
      }
      else {
          n.miss <- 0
      }
      if (n.miss > 0) {
          imputed.data <- matrix(nativeOutput$imputation, nrow = n.miss)
          nativeOutput$imputation <- NULL
          imputed.indv <- imputed.data[, 1]
          imputed.data <- as.data.frame(imputed.data[, -1, drop = FALSE])
          if ((r.dim.newdata > 0) | (perf.type != "none")) {
              colnames(imputed.data) <- c(yvar.names, xvar.names)
          }
          else {
              colnames(imputed.data) <- xvar.names
          }
      }
      if (!restore.mode | outcome == "test") {
          xvar.newdata <- as.data.frame(xvar.newdata)
          rownames(xvar.newdata) <- newdata.row.names
          colnames(xvar.newdata) <- xvar.names
          xvar.newdata <- map.factor(xvar.newdata, xfactor)
          if (perf.type != "none") {
              yvar.newdata <- as.data.frame(yvar.newdata)
              colnames(yvar.newdata) <- yvar.names
              yvar.newdata <- map.factor(yvar.newdata, yfactor)
          }
      }
      if (n.miss > 0) {
          imputed.data <- map.factor(imputed.data, xfactor)
          if (perf.type != "none") {
              imputed.data <- map.factor(imputed.data, yfactor)
          }
      }
      if (proximity != FALSE) {
          if (restore.mode) {
              prox.n <- n
          }
          else {
              prox.n <- n.newdata
          }
          if (proximity == "hybrid") {
              proximity.out <- matrix(nativeOutput$proximity, nrow = n.newdata, ncol = n, byrow = TRUE)
          }
          else {
              proximity.out <- matrix(0, prox.n, prox.n)
              count <- 0
              for (k in 1:prox.n) {
                  proximity.out[k, 1:k] <- nativeOutput$proximity[(count + 1):(count + k)]
                  proximity.out[1:k, k] <- proximity.out[k, 1:k]
                  count <- count + k
              }
          }
          nativeOutput$proximity <- NULL
      }
      else {
          proximity.out <- NULL
      }
      if (distance != FALSE) {
          if (restore.mode) {
              dist.n <- n
          }
          else {
              dist.n <- n.newdata
          }
          if (distance == "hybrid") {
              distance.out <- matrix(nativeOutput$distance, nrow = n.newdata, ncol = n, byrow = TRUE)
          }
          else {
              distance.out <- matrix(0, dist.n, dist.n)
              count <- 0
              for (k in 1:dist.n) {
                  distance.out[k, 1:k] <- nativeOutput$distance[(count + 1):(count + k)]
                  distance.out[1:k, k] <- distance.out[k, 1:k]
                  count <- count + k
              }
          }
          nativeOutput$distance <- NULL
      }
      else {
          distance.out <- NULL
      }
      if (forest.wt != FALSE) {
          if (restore.mode) {
              forest.wt.n <- c(n, n)
          }
          else {
              forest.wt.n <- c(n.newdata, n)
          }
          forest.wt.out <- matrix(nativeOutput$weight, forest.wt.n, byrow = TRUE)
          nativeOutput$weight <- NULL
      }
      else {
          forest.wt.out <- NULL
      }
      if (case.depth != FALSE) {
          if (restore.mode) {
              case.depth.out <- matrix(nativeOutput$caseDepth, c(ntree, n), byrow = TRUE)
              nativeOutput$caseDepth <- NULL
          }
          else {
              case.depth.out <- matrix(nativeOutput$caseDepth, c(ntree, n.newdata), byrow = TRUE)
          }
          nativeOutput$caseDepth <- NULL
      }
      else {
          case.depth.out <- NULL
      }
      n.observed = if (restore.mode) 
          n
      else n.newdata
      if (membership) {
          membership.out <- matrix(nativeOutput$nodeMembership, c(n.observed, ntree))
          nativeOutput$nodeMembership <- NULL
          if (restore.mode) {
              inbag.out <- matrix(nativeOutput$bootMembership, c(n.observed, ntree))
              nativeOutput$bootMembership <- NULL
          }
          else {
              inbag.out <- NULL
          }
          if (ptn.count > 0) {
              ptn.membership.out <- matrix(nativeOutput$pstnMembership, c(n.observed, ntree))
              nativeOutput$pstnMembership <- NULL
          }
          else {
              ptn.membership.out <- NULL
          }
      }
      else {
          membership.out <- NULL
          inbag.out <- NULL
          ptn.membership.out <- NULL
      }
      if (var.used != FALSE) {
          if (var.used == "all.trees") {
              var.used.out <- nativeOutput$varUsed
              names(var.used.out) <- xvar.names
          }
          else {
              var.used.out <- matrix(nativeOutput$varUsed, nrow = ntree, byrow = TRUE)
              colnames(var.used.out) <- xvar.names
          }
          nativeOutput$varUsed <- NULL
      }
      else {
          var.used.out <- NULL
      }
      if (split.depth != FALSE) {
          if (split.depth == "all.trees") {
              split.depth.out <- array(nativeOutput$splitDepth, c(n, n.xvar))
          }
          else {
              split.depth.out <- array(nativeOutput$splitDepth, c(n, n.xvar, ntree))
          }
          nativeOutput$splitDepth <- NULL
      }
      else {
          split.depth.out <- NULL
      }
      rfsrcOutput <- list(call = match.call(), family = family, n = n.observed, ntree = ntree, yvar = (if ((outcome == 
          "train" & restore.mode) | (perf.type != "none")) {
          if (outcome == "train" & restore.mode) amatrix.remove.names(object$yvar) else amatrix.remove.names(yvar.newdata)
      } else NULL), yvar.names = yvar.names, xvar = (if (outcome != "test" & restore.mode) object$xvar else xvar.newdata), 
          xvar.names = xvar.names, leaf.count = nativeOutput$leafCount, proximity = proximity.out, forest = object, 
          forest.wt = forest.wt.out, case.depth = case.depth.out, distance = distance.out, ptn.membership = ptn.membership.out, 
          membership = membership.out, splitrule = splitrule, inbag = inbag.out, var.used = var.used.out, 
          uno.weights = uno.weights.test, imputed.indv = (if (n.miss > 0) imputed.indv else NULL), imputed.data = (if (n.miss > 
              0) imputed.data else NULL), split.depth = split.depth.out, block.size = block.size, perf.type = perf.type, 
          ctime.internal = nativeOutput$cTimeInternal, ctime.external = ctime.external.stop - ctime.external.start)
      nativeOutput$leafCount <- NULL
      remove(object)
      remove(proximity.out)
      remove(forest.wt.out)
      remove(case.depth.out)
      remove(distance.out)
      remove(ptn.membership.out)
      remove(membership.out)
      remove(inbag.out)
      if (n.miss > 0) 
          remove(imputed.indv)
      if (n.miss > 0) 
          remove(imputed.data)
      remove(var.used.out)
      remove(split.depth.out)
      survOutput <- NULL
      classOutput <- NULL
      regrOutput <- NULL
      if (vimp.joint) {
          vimp.count <- 1
      }
      else {
          vimp.count <- length(importance.xvar)
      }
      if (grepl("surv", family)) {
          if ((length(event.info$event.type) > 1) && (splitrule != "l2.impute") && (splitrule != "logrankscore")) {
              coerced.event.count <- length(event.info$event.type)
          }
          else {
              coerced.event.count <- 1
          }
          if (family == "surv") {
              ens.names <- list(NULL, NULL)
              mortality.names <- list(NULL, NULL)
              err.names <- list(NULL, NULL)
              vimp.names <- list(NULL, if (vimp.joint) "joint" else importance.xvar)
          }
          else {
              ens.names <- list(NULL, NULL, c(paste("condCHF.", 1:length(event.info$event.type), sep = "")))
              mortality.names <- list(NULL, paste("event.", 1:length(event.info$event.type), sep = ""))
              cif.names <- list(NULL, NULL, c(paste("CIF.", 1:length(event.info$event.type), sep = "")))
              err.names <- list(c(paste("event.", 1:length(event.info$event.type), sep = "")), NULL)
              vimp.names <- list(paste("event.", 1:length(event.info$event.type), sep = ""), if (vimp.joint) "joint" else importance.xvar)
          }
          chf <- (if (!is.null(nativeOutput$allEnsbCHF)) 
              adrop3d.last(array(nativeOutput$allEnsbCHF, c(n.observed, length(event.info$time.interest), 
                  length(event.info$event.type)), dimnames = ens.names), length(event.info$event.type))
          else NULL)
          nativeOutput$allEnsbCHF <- NULL
          survOutput <- list(chf = chf)
          remove(chf)
          chf.oob <- (if (!is.null(nativeOutput$oobEnsbCHF)) 
              adrop3d.last(array(nativeOutput$oobEnsbCHF, c(n.observed, length(event.info$time.interest), 
                  length(event.info$event.type)), dimnames = ens.names), length(event.info$event.type))
          else NULL)
          nativeOutput$oobEnsbCHF <- NULL
          survOutput = c(survOutput, chf.oob = list(chf.oob))
          remove(chf.oob)
          predicted <- (if (!is.null(nativeOutput$allEnsbMRT)) 
              adrop2d.last(array(nativeOutput$allEnsbMRT, c(n.observed, length(event.info$event.type)), 
                  dimnames = mortality.names), coerced.event.count)
          else NULL)
          nativeOutput$allEnsbMRT <- NULL
          survOutput = c(survOutput, predicted = list(predicted))
          remove(predicted)
          predicted.oob <- (if (!is.null(nativeOutput$oobEnsbMRT)) 
              adrop2d.last(array(nativeOutput$oobEnsbMRT, c(n.observed, length(event.info$event.type)), 
                  dimnames = mortality.names), coerced.event.count)
          else NULL)
          nativeOutput$oobEnsbMRT <- NULL
          survOutput <- c(survOutput, predicted.oob = list(predicted.oob))
          remove(predicted.oob)
          survival <- (if (!is.null(nativeOutput$allEnsbSRV)) 
              matrix(nativeOutput$allEnsbSRV, c(n.observed, length(event.info$time.interest)))
          else NULL)
          nativeOutput$allEnsbSRV <- NULL
          survOutput <- c(survOutput, survival = list(survival))
          remove(survival)
          survival.oob <- (if (!is.null(nativeOutput$oobEnsbSRV)) 
              matrix(nativeOutput$oobEnsbSRV, c(n.observed, length(event.info$time.interest)))
          else NULL)
          nativeOutput$oobEnsbSRV <- NULL
          survOutput <- c(survOutput, survival.oob = list(survival.oob))
          remove(survival.oob)
          cif <- (if (!is.null(nativeOutput$allEnsbCIF)) 
              array(nativeOutput$allEnsbCIF, c(n.observed, length(event.info$time.interest), length(event.info$event.type)), 
                  dimnames = cif.names)
          else NULL)
          nativeOutput$allEnsbCIF <- NULL
          survOutput <- c(survOutput, cif = list(cif))
          remove(cif)
          cif.oob <- (if (!is.null(nativeOutput$oobEnsbCIF)) 
              array(nativeOutput$oobEnsbCIF, c(n.observed, length(event.info$time.interest), length(event.info$event.type)), 
                  dimnames = cif.names)
          else NULL)
          nativeOutput$oobEnsbCIF <- NULL
          survOutput = c(survOutput, cif.oob = list(cif.oob))
          remove(cif.oob)
          if (!is.null(nativeOutput$perfSurv)) {
              err.rate <- adrop2d.first(array(nativeOutput$perfSurv, c(length(event.info$event.type), ntree), 
                  dimnames = err.names), coerced.event.count)
              nativeOutput$perfSurv <- NULL
              if (family == "surv-CR") {
                  survOutput = c(survOutput, err.rate = list(t(err.rate)))
              }
              else {
                  survOutput = c(survOutput, err.rate = list(err.rate))
              }
              remove(err.rate)
          }
          if (!is.null(nativeOutput$blockSurv)) {
              err.block.rate <- adrop2d.first(array(nativeOutput$blockSurv, c(length(event.info$event.type), 
                  floor(ntree/block.size)), dimnames = err.names), coerced.event.count)
              nativeOutput$blockSurv <- NULL
              if (family == "surv-CR") {
                  survOutput = c(survOutput, err.block.rate = list(t(err.block.rate)))
              }
              else {
                  survOutput = c(survOutput, err.block.rate = list(err.block.rate))
              }
              remove(err.block.rate)
          }
          if (!is.null(nativeOutput$vimpSurv)) {
              importance <- adrop2d.first(array(nativeOutput$vimpSurv, c(length(event.info$event.type), 
                  vimp.count), dimnames = vimp.names), coerced.event.count)
              nativeOutput$vimpSurv <- NULL
              if (family == "surv-CR") {
                  survOutput = c(survOutput, importance = list(t(importance)))
              }
              else {
                  survOutput = c(survOutput, importance = list(importance))
              }
              remove(importance)
          }
          survOutput = c(survOutput, list(time.interest = event.info$time.interest, ndead = (if (perf.type != 
              "none") sum((if (restore.mode) yvar[, 2] else yvar.newdata[, 2]) != 0, na.rm = TRUE) else NULL)))
          if (univariate.nomenclature) {
              rfsrcOutput <- c(rfsrcOutput, survOutput)
          }
          else {
              rfsrcOutput <- c(rfsrcOutput, survOutput = list(survOutput))
          }
      }
      else {
          class.index <- which(yvar.types != "R")
          class.count <- length(class.index)
          regr.index <- which(yvar.types == "R")
          regr.count <- length(regr.index)
          if (class.count > 0) {
              classOutput <- vector("list", class.count)
              names(classOutput) <- yvar.names[class.index]
              levels.count <- array(0, class.count)
              levels.names <- vector("list", class.count)
              counter <- 0
              for (i in class.index) {
                  counter <- counter + 1
                  levels.count[counter] <- yvar.nlevels[i]
                  if (yvar.types[i] == "C") {
                    levels.names[[counter]] <- yfactor$levels[[which(yfactor$factor == yvar.names[i])]]
                  }
                  else {
                    levels.names[[counter]] <- yfactor$order.levels[[which(yfactor$order == yvar.names[i])]]
                  }
              }
              tree.offset <- array(1, ntree)
              levels.total <- 0
              if (ntree > 1) {
                  for (i in 1:length(m.target.idx)) {
                    target.idx <- which(class.index == m.target.idx[i])
                    if (length(target.idx) > 0) {
                      levels.total <- levels.total + 1 + levels.count[target.idx]
                    }
                  }
                  tree.offset[2:ntree] <- levels.total
              }
              tree.offset <- cumsum(tree.offset)
              block.offset <- array(1, floor(ntree/block.size))
              if (floor(ntree/block.size) > 1) {
                  block.offset[2:floor(ntree/block.size)] <- levels.total
              }
              block.offset <- cumsum(block.offset)
              vimp.offset <- array(1, vimp.count)
              if (vimp.count > 1) {
                  vimp.offset[2:vimp.count] <- levels.total
              }
              vimp.offset <- cumsum(vimp.offset)
              iter.ensb.start <- 0
              iter.ensb.end <- 0
              for (i in 1:length(m.target.idx)) {
                  target.idx <- which(class.index == m.target.idx[i])
                  if (length(target.idx) > 0) {
                    iter.ensb.start <- iter.ensb.end
                    iter.ensb.end <- iter.ensb.end + (levels.count[target.idx] * n.observed)
                    ens.names <- list(NULL, levels.names[[target.idx]])
                    err.names <- c("all", levels.names[[target.idx]])
                    vimp.names <- list(c("all", levels.names[[target.idx]]), if (vimp.joint) "joint" else importance.xvar)
                    predicted <- (if (!is.null(nativeOutput$allEnsbCLS)) 
                      array(nativeOutput$allEnsbCLS[(iter.ensb.start + 1):iter.ensb.end], c(n.observed, 
                        levels.count[target.idx]), dimnames = ens.names)
                    else NULL)
                    classOutput[[target.idx]] <- list(predicted = predicted)
                    response <- (if (!is.null(predicted)) 
                      get.bayes.rule(predicted, class.relfrq)
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], class = list(response))
                    remove(predicted)
                    remove(response)
                    predicted.oob <- (if (!is.null(nativeOutput$oobEnsbCLS)) 
                      array(nativeOutput$oobEnsbCLS[(iter.ensb.start + 1):iter.ensb.end], c(n.observed, 
                        levels.count[target.idx]), dimnames = ens.names)
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], predicted.oob = list(predicted.oob))
                    response.oob <- (if (!is.null(predicted.oob)) 
                      get.bayes.rule(predicted.oob, class.relfrq)
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], class.oob = list(response.oob))
                    remove(predicted.oob)
                    remove(response.oob)
                    cse.num <- (if (!is.null(nativeOutput$cseClas)) 
                      array(nativeOutput$cseClas[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], cse.num = list(cse.num))
                    remove(cse.num)
                    cse.den <- (if (!is.null(nativeOutput$cseDen)) 
                      array(nativeOutput$cseDen[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], cse.den = list(cse.den))
                    remove(cse.den)
                    if (!is.null(nativeOutput$perfClas)) {
                      err.rate <- array(0, c(1 + levels.count[target.idx], ntree))
                      for (j in 1:(1 + levels.count[target.idx])) {
                        err.rate[j, ] <- nativeOutput$perfClas[tree.offset]
                        tree.offset <- tree.offset + 1
                      }
                      row.names(err.rate) <- err.names
                      classOutput[[target.idx]] <- c(classOutput[[target.idx]], err.rate = list(t(err.rate)))
                      remove(err.rate)
                    }
                    if (!is.null(nativeOutput$blockClas)) {
                      err.block.rate <- array(0, c(1 + levels.count[target.idx], floor(ntree/block.size)))
                      for (j in 1:(1 + levels.count[target.idx])) {
                        err.block.rate[j, ] <- nativeOutput$blockClas[block.offset]
                        block.offset <- block.offset + 1
                      }
                      row.names(err.block.rate) <- err.names
                      classOutput[[target.idx]] <- c(classOutput[[target.idx]], err.block.rate = list(t(err.block.rate)))
                      remove(err.block.rate)
                    }
                    if (!is.null(nativeOutput$vimpClas)) {
                      importance <- array(0, c(1 + levels.count[target.idx], vimp.count), dimnames = vimp.names)
                      for (j in 1:(1 + levels.count[target.idx])) {
                        importance[j, ] <- nativeOutput$vimpClas[vimp.offset]
                        vimp.offset <- vimp.offset + 1
                      }
                      classOutput[[target.idx]] <- c(classOutput[[target.idx]], importance = list(t(importance)))
                      remove(importance)
                    }
                    csv.idx <- array(0, n.observed * n.xvar)
                    j2seq <- (target.idx - 1) * n.observed
                    for (j in 1:n.xvar) {
                      j1seq <- (j - 1) * n.observed
                      csv.idx[(j1seq + 1):(j1seq + n.observed)] <- ((j2seq + j1seq * class.count + 1):(j2seq + 
                        j1seq * class.count + n.observed))
                    }
                    csv.num <- (if (!is.null(nativeOutput$csvClas)) 
                      array(nativeOutput$csvClas[csv.idx], c(n.observed, n.xvar))
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], csv.num = list(csv.num))
                    remove(csv.num)
                    csv.den <- (if (!is.null(nativeOutput$csvDen)) 
                      array(nativeOutput$csvDen, c(n.observed, n.xvar))
                    else NULL)
                    classOutput[[target.idx]] <- c(classOutput[[target.idx]], csv.den = list(csv.den))
                    remove(csv.den)
                  }
              }
              nativeOutput$allEnsbCLS <- NULL
              nativeOutput$oobEnsbCLS <- NULL
              nativeOutput$perfClas <- NULL
              nativeOutput$vimpClas <- NULL
              nativeOutput$blockClas <- NULL
              if (univariate.nomenclature) {
                  if ((class.count == 1) & (regr.count == 0)) {
                    names(classOutput) <- NULL
                    rfsrcOutput <- c(rfsrcOutput, unlist(classOutput, recursive = FALSE))
                  }
                  else {
                    rfsrcOutput <- c(rfsrcOutput, classOutput = list(classOutput))
                  }
              }
              else {
                  rfsrcOutput <- c(rfsrcOutput, classOutput = list(classOutput))
              }
          }
          if (regr.count > 0) {
              regrOutput <- vector("list", regr.count)
              names(regrOutput) <- yvar.names[regr.index]
              tree.offset <- array(1, ntree)
              if (ntree > 1) {
                  tree.offset[2:ntree] <- length(regr.index)
              }
              tree.offset <- cumsum(tree.offset)
              block.offset <- array(1, floor(ntree/block.size))
              if (floor(ntree/block.size) > 1) {
                  block.offset[2:floor(ntree/block.size)] <- length(regr.index)
              }
              block.offset <- cumsum(block.offset)
              vimp.offset <- array(1, vimp.count)
              if (vimp.count > 1) {
                  vimp.offset[2:vimp.count] <- length(regr.index)
              }
              vimp.offset <- cumsum(vimp.offset)
              iter.ensb.start <- 0
              iter.ensb.end <- 0
              iter.qntl.start <- 0
              iter.qntl.end <- 0
              for (i in 1:length(m.target.idx)) {
                  target.idx <- which(regr.index == m.target.idx[i])
                  if (length(target.idx) > 0) {
                    iter.ensb.start <- iter.ensb.end
                    iter.ensb.end <- iter.ensb.end + n.observed
                    iter.qntl.start <- iter.qntl.end
                    iter.qntl.end <- iter.qntl.end + (length(prob) * n.observed)
                    vimp.names <- if (vimp.joint) 
                      "joint"
                    else importance.xvar
                    predicted <- (if (!is.null(nativeOutput$allEnsbRGR)) 
                      array(nativeOutput$allEnsbRGR[(iter.ensb.start + 1):iter.ensb.end], n.observed)
                    else NULL)
                    regrOutput[[target.idx]] <- list(predicted = predicted)
                    remove(predicted)
                    predicted.oob <- (if (!is.null(nativeOutput$oobEnsbRGR)) 
                      array(nativeOutput$oobEnsbRGR[(iter.ensb.start + 1):iter.ensb.end], n.observed)
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], predicted.oob = list(predicted.oob))
                    remove(predicted.oob)
                    cse.num <- (if (!is.null(nativeOutput$cseRegr)) 
                      array(nativeOutput$cseRegr[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], cse.num = list(cse.num))
                    remove(cse.num)
                    cse.den <- (if (!is.null(nativeOutput$cseDen)) 
                      array(nativeOutput$cseDen[(iter.ensb.start + 1):iter.ensb.end], n)
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], cse.den = list(cse.den))
                    remove(cse.den)
                    quantile <- (if (!is.null(nativeOutput$allEnsbQNT)) 
                      array(nativeOutput$allEnsbQNT[(iter.qntl.start + 1):iter.qntl.end], c(n.observed, 
                        length(prob)))
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], quantile = list(quantile))
                    remove(quantile)
                    quantile.oob <- (if (!is.null(nativeOutput$oobEnsbQNT)) 
                      array(nativeOutput$oobEnsbQNT[(iter.qntl.start + 1):iter.qntl.end], c(n.observed, 
                        length(prob)))
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], quantile.oob = list(quantile.oob))
                    remove(quantile.oob)
                    if (!is.null(nativeOutput$perfRegr)) {
                      err.rate <- nativeOutput$perfRegr[tree.offset]
                      tree.offset <- tree.offset + 1
                      regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], err.rate = list(err.rate))
                      remove(err.rate)
                    }
                    if (!is.null(nativeOutput$blockRegr)) {
                      err.block.rate <- nativeOutput$blockRegr[block.offset]
                      block.offset <- block.offset + 1
                      regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], err.block.rate = list(err.block.rate))
                      remove(err.block.rate)
                    }
                    if (!is.null(nativeOutput$vimpRegr)) {
                      importance <- nativeOutput$vimpRegr[vimp.offset]
                      names(importance) <- vimp.names
                      vimp.offset <- vimp.offset + 1
                      regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], importance = list(importance))
                      remove(importance)
                    }
                    csv.idx <- array(0, n.observed * n.xvar)
                    j2seq <- (target.idx - 1) * n.observed
                    for (j in 1:n.xvar) {
                      j1seq <- (j - 1) * n.observed
                      csv.idx[(j1seq + 1):(j1seq + n.observed)] <- ((j2seq + j1seq * regr.count + 1):(j2seq + 
                        j1seq * regr.count + n.observed))
                    }
                    csv.num <- (if (!is.null(nativeOutput$csvRegr)) 
                      array(nativeOutput$csvRegr[csv.idx], c(n.observed, n.xvar))
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], csv.num = list(csv.num))
                    remove(csv.num)
                    csv.den <- (if (!is.null(nativeOutput$csvDen)) 
                      array(nativeOutput$csvDen, c(n.observed, n.xvar))
                    else NULL)
                    regrOutput[[target.idx]] <- c(regrOutput[[target.idx]], csv.den = list(csv.den))
                    remove(csv.den)
                  }
              }
              nativeOutput$allEnsbRGR <- NULL
              nativeOutput$oobEnsbRGR <- NULL
              nativeOutput$allEnsbQNT <- NULL
              nativeOutput$oobEnsbQNT <- NULL
              nativeOutput$perfRegr <- NULL
              nativeOutput$vimpRegr <- NULL
              nativeOutput$blockRegr <- NULL
              if (univariate.nomenclature) {
                  if ((class.count == 0) & (regr.count == 1)) {
                    names(regrOutput) <- NULL
                    rfsrcOutput <- c(rfsrcOutput, unlist(regrOutput, recursive = FALSE))
                  }
                  else {
                    rfsrcOutput <- c(rfsrcOutput, regrOutput = list(regrOutput))
                  }
              }
              else {
                  rfsrcOutput <- c(rfsrcOutput, regrOutput = list(regrOutput))
              }
          }
      }
      class(rfsrcOutput) <- c("rfsrc", "predict", family)
      return(rfsrcOutput)
  }
  get.block.size.bits <- function(block.size, ntree) {
      if (!is.null(block.size)) {
          if (is.logical(block.size)) {
              if (block.size) {
                  block.size <- 1
              }
              else {
                  block.size <- ntree
              }
          }
          else if ((block.size < 1) || (block.size > ntree)) {
              block.size <- ntree
          }
          else {
              block.size <- round(block.size)
          }
      }
      else {
          block.size <- ntree
      }
      return(block.size)
  }
  get.bootstrap.bits <- function(bootstrap) {
      if (bootstrap == "by.root") {
          bootstrap <- 0
      }
      else if (bootstrap == "by.node") {
          bootstrap <- 2^19
      }
      else if (bootstrap == "none") {
          bootstrap <- 2^20
      }
      else if (bootstrap == "by.user") {
          bootstrap <- 2^19 + 2^20
      }
      else {
          stop("Invalid choice for 'bootstrap' option:  ", bootstrap)
      }
      return(bootstrap)
  }
  get.case.depth.bits <- function(case.depth) {
      if (!is.null(case.depth)) {
          if (case.depth == TRUE) {
              case.depth <- 2^11
          }
          else if (case.depth == FALSE) {
              case.depth <- 0
          }
          else {
              stop("Invalid choice for 'case.depth' option:  ", case.depth)
          }
      }
      else {
          stop("Invalid choice for 'case.depth' option:  ", case.depth)
      }
      return(case.depth)
  }
  get.cse.bits <- function(cse) {
      if (!is.null(cse)) {
          if (cse == TRUE) {
              cse <- 2^28
          }
          else if (cse == FALSE) {
              cse <- 0
          }
          else {
              stop("Invalid choice for 'cse' option:  ", cse)
          }
      }
      else {
          stop("Invalid choice for 'cse' option:  ", cse)
      }
      return(cse)
  }
  get.csv.bits <- function(csv) {
      if (!is.null(csv)) {
          if (csv == TRUE) {
              csv <- 2^29
          }
          else if (csv == FALSE) {
              csv <- 0
          }
          else {
              stop("Invalid choice for 'csv' option:  ", csv)
          }
      }
      else {
          stop("Invalid choice for 'csv' option:  ", csv)
      }
      return(csv)
  }
  get.data.pass.bits <- function(data.pass) {
      if (!is.null(data.pass)) {
          if (data.pass == TRUE) {
              data.pass <- 2^15
          }
          else if (data.pass == FALSE) {
              data.pass <- 0
          }
          else {
              stop("Invalid choice for 'data.pass' option:  ", data.pass)
          }
      }
      else {
          stop("Invalid choice for 'data.pass' option:  ", data.pass)
      }
      return(data.pass)
  }
  get.distance.bits <- function(grow.equivalent, distance) {
      if (!is.null(distance)) {
          if (distance == FALSE) {
              dist.bits <- 0
          }
          else if (grow.equivalent == TRUE) {
              if (distance == TRUE) {
                  dist.bits <- 2^20 + 2^21
              }
              else if (distance == "inbag") {
                  dist.bits <- 2^20 + 2^21
              }
              else if (distance == "oob") {
                  dist.bits <- 2^20 + 2^22
              }
              else if (distance == "all") {
                  dist.bits <- 2^20 + 2^21 + 2^22
              }
              else {
                  stop("Invalid choice for 'distance' option:  ", distance)
              }
          }
          else if (grow.equivalent == FALSE) {
              if (distance == TRUE) {
                  dist.bits <- 2^20 + 2^22
              }
              else if (distance == "all") {
                  dist.bits <- 2^20 + 2^22
              }
              else if (distance == "hybrid") {
                  dist.bits <- 2^20 + 2^21 + 2^22
              }
              else {
                  stop("Invalid choice for 'distance' option:  ", distance)
              }
          }
          else {
              stop("Invalid choice for 'grow.equivalent' in distance:  ", grow.equivalent)
          }
      }
      else {
          stop("Invalid choice for 'distance' option:  ", distance)
      }
      return(dist.bits)
  }
  get.ensemble.bits <- function(ensemble) {
      if (ensemble == "oob") {
          ensemble <- 2^1
      }
      else if (ensemble == "inbag") {
          ensemble <- 2^0
      }
      else if (ensemble == "all") {
          ensemble <- 2^0 + 2^1
      }
      else {
          stop("Invalid choice for 'ensemble' option:  ", ensemble)
      }
      return(ensemble)
  }
  get.experimental.bits <- function(experimental) {
      bits <- 0
      for (i in 1:length(experimental)) {
          if (experimental[i] == TRUE) {
              bits <- bits + 2^(i - 1)
          }
      }
      return(bits)
  }
  get.forest.bits <- function(forest) {
      if (!is.null(forest)) {
          if (forest == TRUE) {
              forest <- 2^5
          }
          else if (forest == FALSE) {
              forest <- 0
          }
          else {
              stop("Invalid choice for 'forest' option:  ", forest)
          }
      }
      else {
          stop("Invalid choice for 'forest' option:  ", forest)
      }
      return(forest)
  }
  get.forest.wt.bits <- function(grow.equivalent, bootstrap, weight) {
      if (!is.null(weight)) {
          if (weight == FALSE) {
              wght.bits <- 0
          }
          else if (grow.equivalent == TRUE) {
              if (weight == TRUE) {
                  wght.bits <- 2^0 + 2^1
              }
              else if (weight == "inbag") {
                  wght.bits <- 2^0 + 2^1
              }
              else if (weight == "oob") {
                  wght.bits <- 2^0 + 2^2
              }
              else if (weight == "all") {
                  wght.bits <- 2^0 + 2^1 + 2^2
              }
              else {
                  stop("Invalid choice for 'weight' option:  ", weight)
              }
          }
          else if (grow.equivalent == FALSE) {
              if (weight == TRUE) {
                  wght.bits <- 2^0 + 2^1 + 2^2
              }
              else if (weight == "all") {
                  wght.bits <- 2^0 + 2^1 + 2^2
              }
              else {
                  stop("Invalid choice for 'weight' option:  ", weight)
              }
          }
          else {
              stop("Invalid choice for 'grow.equivalent' in weight:  ", grow.equivalent)
          }
      }
      else {
          stop("Invalid choice for 'weight' option:  ", weight)
      }
      return(wght.bits)
  }
  get.gk.quantile <- function(gk.quantile) {
      if (is.null(gk.quantile)) {
          gk.quantile <- FALSE
      }
      gk.quantile
  }
  get.gk.quantile.bits <- function(gk.quantile) {
      if (gk.quantile) {
          return(2^24)
      }
      else {
          return(0)
      }
  }
  get.importance <- function(importance, perf.type = NULL) {
      if (!is.null(importance)) {
          if (!is.null(perf.type) && perf.type == "gmean" && as.character(importance) == TRUE) {
              importance <- "permute"
          }
          if (importance == TRUE) {
              importance <- "anti"
          }
          else if (importance == FALSE) {
              importance <- "none"
          }
      }
      importance
  }
  get.importance.bits <- function(importance, perf.type = NULL) {
      if (!is.null(importance)) {
          importance <- get.importance(importance, perf.type)
          if (importance == "none") {
              importance <- 0
          }
          else if (importance == "anti") {
              importance <- 2^25 + 0
          }
          else if (importance == "permute") {
              importance <- 2^25 + 2^8
          }
          else if (importance == "random") {
              importance <- 2^25 + 2^9
          }
          else if (importance == "anti.joint") {
              importance <- 2^25 + 2^10 + 0
          }
          else if (importance == "permute.joint") {
              importance <- 2^25 + 2^10 + 2^8
          }
          else if (importance == "random.joint") {
              importance <- 2^25 + 2^10 + 2^9
          }
          else {
              stop("Invalid choice for 'importance' option:  ", importance)
          }
      }
      else {
          stop("Invalid choice for 'importance' option:  ", importance)
      }
      return(importance)
  }
  get.impute.only.bits <- function(impute.only, nMiss) {
      if (impute.only) {
          if (nMiss > 0) {
              return(2^16)
          }
          else {
              stop("Data has no missing values, using 'impute' makes no sense.")
          }
      }
      else {
          return(0)
      }
  }
  get.membership.bits <- function(membership) {
      bits <- 0
      if (!is.null(membership)) {
          if (membership == TRUE) {
              bits <- 2^6
          }
          else if (membership != FALSE) {
              stop("Invalid choice for 'membership' option:  ", membership)
          }
      }
      else {
          stop("Invalid choice for 'membership' option:  ", membership)
      }
      return(bits)
  }
  get.na.action.bits <- function(na.action) {
      if (na.action == "na.omit") {
          na.action <- 0
      }
      else if (na.action == "na.impute" || na.action == "na.random") {
          na.action <- 2^4
      }
      else {
          stop("Invalid choice for 'na.action' option:  ", na.action)
      }
      return(na.action)
  }
  get.perf <- function(perf, impute.only, family) {
      if (impute.only == TRUE) {
          return("none")
      }
      if (family != "class") {
          if (is.null(perf)) {
              return("default")
          }
          perf <- match.arg(perf, c("none", "default", "standard"))
          if (perf == "standard") {
              perf <- "default"
          }
          return(perf)
      }
      if (is.null(perf)) {
          return("default")
      }
      perf <- match.arg(perf, c("none", "default", "standard", "misclass", "brier", "gmean", "g.mean"))
      if (perf == "standard" || perf == "misclass") {
          perf <- "default"
      }
      if (perf == "g.mean") {
          perf <- "gmean"
      }
      perf
  }
  get.perf.bits <- function(perf) {
      if (perf == "default") {
          return(2^2)
      }
      else if (perf == "gmean" || perf == "g.mean") {
          return(2^2 + 2^14)
      }
      else if (perf == "brier") {
          return(2^2 + 2^3)
      }
      else {
          return(0)
      }
  }
  get.proximity.bits <- function(grow.equivalent, proximity) {
      if (!is.null(proximity)) {
          if (proximity == FALSE) {
              prox.bits <- 0
          }
          else if (grow.equivalent == TRUE) {
              if (proximity == TRUE) {
                  prox.bits <- 2^28 + 2^29
              }
              else if (proximity == "inbag") {
                  prox.bits <- 2^28 + 2^29
              }
              else if (proximity == "oob") {
                  prox.bits <- 2^28 + 2^30
              }
              else if (proximity == "all") {
                  prox.bits <- 2^28 + 2^29 + 2^30
              }
              else {
                  stop("Invalid choice for 'proximity' option:  ", proximity)
              }
          }
          else if (grow.equivalent == FALSE) {
              if (proximity == TRUE) {
                  prox.bits <- 2^28 + 2^30
              }
              else if (proximity == "all") {
                  prox.bits <- 2^28 + 2^30
              }
              else if (proximity == "hybrid") {
                  prox.bits <- 2^28 + 2^29 + 2^30
              }
              else {
                  stop("Invalid choice for 'proximity' option:  ", proximity)
              }
          }
          else {
              stop("Invalid choice for 'grow.equivalent' in proximity:  ", grow.equivalent)
          }
      }
      else {
          stop("Invalid choice for 'proximity' option:  ", proximity)
      }
      return(prox.bits)
  }
  get.rfq <- function(rfq) {
      if (is.null(rfq)) {
          rfq <- FALSE
      }
      rfq
  }
  get.rfq.bits <- function(rfq, family) {
      result <- 0
      if (family == "class") {
          if (rfq) {
              result <- 2^15
          }
      }
      return(result)
  }
  get.rf.cores <- function() {
      if (is.null(getOption("rf.cores", NULL))) {
          if (!is.na(as.numeric(Sys.getenv("RF_CORES")))) {
              options(rf.cores = as.integer(Sys.getenv("RF_CORES")))
          }
      }
      if (!is.null(getOption("rf.cores", NULL))) {
          return(getOption("rf.cores"))
      }
      chk <- tolower(Sys.getenv("_R_CHECK_LIMIT_CORES_", ""))
      if (nzchar(chk) && chk != "false") {
          return(2L)
      }
      return(-1L)
  }
  get.samptype.bits <- function(samptype) {
      if (samptype == "swr") {
          bits <- 0
      }
      else if (samptype == "swor") {
          bits <- 2^12
      }
      else {
          stop("Invalid choice for 'samptype' option:  ", samptype)
      }
      return(bits)
  }
  get.seed <- function(seed) {
      if ((is.null(seed)) || (abs(seed) < 1)) {
          seed <- runif(1, 1, 1e+06)
      }
      seed <- -round(abs(seed))
      return(seed)
  }
  get.split.cust.bits <- function(split.cust) {
      if (!is.null(split.cust)) {
          if ((split.cust >= 1) && (split.cust <= 16)) {
              split.cust <- 256 * (split.cust - 1)
          }
          else {
              stop("Invalid choice for 'split.cust' option:  ", split.cust)
          }
      }
      else {
          split.cust <- 0
      }
      return(split.cust)
  }
  get.split.depth.bits <- function(split.depth) {
      if (!is.null(split.depth)) {
          if (split.depth == "all.trees") {
              split.depth <- 2^22
          }
          else if (split.depth == "by.tree") {
              split.depth <- 2^23
          }
          else if (split.depth == FALSE) {
              split.depth <- 0
          }
          else {
              stop("Invalid choice for 'split.depth' option:  ", split.depth)
          }
      }
      else {
          stop("Invalid choice for 'split.depth' option:  ", split.depth)
      }
      return(split.depth)
  }
  get.tdc.rule.bits <- function(tdc.rule) {
      if (is.null(tdc.rule)) {
          result <- 2^24 + 2^25 + 2^26
      }
      else if (tdc.rule == "all") {
          result <- 2^24 + 2^25 + 2^26
      }
      else if (tdc.rule == "time") {
          result <- 2^24
      }
      else if (tdc.rule == "tdx") {
          result <- 2^25
      }
      else if (tdc.rule == "tsx") {
          result <- 2^26
      }
      else if (tdc.rule == "time.and.tsx") {
          result <- 2^24 + 2^26
      }
      else if (tdc.rule == "time.and.tdx") {
          result <- 2^24 + 2^25
      }
      return(result)
  }
  get.terminal.qualts.bits <- function(terminal.qualts) {
      bits <- 0
      if (!is.null(terminal.qualts)) {
          if (terminal.qualts == TRUE) {
              bits <- bits + 2^16
          }
          else if (terminal.qualts != FALSE) {
              stop("Invalid choice for 'terminal.qualts' option:  ", terminal.qualts)
          }
      }
      else {
          stop("Invalid choice for 'terminal.qualts' option:  ", terminal.qualts)
      }
      return(bits)
  }
  get.terminal.quants.bits <- function(terminal.quants) {
      bits <- 0
      if (!is.null(terminal.quants)) {
          if (terminal.quants == TRUE) {
              bits <- bits + 2^18
          }
          else if (terminal.quants != FALSE) {
              stop("Invalid choice for 'terminal.quants' option:  ", terminal.quants)
          }
      }
      else {
          stop("Invalid choice for 'terminal.quants' option:  ", terminal.quants)
      }
      return(bits)
  }
  get.trace.bits <- function(do.trace) {
      if (!is.logical(do.trace)) {
          if (do.trace >= 1) {
              do.trace <- round(do.trace)
          }
          else {
              do.trace <- 0
          }
      }
      else {
          do.trace <- 1 * do.trace
      }
      return(do.trace)
  }
  get.var.used.bits <- function(var.used) {
      if (!is.null(var.used)) {
          if (var.used == "all.trees") {
              var.used <- 2^12
          }
          else if (var.used == "by.tree") {
              var.used <- 2^13
          }
          else if (var.used == FALSE) {
              var.used <- 0
          }
          else {
              stop("Invalid choice for 'var.used' option:  ", var.used)
          }
      }
      else {
          stop("Invalid choice for 'var.used' option:  ", var.used)
      }
      return(var.used)
  }
  is.hidden.cse <- function(user.option) {
      if (is.null(user.option$cse)) {
          FALSE
      }
      else {
          as.logical(as.character(user.option$cse))
      }
  }
  is.hidden.csv <- function(user.option) {
      if (is.null(user.option$csv)) {
          FALSE
      }
      else {
          as.logical(as.character(user.option$csv))
      }
  }
  is.hidden.data.pass <- function(user.option) {
      if (is.null(user.option$data.pass)) {
          FALSE
      }
      else {
          as.logical(as.character(user.option$data.pass))
      }
  }
  is.hidden.experimental <- function(user.option) {
      if (is.null(user.option$experimental)) {
          e <- FALSE
      }
      else {
          e <- as.logical(as.character(user.option$experimental))
      }
      return(e)
  }
  is.hidden.gk.quantile <- function(user.option) {
      if (is.null(user.option$gk.quantile)) {
          NULL
      }
      else {
          as.logical(as.character(user.option$gk.quantile))
      }
  }
  is.hidden.holdout.array <- function(user.option) {
      if (is.null(user.option$holdout.array)) {
          NULL
      }
      else {
          user.option$holdout.array
      }
  }
  is.hidden.holdout.specs <- function(user.option) {
      if (is.null(user.option$holdout.specs)) {
          obj <- NULL
      }
      else {
          obj <- user.option$holdout.specs
      }
      return(obj)
  }
  is.hidden.impute.only <- function(user.option) {
      if (is.null(user.option$impute.only)) {
          FALSE
      }
      else {
          as.logical(as.character(user.option$impute.only))
      }
  }
  is.hidden.mahalanobis.sigma <- function(user.option) {
      if (is.null(user.option$mahalanobis.sigma) & is.null(user.option$sigma)) {
          NULL
      }
      else {
          if (!is.null(user.option$mahalanobis.sigma)) {
              ginverse(user.option$mahalanobis.sigma)
          }
          else {
              ginverse(user.option$sigma)
          }
      }
  }
  is.hidden.prob <- function(user.option) {
      if (is.null(user.option$prob)) {
          NULL
      }
      else {
          prob <- user.option$prob
          sort(prob[prob > 0 & prob < 1])
      }
  }
  is.hidden.prob.epsilon <- function(user.option) {
      if (is.null(user.option$prob.epsilon)) {
          NULL
      }
      else {
          prob.epsilon <- user.option$prob.epsilon
          if ((prob.epsilon <= 0) || (prob.epsilon >= 0.5)) {
              stop("parameter 'prob.epsilon' must be in range (0, 1/2) :  ", prob.epsilon)
          }
          prob.epsilon
      }
  }
  is.hidden.quantile.regr <- function(user.option) {
      if (is.null(user.option$quantile.regr)) {
          FALSE
      }
      else {
          as.logical(as.character(user.option$quantile.regr))
      }
  }
  is.hidden.rfq <- function(user.option) {
      if (is.null(user.option$rfq)) {
          NULL
      }
      else {
          as.logical(as.character(user.option$rfq))
      }
  }
  is.hidden.tdc.rule <- function(user.option) {
      if (is.null(user.option$tdc.rule)) {
          NULL
      }
      else {
          user.option$tdc.rule
      }
  }
  is.hidden.terminal.qualts <- function(user.option) {
      if (is.null(user.option$terminal.qualts)) {
          TRUE
      }
      else {
          as.logical(as.character(user.option$terminal.qualts))
      }
  }
  is.hidden.terminal.quants <- function(user.option, save.memory = FALSE) {
      if (is.null(user.option$terminal.quants)) {
          TRUE & !save.memory
      }
      else {
          as.logical(as.character(user.option$terminal.quants))
      }
  }
  is.hidden.vtry <- function(user.option) {
      if (is.null(user.option$vtry)) {
          0
      }
      else {
          user.option$vtry
      }
  }
  is.hidden.vimp.threshold <- function(user.option) {
      if (is.null(user.option$vimp.threshold)) {
          1
      }
      else {
          user.option$vimp.threshold
      }
  }
  adrop3d.last <- function(x, d, keepColNames = FALSE) {
      if (!is.array(x)) {
          x
      }
      else {
          if (d > 1) {
              x[, , 1:d, drop = FALSE]
          }
          else {
              if (dim(x)[1] == 1) {
                  rbind(x[, , 1, drop = TRUE])
              }
              else {
                  if (dim(x)[2] == 1) {
                    if (keepColNames) {
                      xnew <- cbind(x[, , 1, drop = TRUE])
                      colnames(xnew) <- colnames(x)
                      xnew
                    }
                    else {
                      cbind(x[, , 1, drop = TRUE])
                    }
                  }
                  else {
                    x[, , 1, drop = TRUE]
                  }
              }
          }
      }
  }
  adrop2d.first <- function(x, d, keepColNames = FALSE) {
      if (!is.array(x)) {
          x
      }
      else {
          if (d > 1) {
              x[1:d, , drop = FALSE]
          }
          else {
              x[1, , drop = TRUE]
          }
      }
  }
  adrop2d.last <- function(x, d, keepColNames = FALSE) {
      if (!is.array(x)) {
          x
      }
      else {
          if (d > 1) {
              x[, 1:d, drop = FALSE]
          }
          else {
              x[, 1, drop = TRUE]
          }
      }
  }
  amatrix.remove.names <- function(x) {
      if (!is.null(dim(x)) && ncol(x) == 1) {
          unlist(c(x), use.names = FALSE)
      }
      else {
          x
      }
  }
  finalizeFormula <- function(formula.obj, data) {
      yvar.names <- formula.obj$yvar.names
      subj.names <- formula.obj$subj.names
      all.names <- formula.obj$all.names
      fmly <- formula.obj$family
      ytry <- formula.obj$ytry
      index <- length(yvar.names)
      if (fmly == "surv") {
          if (!is.null(subj.names)) {
              index <- index + 1
          }
      }
      if (length(all.names) <= index) {
          stop("formula is misspecified: total number of variables does not exceed total number of y-variables")
      }
      if (all.names[index + 1] == ".") {
          if (index == 0) {
              xvar.names <- names(data)
          }
          else {
              xvar.names <- names(data)[!is.element(names(data), all.names[1:index])]
          }
      }
      else {
          if (index == 0) {
              xvar.names <- all.names
          }
          else {
              xvar.names <- all.names[-c(1:index)]
          }
          not.specified <- !is.element(xvar.names, names(data))
          if (sum(not.specified) > 0) {
              stop("formula is misspecified, object ", xvar.names[not.specified], " not found")
          }
      }
      return(list(family = fmly, subj.names = subj.names, yvar.names = yvar.names, xvar.names = xvar.names, 
          ytry = ytry))
  }
  finalizeData <- function(fnames, data, na.action, miss.flag = TRUE) {
      data <- data[, is.element(names(data), fnames), drop = FALSE]
      factor.names <- unlist(lapply(data, is.factor))
      if (sum(factor.names) > 0) {
          data[, factor.names] <- data.matrix(data[, factor.names, drop = FALSE])
      }
      if (miss.flag == TRUE && na.action == "na.omit") {
          if (any(is.na(data))) {
              data <- na.omit(data)
          }
      }
      if (miss.flag == TRUE && na.action != "na.omit") {
          nan.names <- sapply(data, function(x) {
              any(is.nan(x))
          })
          if (sum(nan.names) > 0) {
              data[, nan.names] <- data.frame(lapply(which(nan.names), function(j) {
                  x <- data[, j]
                  x[is.nan(x)] <- NA
                  x
              }))
          }
      }
      if (nrow(data) == 0) {
          stop("no records in the NA-processed data: consider using 'na.action=na.impute'")
      }
      logical.names <- unlist(lapply(data, is.logical))
      if (sum(logical.names) > 0) {
          data[, logical.names] <- 1 * data[, logical.names, drop = FALSE]
      }
      character.names <- unlist(lapply(data, is.character))
      if (sum(character.names) > 0) {
          stop("data types cannot be character: please convert all characters to factors")
      }
      return(data)
  }
  get.coerced.survival.fmly <- function(fmly, subj, event.type, splitrule = NULL) {
      if (grepl("surv", fmly)) {
          coerced.fmly <- "surv"
          if (!is.null(splitrule)) {
              if (is.null(subj)) {
                  if ((length(event.type) > 1) && (splitrule != "l2.impute") && (splitrule != "logrankscore")) {
                    coerced.fmly <- "surv-CR"
                  }
              }
              else {
                  coerced.fmly <- "surv-TDC"
              }
          }
          else {
              if (is.null(subj)) {
                  if (length(event.type) > 1) {
                    coerced.fmly <- "surv-CR"
                  }
              }
              else {
                  coerced.fmly <- "surv-TDC"
              }
          }
      }
      else {
          stop("attempt to coerce a non-survival family")
      }
      coerced.fmly
  }
  get.grow.mtry <- function(mtry = NULL, n.xvar, fmly, splitrule = NULL) {
      if (!is.null(mtry)) {
          mtry <- round(mtry)
          if (mtry < 1 | mtry > n.xvar) 
              mtry <- max(1, min(mtry, n.xvar))
      }
      else {
          if (grepl("regr", fmly)) {
              mtry <- max(ceiling(n.xvar/3), 1)
          }
          else {
              mtry <- max(ceiling(sqrt(n.xvar)), 1)
          }
      }
      if (!is.null(splitrule) && splitrule == "random") {
          mtry <- 1
      }
      mtry
  }
  get.grow.nodesize <- function(fmly, nodesize) {
      if (fmly == "surv") {
          if (is.null(nodesize)) {
              nodesize <- 15
          }
      }
      else if (fmly == "surv-CR") {
          if (is.null(nodesize)) {
              nodesize <- 15
          }
      }
      else if (fmly == "surv-TDC") {
          if (is.null(nodesize)) {
              nodesize <- 15
          }
      }
      else if (fmly == "class" | fmly == "class+") {
          if (is.null(nodesize)) {
              nodesize <- 1
          }
      }
      else if (fmly == "regr" | fmly == "regr+") {
          if (is.null(nodesize)) {
              nodesize <- 5
          }
      }
      else if (fmly == "mix+") {
          if (is.null(nodesize)) {
              nodesize <- 3
          }
      }
      else if (fmly == "unsupv") {
          if (is.null(nodesize)) {
              nodesize <- 3
          }
      }
      else if (is.null(nodesize)) {
          stop("family is misspecified")
      }
      nodesize <- round(nodesize)
  }
  get.grow.splitinfo <- function(formula.detail, splitrule, nsplit, event.info) {
      splitrule.names <- c("logrank", "logrankscore", "logrankCR", "random", "mse", "mse.unwt", "mse.hvwt", 
          "gini", "gini.unwt", "gini.hvwt", "unsupv", "unsupv.unwt", "unsupv.hvwt", "mv", "mv.unwt", "mv.hvwt", 
          "custom", "quantile.regr", "la.quantile.regr", "bs.gradient", "auc", "entropy", "sg.regr", "sg.class", 
          "sg.surv", "mahalanobis", "logrankCRGeneral")
      fmly <- formula.detail$family
      cust.idx <- NULL
      splitpass <- FALSE
      if (!is.null(splitrule)) {
          if (grepl("custom", splitrule)) {
              splitrule.idx <- which(splitrule.names == "custom")
              cust.idx <- as.integer(sub("custom", "", splitrule))
              if (is.na(cust.idx)) 
                  cust.idx <- 1
              splitpass <- TRUE
          }
          else if (splitrule == "random") {
              splitrule.idx <- which(splitrule.names == "random")
              splitpass <- TRUE
          }
      }
      if (!splitpass) {
          if (!is.null(splitrule)) {
              splitrule <- match.arg(splitrule, splitrule.names)
          }
          if (grepl("surv", fmly)) {
              if (is.null(splitrule)) {
                  if (event.info$r.dim == 2) {
                    if (length(event.info$event.type) == 1) {
                      splitrule.idx <- which(splitrule.names == "logrank")
                    }
                    else {
                      splitrule.idx <- which(splitrule.names == "logrankCR")
                    }
                  }
                  else if (event.info$r.dim == 3) {
                    splitrule.idx <- which(splitrule.names == "tdc.gradient")
                  }
                  else {
                    stop("Invalid r.dim encountered in split rule:  ", event.info$r.dim)
                  }
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  splitrule.idx <- which(splitrule.names == splitrule)
                  if (length(splitrule.idx) != 1) {
                    stop("Invalid split rule specified for survival:  ", splitrule)
                  }
                  if (event.info$r.dim == 2) {
                    if ((length(event.info$event.type) == 1) & (splitrule.idx == which(splitrule.names == 
                      "logrankCR"))) {
                      stop("Cannot specify logrankCR splitting for right-censored data")
                    }
                    if ((length(event.info$event.type) > 1) & (splitrule.idx == which(splitrule.names == 
                      "logrank"))) {
                      splitrule.idx <- which(splitrule.names == "logrankCRGeneral")
                    }
                  }
                  else if (event.info$r.dim == 3) {
                    if (splitrule.idx != which(splitrule.names == "tdc.gradient")) {
                      stop("Must specify tdc.gradient for time dependent covariates")
                    }
                  }
                  else {
                    stop("Invalid r.dim encountered in split rule:  ", event.info$r.dim)
                  }
              }
          }
          if (fmly == "class") {
              if (is.null(splitrule)) {
                  splitrule.idx <- which(splitrule.names == "gini")
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  if ((splitrule != "gini") & (splitrule != "gini.unwt") & (splitrule != "gini.hvwt") & 
                    (splitrule != "auc") & (splitrule != "entropy") & (splitrule != "sg.class")) {
                    stop("Invalid split rule specified for classification:  ", splitrule)
                  }
                  splitrule.idx <- which(splitrule.names == splitrule)
              }
          }
          if (fmly == "regr") {
              if (is.null(splitrule)) {
                  splitrule.idx <- which(splitrule.names == "mse")
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  if ((splitrule != "mse") & (splitrule != "mse.unwt") & (splitrule != "mse.hvwt") & (splitrule != 
                    "sg.regr") & (splitrule != "la.quantile.regr") & (splitrule != "quantile.regr")) {
                    stop("Invalid split rule specified for regression:  ", splitrule)
                  }
                  splitrule.idx <- which(splitrule.names == splitrule)
              }
          }
          if (fmly == "regr+") {
              if (is.null(splitrule)) {
                  splitrule.idx <- which(splitrule.names == "mv")
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  if ((splitrule != "mv") & (splitrule != "mv.unwt") & (splitrule != "mv.hvwt") & (splitrule != 
                    "mahalanobis")) {
                    stop("Invalid split rule specified for multivariate regression:  ", splitrule)
                  }
                  splitrule.idx <- which(splitrule.names == splitrule)
              }
          }
          if (fmly == "class+") {
              if (is.null(splitrule)) {
                  splitrule.idx <- which(splitrule.names == "mv")
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  if ((splitrule != "mv") & (splitrule != "mv.unwt") & (splitrule != "mv.hvwt")) {
                    stop("Invalid split rule specified for multivariate classsification:  ", splitrule)
                  }
                  splitrule.idx <- which(splitrule.names == splitrule)
              }
          }
          if (fmly == "mix+") {
              if (is.null(splitrule)) {
                  splitrule.idx <- which(splitrule.names == "mv")
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  if ((splitrule != "mv") & (splitrule != "mv.unwt") & (splitrule != "mv.hvwt")) {
                    stop("Invalid split rule specified for mixed multivariate regression:  ", splitrule)
                  }
                  splitrule.idx <- which(splitrule.names == splitrule)
              }
          }
          if (fmly == "unsupv") {
              if (is.null(splitrule)) {
                  splitrule.idx <- which(splitrule.names == "unsupv")
                  splitrule <- splitrule.names[splitrule.idx]
              }
              else {
                  if ((splitrule != "unsupv") & (splitrule != "unsupv.unwt") & (splitrule != "unsupv.hvwt")) {
                    stop("Invalid split rule specified:  ", splitrule)
                  }
                  splitrule.idx <- which(splitrule.names == splitrule)
              }
          }
      }
      if (!is.null(nsplit)) {
          nsplit <- round(nsplit)
          if (nsplit < 0) {
              stop("Invalid nsplit value: set nsplit >= 0")
          }
      }
      else {
          if (splitrule == "random") {
              nsplit <- 1
          }
          else if ((splitrule == "mse") | (splitrule == "mse.unwt") | (splitrule == "mse.hvwt") | (splitrule == 
              "gini") | (splitrule == "gini.unwt") | (splitrule == "gini.hvwt")) {
              nsplit <- 10
          }
          else if ((splitrule == "sg.regr") | (splitrule == "sg.class") | (splitrule == "sg.surv")) {
              nsplit <- 10
          }
          else {
              nsplit <- 10
          }
      }
      splitinfo <- list(name = splitrule, index = splitrule.idx, cust = cust.idx, nsplit = nsplit)
      return(splitinfo)
  }
  get.nmiss <- function(xvar, yvar = NULL) {
      if (!is.null(yvar)) {
          sum(apply(yvar, 1, function(x) {
              any(is.na(x))
          }) | apply(xvar, 1, function(x) {
              any(is.na(x))
          }))
      }
      else {
          sum(apply(xvar, 1, function(x) {
              any(is.na(x))
          }))
      }
  }
  get.weight <- function(weight, n) {
      if (!is.null(weight)) {
          if (any(weight < 0) || length(weight) != n || any(is.na(weight))) {
              stop("Invalid weight vector specified.")
          }
      }
      else {
          weight <- rep(1, n)
      }
      return(weight)
  }
  get.yvar.type <- function(fmly, generic.types, yvar.names) {
      if (fmly == "unsupv") {
          yvar.type <- NULL
      }
      else {
          if (grepl("surv", fmly)) {
              if (length(yvar.names) == 2) {
                  yvar.type <- c("T", "S")
              }
              else {
                  yvar.type <- c("t", "T", "S")
              }
          }
          else {
              yvar.type <- generic.types
          }
      }
      yvar.type
  }
  get.yvar.nlevels <- function(fmly, nlevels, yvar.names, yvar) {
      if (fmly == "unsupv") {
          NULL
      }
      else {
          nlevels
      }
  }
  get.numeric.levels <- function(fmly, nlevels, gvar) {
      gvar.numeric.levels <- lapply(1:length(nlevels), function(nn) {
          if (nlevels[nn] > 0) 
              unique(sort(gvar[, nn]))
          else NULL
      })
      gvar.numeric.levels <- gvar.numeric.levels[!sapply(gvar.numeric.levels, is.null)]
      if (length(gvar.numeric.levels) == 0) 
          gvar.numeric.levels = NULL
      gvar.numeric.levels
  }
  global.prob.assign <- function(prob, prob.epsilon, gk.quantile, quantile.regr, splitrule, n) {
      prob.default <- (1:99)/100
      prob.epsilon.default <- 0.005
      prob.bs.default <- 0.9
      if (quantile.regr || grepl("quantile.regr", splitrule) || gk.quantile) {
          if (!is.null(prob)) {
              if (!is.numeric(prob) || !is.null(dim(prob)) || !length(prob) || any(!is.finite(prob))) {
                  stop("parameter 'prob' must be a nonempty finite numeric vector")
              }
              prob <- sort(prob[prob > 0 & prob < 1])
              if (!length(prob)) 
                  stop("parameter 'prob' is not between (0,1)")
          }
          if (gk.quantile) {
              if (is.null(prob) && is.null(prob.epsilon)) {
                  n <- max(n, 1)
                  prob <- (1:(2 * n))/(2 * n + 1)
                  prob.epsilon <- diff(prob)[1] * 0.99
              }
              else if (is.null(prob) && !is.null(prob.epsilon)) {
                  prob <- prob.default
              }
              else if (!is.null(prob) && is.null(prob.epsilon)) {
                  spacing <- diff(prob)
                  prob.epsilon <- if (length(spacing) && any(spacing > 0)) {
                    mean(spacing) * 0.99
                  }
                  else {
                    prob.epsilon.default
                  }
              }
              else {
              }
          }
          else {
              prob.epsilon <- prob.epsilon.default
              if (is.null(prob)) {
                  prob <- prob.default
              }
          }
          if (gk.quantile && (!is.numeric(prob.epsilon) || length(prob.epsilon) != 1L || !is.finite(prob.epsilon) || 
              prob.epsilon <= 0 || prob.epsilon >= 1)) {
              stop("parameter 'prob.epsilon' must be a finite number in (0,1)")
          }
          if (sum(prob > 0 & prob < 1) == 0) {
              stop("parameter 'prob' is not between (0,1)", prob)
          }
          prob <- sort(prob[prob > 0 & prob < 1])
      }
      if (splitrule == "bs.gradient") {
          if (is.null(prob)) {
              prob <- prob.bs.default
          }
          if (sum(prob > 0 & prob < 1) == 0) {
              stop("parameter 'prob' is not between (0,1)", prob)
          }
          prob <- prob[prob > 0 & prob < 1][1]
      }
      return(list(prob = prob, prob.epsilon = prob.epsilon))
  }
  make.samplesize.function <- function(fraction = 1) {
      f <- paste("x * ", paste(eval(fraction)))
      expr <- parse(text = f)
      function(x) eval(expr, list(x = x))
  }
  parseFormula <- function(f, data, ytry = NULL, coerce.factor = NULL) {
      if (!inherits(f, "formula")) {
          stop("'formula' is not a formula object.")
      }
      if (is.null(data)) {
          stop("'data' is missing.")
      }
      if (!is.data.frame(data)) {
          stop("'data' must be a data frame.")
      }
      fmly <- all.names(f, max.names = 1e+07)[2]
      all.names <- all.vars(f, max.names = 1e+07)
      yvar.names <- all.vars(formula(paste(as.character(f)[2], "~ .")), max.names = 1e+07)
      yvar.names <- yvar.names[-length(yvar.names)]
      subj.names <- NULL
      coerce.factor.org <- coerce.factor
      coerce.factor <- vector("list", 2)
      names(coerce.factor) <- c("xvar.names", "yvar.names")
      if (!is.null(coerce.factor.org)) {
          coerce.factor$yvar.names <- intersect(yvar.names, coerce.factor.org)
          if (length(coerce.factor$yvar.names) == 0) {
              coerce.factor$yvar.names <- NULL
          }
          coerce.factor$xvar.names <- intersect(setdiff(colnames(data), yvar.names), coerce.factor.org)
      }
      if (fmly == "Surv") {
          if ((sum(is.element(yvar.names, names(data))) != 2) && (sum(is.element(yvar.names, names(data))) != 
              4)) {
              stop("Survival formula incorrectly specified.")
          }
          else {
              if (sum(is.element(yvar.names, names(data))) == 4) {
                  subj.names <- yvar.names[1]
                  yvar.names <- yvar.names[-1]
              }
          }
          family <- "surv"
          ytry <- 0
      }
      else if ((fmly == "Multivar" || fmly == "cbind") && length(yvar.names) > 1) {
          if (sum(is.element(yvar.names, names(data))) < length(yvar.names)) {
              stop("Multivariate formula incorrectly specified: y's listed in formula are not in data.")
          }
          Y <- data[, yvar.names, drop = FALSE]
          logical.names <- unlist(lapply(Y, is.logical))
          if (sum(logical.names) > 0) {
              Y[, logical.names] <- 1 * Y[, logical.names, drop = FALSE]
          }
          if ((sum(unlist(lapply(Y, is.factor))) + length(coerce.factor$yvar.names)) == length(yvar.names)) {
              family <- "class+"
          }
          else if ((sum(unlist(lapply(Y, is.factor))) + length(coerce.factor$yvar.names)) == 0) {
              family <- "regr+"
          }
          else if (((sum(unlist(lapply(Y, is.factor))) + length(coerce.factor$yvar.names)) > 0) && ((sum(unlist(lapply(Y, 
              is.factor))) + length(coerce.factor$yvar.names)) < length(yvar.names))) {
              family <- "mix+"
          }
          else {
              stop("y-outcomes must be either real or factors in multivariate forests.")
          }
          if (!is.null(ytry)) {
              if ((ytry < 1) || (ytry > length(yvar.names))) {
                  stop("invalid value for ytry:  ", ytry)
              }
          }
          else {
              ytry <- length(yvar.names)
          }
      }
      else if (fmly == "Unsupervised") {
          if (length(yvar.names) != 0) {
              stop("Unsupervised forests require no y-responses")
          }
          family <- "unsupv"
          yvar.names <- NULL
          temp <- gsub(fmly, "", as.character(f)[2])
          temp <- gsub("\\(|\\)", "", temp)
          ytry <- as.integer(temp)
          if (is.na(ytry)) {
              ytry <- 1
          }
          else {
              if (ytry <= 0) {
                  stop("Unsupervised forests require positive ytry value")
              }
          }
      }
      else {
          if (sum(is.element(yvar.names, names(data))) != 1) {
              stop("formula is incorrectly specified.")
          }
          Y <- data[, yvar.names]
          if (is.logical(Y)) {
              Y <- as.numeric(Y)
          }
          if (!(is.factor(Y) | is.numeric(Y))) {
              stop("the y-outcome must be either real or a factor.")
          }
          if (is.factor(Y) || length(coerce.factor$yvar.names) == 1) {
              family <- "class"
          }
          else {
              family <- "regr"
          }
          ytry <- 1
      }
      return(list(all.names = all.names, family = family, subj.names = subj.names, yvar.names = yvar.names, 
          ytry = ytry, coerce.factor = coerce.factor))
  }
  parseMissingData <- function(formula.obj, data) {
      yvar.names <- formula.obj$yvar.names
      if (length(yvar.names) > 0) {
          resp <- data[, yvar.names, drop = FALSE]
          col.resp.na <- unlist(lapply(data[, yvar.names, drop = FALSE], is.all.na))
          if (any(col.resp.na)) {
              stop("All records are missing for one (or more) yvar(s)")
          }
      }
      colPt <- unlist(lapply(data, is.all.na))
      if (sum(colPt) > 0 && sum(colPt) >= (ncol(data) - length(yvar.names))) {
          stop("All x-variables have all missing data:  analysis not meaningful.")
      }
      data <- data[, !colPt, drop = FALSE]
      rowPt <- apply(data, 1, is.all.na)
      if (sum(rowPt) == nrow(data)) {
          stop("Rows of the data have all missing data:  analysis not meaningful.")
      }
      data <- data[!rowPt, , drop = FALSE]
      return(data)
  }
  extract.factor <- function(dat, generic.names = NULL) {
      generic.types <- gfactor <- gfactor.order <- gfactor.levels <- gfactor.order.levels <- NULL
      target.names <- if (is.null(generic.names)) 
          names(dat)
      else generic.names
      nlevels <- rep(0, length(target.names))
      gfactor <- names(dat)[vapply(dat, is.factor.not.ordered, logical(1))]
      gfactor.order <- names(dat)[vapply(dat, is.ordered, logical(1))]
      if (!is.null(generic.names)) {
          gfactor <- intersect(gfactor, generic.names)
          gfactor.order <- intersect(gfactor.order, generic.names)
      }
      if (length(gfactor) > 0) {
          gfactor.levels <- lapply(gfactor, function(nm) levels(dat[[nm]]))
          nlevels[match(gfactor, target.names)] <- lengths(gfactor.levels)
      }
      if (length(gfactor.order) > 0) {
          gfactor.order.levels <- lapply(gfactor.order, function(nm) levels(dat[[nm]]))
          nlevels[match(gfactor.order, target.names)] <- lengths(gfactor.order.levels)
      }
      if (!is.null(generic.names)) {
          generic.types <- rep("R", length(generic.names))
          if (length(gfactor) > 0) {
              generic.types[match(gfactor, generic.names)] <- "C"
          }
          if (length(gfactor.order) > 0) {
              generic.types[match(gfactor.order, generic.names)] <- "I"
          }
      }
      else {
          generic.types <- rep("R", ncol(dat))
          if (length(gfactor) > 0) {
              generic.types[match(gfactor, names(dat))] <- "C"
          }
          if (length(gfactor.order) > 0) {
              generic.types[match(gfactor.order, names(dat))] <- "I"
          }
      }
      if (is.null(gfactor) & is.null(gfactor.order)) {
          return(NULL)
      }
      else {
          return(list(factor = gfactor, order = gfactor.order, levels = gfactor.levels, order.levels = gfactor.order.levels, 
              nlevels = nlevels, generic.types = generic.types))
      }
  }
  map.factor <- function(gvar, gfactor) {
      if (is.null(gfactor)) 
          return(gvar)
      cn <- colnames(gvar)
      if (length(gfactor$factor) > 0) {
          idx <- match(gfactor$factor, cn)
          new_cols <- lapply(seq_along(idx), function(k) {
              j <- idx[k]
              levs <- gfactor$levels[[k]]
              codes <- gvar[[j]]
              factor.k <- levs[codes]
              labels.k <- levs[sort(unique(codes))]
              gk <- factor(factor.k, labels = labels.k, levels = labels.k, exclude = NULL)
              if (length(setdiff(levs, labels.k)) > 0) {
                  gk <- factor(as.character(gk), levels = levs)
              }
              gk
          })
          gvar[idx] <- new_cols
      }
      if (length(gfactor$order) > 0) {
          idx <- match(gfactor$order, cn)
          new_cols <- lapply(seq_along(idx), function(k) {
              j <- idx[k]
              levs <- gfactor$order.levels[[k]]
              codes <- gvar[[j]]
              factor.k <- levs[codes]
              labels.k <- levs[sort(unique(codes))]
              gk <- factor(factor.k, labels = labels.k, levels = labels.k, exclude = NULL, ordered = TRUE)
              if (length(setdiff(levs, labels.k)) > 0) {
                  gk <- factor(as.character(gk), levels = levs, ordered = TRUE)
              }
              gk
          })
          gvar[idx] <- new_cols
      }
      gvar
  }
  rm.na.levels <- function(dat, xvar.names = NULL) {
      factor.names <- names(dat)[vapply(dat, is.factor, logical(1))]
      if (!is.null(xvar.names)) 
          factor.names <- intersect(factor.names, xvar.names)
      if (length(factor.names) > 0) {
          levels.na.pt <- vapply(factor.names, function(nm) {
              any(levels(dat[[nm]]) == "NA", na.rm = TRUE)
          }, logical(1))
          if (any(levels.na.pt)) {
              fn <- factor.names[levels.na.pt]
              idx <- match(fn, names(dat))
              new_cols <- lapply(fn, function(nm) {
                  x <- dat[[nm]]
                  levels(x)[levels(x) == "NA"] <- NA
                  x
              })
              dat[idx] <- new_cols
          }
      }
      dat
  }
  get.bayes.rule <- function(prob, class.relfrq = NULL) {
      class.labels <- colnames(prob)
      if (is.null(class.relfrq)) {
          factor(class.labels[apply(prob, 1, function(x) {
              if (!all(is.na(x))) {
                  resample(which(x == max(x, na.rm = TRUE)), 1)
              }
              else {
                  NA
              }
          })], levels = class.labels)
      }
      else {
          minority <- which.min(class.relfrq)
          majority <- setdiff(1:2, minority)
          rfq.rule <- rep(majority, nrow(prob))
          rfq.rule[prob[, minority] >= min(class.relfrq, na.rm = TRUE)] <- minority
          factor(class.labels[rfq.rule], levels = class.labels)
      }
  }
  get.grow.event.info <- function(yvar, fmly, need.deaths = TRUE, ntime = NULL) {
      if (grepl("surv", fmly)) {
          if (dim(yvar)[2] == 2) {
              r.dim <- 2
              time <- yvar[, 1]
              cens <- yvar[, 2]
              start.time <- NULL
              if (!all(floor(cens) == abs(cens), na.rm = TRUE)) {
                  stop("for survival families censoring variable must be coded as a non-negative integer (perhaps the formula is set incorrectly?)")
              }
              if (need.deaths && (all(na.omit(cens) == 0))) {
                  stop("no deaths in data!")
              }
              event.type <- unique(na.omit(cens))
              if (sum(event.type >= 0) != length(event.type)) {
                  stop("censoring variable must be coded as NA, 0, or greater than 0.")
              }
              event <- na.omit(cens)[na.omit(cens) > 0]
              event.type <- unique(event)
              nonMissingOutcome <- which(!is.na(cens) & !is.na(time))
              nonMissingDeathFlag <- (cens[nonMissingOutcome] != 0)
              time.interest <- sort(unique(time[nonMissingOutcome[nonMissingDeathFlag]]))
              if (!is.null(ntime) && !((length(ntime) == 1) && ntime == 0)) {
                  if (length(ntime) == 1 && length(time.interest) > ntime) {
                    time.interest <- time.interest[unique(round(seq.int(1, length(time.interest), length.out = ntime)))]
                  }
                  if (length(ntime) > 1) {
                    time.interest <- unique(sapply(ntime, function(tt) {
                      time.interest[max(1, sum(tt >= time.interest, na.rm = TRUE))]
                    }))
                  }
              }
          }
          else {
              r.dim <- 3
              start.time <- yvar[, 1]
              time <- yvar[, 2]
              cens <- yvar[, 3]
              if (!all(floor(cens) == abs(cens), na.rm = TRUE)) {
                  stop("for survival families censoring variable must be coded as a non-negative integer (perhaps the formula is set incorrectly?)")
              }
              if (need.deaths && (all(na.omit(cens) == 0))) {
                  stop("no deaths in data!")
              }
              if (!all(na.omit(time) >= 0)) {
                  stop("time must be  positive")
              }
              event.type <- unique(na.omit(cens))
              if (sum(event.type >= 0) != length(event.type)) {
                  stop("censoring variable must be coded as NA, 0, or greater than 0.")
              }
              event <- na.omit(cens)[na.omit(cens) > 0]
              event.type <- unique(event)
              nonMissingOutcome <- which(!is.na(cens) & !is.na(time))
              nonMissingDeathFlag <- (cens[nonMissingOutcome] != 0)
              time.interest <- sort(unique(time[nonMissingOutcome[nonMissingDeathFlag]]))
              if (!is.null(ntime) && !((length(ntime) == 1) && ntime == 0)) {
                  if (length(ntime) == 1 && length(time.interest) > ntime) {
                    time.interest <- seq(0, min(1, max(time[nonMissingOutcome])), length = ntime)
                    time.interest <- time.interest[time.interest > 0]
                  }
                  if (length(ntime) > 1) {
                    time.pt <- ntime <= min(1, max(time[nonMissingOutcome])) & ntime > 0
                    if (sum(time.pt) == 0) {
                      stop("the ntime vector supplied must be between [0,1]:", ntime)
                    }
                    time.interest <- sort(unique(ntime[time.pt]))
                  }
              }
          }
      }
      else {
          if ((fmly == "regr+") | (fmly == "class+") | (fmly == "mix+")) {
              r.dim <- dim(yvar)[2]
          }
          else {
              if (fmly == "unsupv") {
                  r.dim <- 0
              }
              else {
                  r.dim <- 1
              }
          }
          event <- event.type <- cens <- time.interest <- cens <- time <- start.time <- NULL
      }
      return(list(event = event, event.type = event.type, cens = cens, time.interest = time.interest, time = time, 
          start.time = start.time, r.dim = r.dim))
  }
  get.uno.weights.train <- function(time, status, gmin = "auto", ess_frac = 0.2, ess_min = 20L, eps = 1e-12, 
      eps_keep = .Machine$double.eps, drop_if_G0 = FALSE, return_fit = TRUE) {
      stopifnot(length(time) == length(status))
      fit <- km_censor_fit(time, status)
      G_gate <- uno_Ghat_minus_predict(fit$time, fit$G, time)
      if (is.character(gmin)) {
          gmin <- match.arg(gmin, c("auto", "none"))
          if (gmin == "none") {
              gmin_used <- 0
              ginfo <- list(gmin = 0)
          }
          else {
              ev <- !is.na(status) & (as.integer(status) != 0L) & !is.na(G_gate)
              ginfo <- uno_choose_gmin_auto(G_gate[ev], eps = eps, ess_frac = ess_frac, ess_min = ess_min)
              gmin_used <- ginfo$gmin
          }
      }
      else {
          gmin_used <- as.numeric(gmin)[1L]
          if (!is.finite(gmin_used) || gmin_used < 0) 
              gmin_used <- 0
          ginfo <- list(gmin = gmin_used)
      }
      miss <- is.na(time) | is.na(status)
      G_gate[miss] <- NA_real_
      w <- rep(0, length(time))
      ok <- !is.na(G_gate)
      if (!drop_if_G0) {
          keep <- ok & (G_gate >= gmin_used)
          drop <- ok & !keep
          if (any(keep)) {
              Gsafe <- pmax(G_gate[keep], eps)
              w[keep] <- 1/(Gsafe * Gsafe)
          }
          if (any(drop)) {
              w[drop] <- eps_keep
          }
      }
      else {
          keep <- ok & (G_gate >= gmin_used) & (G_gate > eps)
          drop <- ok & !keep
          if (any(keep)) {
              Gsafe <- pmax(G_gate[keep], eps)
              w[keep] <- 1/(Gsafe * Gsafe)
          }
          if (any(drop)) {
              w[drop] <- eps_keep
          }
      }
      fit$gmin <- gmin_used
      fit$eps_keep <- eps_keep
      fit$gmin_info <- ginfo
      if (return_fit) {
          return(list(weight = w, Ghat_minus = G_gate, fit = fit))
      }
      w
  }
  holdout.vimp.rfsrc <- function(formula, data, ntree = function(p, vtry) {
      1000 * p/vtry
  }, nsplit = 10, ntime = 50, sampsize = function(x) {
      x * 0.632
  }, samptype = "swor", block.size = 10, vtry = 1, ...) {
      dots <- list(...)
      dots$formula <- dots$data <- dots$ntree <- dots$nsplit <- dots$ntime <- dots$samp <- dots$sampsize <- dots$samptype <- dots$block.size <- dots$importance <- NULL
      dots$terminal.qualts <- FALSE
      p <- length(rfsrc(formula, data, nodedepth = 1, ntime = 1, ntree = 1, splitrule = "random")$xvar.names)
      if (!is.function(ntree) && !is.numeric(ntree)) {
          stop("ntree must be a function or number specifying requested number of grow trees")
      }
      if (is.function(ntree)) {
          if (!is.list(vtry)) {
              ntree <- ntree(p, vtry)
          }
          else {
              xvar <- unlist(vtry[1])
              if (any(xvar < 1) | any(xvar > p)) {
                  stop("x-variables specified in vtry should be integer values between 1 and p=number of features")
              }
              joint <- unlist(vtry[2])
              if (!is.logical(joint)) {
                  stop("joint vimp in vtry must be specified as being either TRUE or FALSE")
              }
              if (!joint) {
                  ntree <- ntree(length(xvar), 1)
              }
              else {
                  if (length(xvar) == p) {
                    stop("number of hold out variables for joint analysis must be less than number of features")
                  }
                  ntree <- ntree(1, 1)
              }
          }
      }
      holdout.specs <- get.holdout.specs(vtry, p, ntree, block.size, mode = "baseline")
      seed <- dots$seed
      dots$seed <- NULL
      seed <- get.seed(seed)
      base.obj <- do.call(rfsrc, c(list(formula = formula, data = data, ntree = ntree, nsplit = nsplit, 
          ntime = ntime, sampsize = sampsize, samptype = samptype, holdout.specs = holdout.specs, importance = FALSE, 
          forest = FALSE, terminal.qualts = FALSE, seed = seed), dots))
      holdout.specs <- switch.holdout.specs(holdout.specs, "holdout")
      hold.obj <- do.call(rfsrc, c(list(formula = formula, data = data, ntree = ntree, nsplit = nsplit, 
          ntime = ntime, sampsize = sampsize, samptype = samptype, holdout.specs = holdout.specs, importance = FALSE, 
          forest = FALSE, terminal.qualts = FALSE, seed = seed), dots))
      mv.flag <- FALSE
      if ((class(base.obj)[3] == "regr+") | (class(base.obj)[3] == "class+") | (class(base.obj)[3] == "mix+")) {
          mv.flag <- TRUE
          hvimp <- list()
          if (length(base.obj$regrOutput) > 0) {
              hvimp$regrOutput <- lapply(1:length(base.obj$regrOutput), function(i) {
                  hv <- sapply(1:length(base.obj$regrOutput[[i]]$holdout.vimp), function(j) {
                    mean(hold.obj$regrOutput[[i]]$holdout.vimp[[j]] - base.obj$regrOutput[[i]]$holdout.vimp[[j]], 
                      na.rm = TRUE)
                  })
                  names(hv) <- names(base.obj$regrOutput[[i]]$holdout.vimp)
                  hv
              })
              names(hvimp$regrOutput) <- names(base.obj$regrOutput)
          }
          if (length(base.obj$classOutput) > 0) {
              hvimp$classOutput <- lapply(1:length(base.obj$classOutput), function(i) {
                  yval.i <- colnames(base.obj$classOutput[[i]]$predicted)
                  hv <- do.call(rbind, lapply(1:length(base.obj$classOutput[[i]]$holdout.vimp), function(j) {
                    if (!is.null(dim(base.obj$classOutput[[i]]$holdout.vimp[[j]]))) {
                      rowMeans(hold.obj$classOutput[[i]]$holdout.vimp[[j]] - base.obj$classOutput[[i]]$holdout.vimp[[j]], 
                        na.rm = TRUE)
                    }
                    else {
                      rep(NA, length(yval.i) + 1)
                    }
                  }))
                  colnames(hv) <- c("all", yval.i)
                  rownames(hv) <- names(base.obj$classOutput[[i]]$holdout.vimp)
                  hv
              })
              names(hvimp$classOutput) <- names(base.obj$classOutput)
          }
      }
      else if (class(base.obj)[3] == "regr") {
          hvimp <- sapply(1:length(base.obj$holdout.vimp), function(j) {
              if (!is.null(base.obj$holdout.vimp[[j]])) {
                  mean(hold.obj$holdout.vimp[[j]] - base.obj$holdout.vimp[[j]], na.rm = TRUE)
              }
              else {
                  NA
              }
          })
          names(hvimp) <- names(base.obj$holdout.vimp)
      }
      else if (class(base.obj)[3] == "class") {
          yval <- levels(base.obj$yvar)
          hvimp <- do.call(rbind, lapply(1:length(base.obj$holdout.vimp), function(j) {
              if (!is.null(dim(base.obj$holdout.vimp[[j]]))) {
                  rowMeans(hold.obj$holdout.vimp[[j]] - base.obj$holdout.vimp[[j]], na.rm = TRUE)
              }
              else {
                  rep(NA, length(yval) + 1)
              }
          }))
          colnames(hvimp) <- c("all", yval)
          rownames(hvimp) <- names(base.obj$holdout.vimp)
      }
      else if (class(base.obj)[3] == "surv") {
          hvimp <- sapply(1:length(base.obj$holdout.vimp), function(j) {
              if (!is.null(base.obj$holdout.vimp[[j]])) {
                  mean(hold.obj$holdout.vimp[[j]] - base.obj$holdout.vimp[[j]], na.rm = TRUE)
              }
              else {
                  rep(NA)
              }
          })
          names(hvimp) <- names(base.obj$holdout.vimp)
      }
      else if (class(base.obj)[3] == "surv-CR") {
          hvimp <- do.call(rbind, lapply(1:length(base.obj$holdout.vimp), function(j) {
              if (!is.null(dim(base.obj$holdout.vimp[[j]]))) {
                  rowMeans(hold.obj$holdout.vimp[[j]] - base.obj$holdout.vimp[[j]], na.rm = TRUE)
              }
              else {
                  rep(NA, length(base.obj$holdout.vimp))
              }
          }))
          colnames(hvimp) <- paste("event.", 1:length(get.event.info(base.obj)$event.type), sep = "")
          rownames(hvimp) <- names(base.obj$holdout.vimp)
      }
      rO <- list()
      if (mv.flag) {
          rO$baseline <- rO$holdout <- rO$importance <- list()
          if (length(base.obj$regrOutput) > 0) {
              rO$baseline$regrOutput <- lapply(base.obj$regrOutput, function(o) {
                  o$holdout.vimp
              })
              rO$holdout$regrOutput <- lapply(hold.obj$regrOutput, function(o) {
                  o$holdout.vimp
              })
              rO$importance$regrOutput <- hvimp$regrOutput
          }
          if (length(base.obj$classOutput) > 0) {
              rO$baseline$classOutput <- lapply(base.obj$classOutput, function(o) {
                  o$holdout.vimp
              })
              rO$holdout$classOutput <- lapply(hold.obj$classOutput, function(o) {
                  o$holdout.vimp
              })
              rO$importance$classOutput <- hvimp$classOutput
          }
      }
      else {
          rO$baseline <- base.obj$holdout.vimp
          rO$holdout <- hold.obj$holdout.vimp
          rO$importance <- hvimp
      }
      return(invisible(rO))
  }
  get.partial.bits <- function(partial.length) {
      if (!is.null(partial.length)) {
          if (partial.length > 0) {
              bits <- 2^14
          }
          else if (partial.length == 0) {
              bits <- 0
          }
          else {
              stop("Invalid choice for 'partial.length' option:  ", partial.length)
          }
      }
      else {
          stop("Invalid choice for 'partial.length' option:  ", partial.length)
      }
      return(bits)
  }
  get.cr.bits <- function(fmly) {
      if (fmly == "surv-CR") {
          return(2^21)
      }
      else {
          return(0)
      }
  }
  get.data.pass.predict.bits <- function(data.pass) {
      if (!is.null(data.pass)) {
          if (data.pass == TRUE) {
              data.pass <- 2^27
          }
          else if (data.pass == FALSE) {
              data.pass <- 0
          }
          else {
              stop("Invalid choice for 'data.pass' option:  ", data.pass)
          }
      }
      else {
          stop("Invalid choice for 'data.pass' option:  ", data.pass)
      }
      return(data.pass)
  }
  get.jitt.bits <- function(jitt) {
      if (!is.null(jitt)) {
          if (jitt == TRUE) {
              jitt <- 2^23
          }
          else if (jitt == FALSE) {
              jitt <- 0
          }
          else {
              stop("Invalid choice for 'jitt' option:  ", jitt)
          }
      }
      else {
          stop("Invalid choice for 'jitt' option:  ", jitt)
      }
      return(jitt)
  }
  get.outcome.bits <- function(outcome) {
      if (outcome == "train") {
          outcome <- 0
      }
      else if (outcome == "test") {
          outcome <- 2^17
      }
      else {
          stop("Invalid choice for 'outcome' option:  ", outcome)
      }
      return(outcome)
  }
  get.terminal.qualts.predict.bits <- function(incoming.flag) {
      bits <- 2^16
      if (!is.null(incoming.flag)) {
          if (incoming.flag == TRUE) {
              bits <- bits + 2^17
          }
      }
      else {
          stop("Invalid choice for 'incoming.flag':  ", incoming.flag)
      }
      return(bits)
  }
  get.terminal.quants.predict.bits <- function(incoming.flag) {
      bits <- 2^18
      if (!is.null(incoming.flag)) {
          if (incoming.flag == TRUE) {
              bits <- bits + 2^19
          }
      }
      else {
          stop("Invalid choice for 'incoming.flag':  ", incoming.flag)
      }
      return(bits)
  }
  get.tree.index <- function(get.tree, ntree) {
      if (is.null(get.tree)) {
          rep(1, ntree)
      }
      else {
          pt <- get.tree >= 1 & get.tree <= ntree
          if (sum(pt) > 0) {
              get.tree <- get.tree[pt]
              get.tree.temp <- rep(0, ntree)
              get.tree.temp[get.tree] <- 1
              get.tree.temp
          }
          else {
              rep(1, ntree)
          }
      }
  }
  is.forest.missing <- function(object) {
      if (is.null(object$forest$forest)) {
          is.null(object$forest)
      }
      else {
          !object$forest$forest
      }
  }
  is.hidden.jitt <- function(user.option, importance, na.action = "na.omit", anonymous = FALSE, partial = FALSE) {
      if (na.action == "na.random") {
          return(TRUE)
      }
      if (na.action == "na.impute" && !anonymous) {
          return(FALSE)
      }
      if (is.null(user.option$jitt)) {
          if (partial || importance == "permute" || importance == "permute.joint") {
              FALSE
          }
          else {
              TRUE
          }
      }
      else {
          as.logical(as.character(user.option$jitt))
      }
  }
  data.matrix <- function(x) {
      as.data.frame(lapply(x, function(xi) {
          if (is.integer(xi) || is.numeric(xi)) {
              xi
          }
          else if (is.logical(xi) || is.factor(xi)) {
              as.integer(xi)
          }
          else {
              as.numeric(xi)
          }
      }))
  }
  get.importance.xvar <- function(importance.xvar, importance, object) {
      if (!is.null(importance)) {
          if (missing(importance.xvar) || is.null(importance.xvar)) {
              importance.xvar <- object$xvar.names
          }
          else {
              importance.xvar <- unique(importance.xvar)
              importance.xvar <- intersect(importance.xvar, object$xvar.names)
          }
          if (length(importance.xvar) == 0) {
              stop("xvar names do not match object xvar matrix")
          }
      }
      else {
          importance.xvar <- NULL
      }
      return(importance.xvar)
  }
  get.marginal.xvar <- function(marginal.xvar, object) {
      if (missing(marginal.xvar) | is.null(marginal.xvar)) {
          marginal.xvar <- NULL
      }
      else {
          marginal.xvar <- unique(marginal.xvar)
          marginal.xvar <- intersect(marginal.xvar, object$xvar.names)
          if (length(marginal.xvar) == 0) {
              stop("marginal xvar names must be a subset of xvar names")
          }
      }
      return(marginal.xvar)
  }
  get.outcome.target <- function(family, yvar.names, outcome.target) {
      if (family == "regr" | family == "regr+" | family == "class" | family == "class+" | family == "mix+") {
          if (is.null(outcome.target)) {
              outcome.target <- yvar.names
          }
          outcome.target <- unique(outcome.target)
          outcome.target <- intersect(outcome.target, yvar.names)
          if (length(outcome.target) == 0) {
              stop("yvar target names do not match object yvar names")
          }
          outcome.target <- match(outcome.target, yvar.names)
      }
      else {
          outcome.target <- 0
      }
  }
  is.all.na <- function(x) {
      all(is.na(x))
  }
  resample <- function(x, size, ...) {
      if (length(x) <= 1) {
          if (!missing(size) && size == 0) 
              x[FALSE]
          else x
      }
      else {
          sample(x, size, ...)
      }
  }
  check.factor <- function(test, gfactor, ignore = TRUE) {
      if (is.null(gfactor)) 
          return(test)
      cn <- colnames(test)
      if (length(gfactor$factor) > 0) {
          idx <- match(gfactor$factor, cn)
          new_cols <- lapply(seq_along(idx), function(k) {
              j <- idx[k]
              fk.test <- as.character(test[[j]])
              levs <- gfactor$levels[[k]]
              if (!all(is.element(unique(stats::na.omit(fk.test)), levs))) {
                  if (!ignore) {
                    stop("levels of factors in test data do not match those in training data\n")
                  }
                  fake.level.k <- paste0(tail(levs, 1), "+")
                  fk.test[!is.element(fk.test, levs)] <- fake.level.k
                  factor(fk.test, levels = c(levs, fake.level.k), exclude = NULL)
              }
              else {
                  factor(fk.test, levels = levs, exclude = NULL)
              }
          })
          test[idx] <- new_cols
      }
      if (length(gfactor$order) > 0) {
          idx <- match(gfactor$order, cn)
          new_cols <- lapply(seq_along(idx), function(k) {
              j <- idx[k]
              fk.test <- as.character(test[[j]])
              levs <- gfactor$order.levels[[k]]
              if (!all(is.element(unique(stats::na.omit(fk.test)), levs))) {
                  if (!ignore) {
                    stop("levels of ordered factors in test data do not match those in training data\n")
                  }
                  fake.level.k <- paste0(tail(levs, 1), "+")
                  fk.test[!is.element(fk.test, levs)] <- fake.level.k
                  factor(fk.test, levels = c(levs, fake.level.k), ordered = TRUE)
              }
              else {
                  factor(fk.test, levels = levs, ordered = TRUE)
              }
          })
          test[idx] <- new_cols
      }
      test
  }
  is.factor.not.ordered <- function(x) {
      is.factor(x) && !is.ordered(x)
  }
  assign.impute.mean <- function(data, impute.mean) {
      cn <- colnames(data)
      p <- length(cn)
      out <- vector("list", p)
      names(out) <- cn
      for (j in seq_len(p)) {
          nm <- cn[j]
          x <- data[[nm]]
          na_idx <- is.na(x)
          if (any(na_idx)) {
              x[na_idx] <- impute.mean[[nm]]
          }
          out[[j]] <- x
      }
      data.frame(out, row.names = rownames(data), stringsAsFactors = TRUE, check.names = FALSE)
  }
  ginverse <- function(X, tol = sqrt(.Machine$double.eps), test = FALSE) {
      X <- as.matrix(X)
      if (nrow(X) >= ncol(X)) {
          Xinv <- ginverse.workhorse(X, tol)
      }
      else {
          Xinv <- t(ginverse.workhorse(t(X), tol))
      }
      if (test) {
          p1 <- summary(c(X %*% Xinv %*% X - X))
          p2 <- summary(c(Xinv %*% X %*% Xinv - Xinv))
          p3 <- summary(c(X %*% Xinv - t(X %*% Xinv)))
          message("Test three properties of the generalized inverse:\n",
                  paste(utils::capture.output(p1, p2, p3), collapse = "\n"))
      }
      Xinv
  }
  km_censor_fit <- function(time, status) {
      stopifnot(length(time) == length(status))
      ok <- !is.na(time) & !is.na(status)
      time <- as.numeric(time[ok])
      status <- as.integer(status[ok])
      n <- length(time)
      if (n == 0L) 
          stop("No non-missing training outcomes.")
      ord <- order(time)
      t <- time[ord]
      s <- status[ord]
      times <- numeric(n)
      G <- numeric(n)
      surv <- 1
      n_risk <- n
      k <- 0L
      i <- 1L
      while (i <= n) {
          ti <- t[i]
          j <- i
          d_death <- 0L
          d_cens <- 0L
          while (j <= n && t[j] == ti) {
              if (s[j] == 1L) 
                  d_death <- d_death + 1L
              else d_cens <- d_cens + 1L
              j <- j + 1L
          }
          n_after_death <- n_risk - d_death
          if (d_cens > 0L) {
              if (n_after_death <= 0L) {
                  surv <- 0
              }
              else {
                  surv <- surv * (1 - d_cens/n_after_death)
              }
          }
          k <- k + 1L
          times[k] <- ti
          G[k] <- surv
          n_risk <- n_risk - (d_death + d_cens)
          i <- j
      }
      list(time = times[1L:k], G = G[1L:k])
  }
  uno_Ghat_minus_predict <- function(time_knots, G, t_new) {
      .km.censor.predict(time_knots, G, t_new, type = "left")
  }
  uno_choose_gmin_auto <- function(G_event, eps = 1e-12, ess_frac = 0.2, ess_min = 20L) {
      g <- as.numeric(G_event)
      g <- g[is.finite(g) & !is.na(g)]
      d <- length(g)
      if (d <= 1L) {
          return(list(gmin = 0, ess_target = NA_real_, ess_kept = NA_real_, n_events = d, n_dropped = 0L, 
              wmax_kept = NA_real_))
      }
      if (min(g) >= 1 - 1e-12) {
          return(list(gmin = 0, ess_target = d, ess_kept = d, n_events = d, n_dropped = 0L, wmax_kept = 1))
      }
      g_sorted <- sort(g)
      w_desc <- 1/pmax(g_sorted, eps)^2
      p1 <- c(0, cumsum(w_desc))
      p2 <- c(0, cumsum(w_desc * w_desc))
      ess_target <- max(as.integer(ess_min), as.integer(ceiling(ess_frac * d)))
      ess_target <- min(ess_target, d)
      best_k <- 0L
      best_ess <- NA_real_
      for (k in 0L:(d - ess_target)) {
          sum_w <- p1[d + 1L] - p1[k + 1L]
          sum_w2 <- p2[d + 1L] - p2[k + 1L]
          ess_k <- if (sum_w2 > 0) 
              (sum_w * sum_w)/sum_w2
          else NA_real_
          if (is.finite(ess_k) && (ess_k >= ess_target)) {
              best_k <- k
              best_ess <- ess_k
              break
          }
      }
      if (!is.finite(best_ess)) {
          best_k <- d - ess_target
          sum_w <- p1[d + 1L] - p1[best_k + 1L]
          sum_w2 <- p2[d + 1L] - p2[best_k + 1L]
          best_ess <- if (sum_w2 > 0) 
              (sum_w * sum_w)/sum_w2
          else NA_real_
      }
      gmin <- g_sorted[best_k + 1L]
      wmax <- 1/pmax(gmin, eps)^2
      list(gmin = gmin, ess_target = ess_target, ess_kept = best_ess, n_events = d, n_dropped = best_k, 
          wmax_kept = wmax)
  }
  uno.prepare.test <- function(time_test, status_test, fit, eps = 1e-12, drop_if_G0 = FALSE) {
      w <- get.uno.weights.test(time_test, fit, eps = eps, drop_if_G0 = drop_if_G0)
      list(time = time_test, status = status_test, weight = w)
  }
  get.holdout.specs <- function(vtry, p, ntree, block.size, mode) {
      if (!is.list(vtry)) {
          if (vtry > 0) {
              holdout <- make.holdout.array(vtry, p, ntree, NULL)
          }
          else {
              stop("vtry must be positive")
          }
      }
      else {
          xvar <- unlist(vtry[1])
          joint <- unlist(vtry[2])
          if (!joint) {
              vtry <- 1
          }
          else {
              vtry <- length(xvar)
          }
          if (!joint) {
              holdout <- do.call(cbind, lapply(1:ntree, function(b) {
                  ho <- rep(0, p)
                  ho[resample(xvar, size = 1, replace = FALSE)] <- 1
                  ho
              }))
          }
          else {
              holdout <- matrix(0, p, ntree)
              holdout[xvar, ] <- 1
          }
      }
      obj <- list(as.integer(vtry), as.integer(holdout), as.integer(block.size), as.integer(0))
      names(obj) = c("vtry", "holdout", "block.size", "mode")
      return(switch.holdout.specs(obj, mode))
  }
  switch.holdout.specs <- function(obj, mode) {
      if (mode == "baseline") {
          new.mode = 1
      }
      else if (mode == "holdout") {
          new.mode = 2
      }
      else if (mode == "natural") {
          new.mode = 3
      }
      else {
          stop("vtry mode invalid")
      }
      obj$mode = as.integer(new.mode)
      return(obj)
  }
  ginverse.workhorse <- function(X, tol) {
      Xsvd <- svd(X)
      Positive <- Xsvd$d > max(tol * Xsvd$d[1L], 0)
      if (all(Positive)) {
          Xsvd$v %*% (1/Xsvd$d * t(Xsvd$u))
      }
      else if (!any(Positive)) {
          array(0, dim(X)[2L:1L])
      }
      else {
          Xsvd$v[, Positive, drop = FALSE] %*% ((1/Xsvd$d[Positive]) * t(Xsvd$u[, Positive, drop = FALSE]))
      }
  }
  get.event.info <- function(obj, subset = NULL) {
      if (grepl("surv", obj$family)) {
          if (!is.null(obj$yvar)) {
              if (is.null(subset)) {
                  subset <- (1:nrow(cbind(obj$yvar)))
              }
              if (is.null(obj$subj)) {
                  r.dim <- 2
                  time <- obj$yvar[subset, 1]
                  cens <- obj$yvar[subset, 2]
              }
              else {
                  r.dim <- 3
                  start.time <- obj$yvar[subset, 1]
                  time <- obj$yvar[subset, 2]
                  cens <- obj$yvar[subset, 3]
              }
              if (!all(floor(cens) == abs(cens), na.rm = TRUE)) {
                  stop("for survival families censoring variable must be coded as a non-negative integer")
              }
              event <- na.omit(cens)[na.omit(cens) > 0]
              event.type <- sort(unique(event))
          }
          else {
              r.dim <- 0
              event <- event.type <- cens <- cens <- time <- NULL
          }
          time.interest <- obj$time.interest
      }
      else {
          if ((obj$family == "regr+") | (obj$family == "class+")) {
              r.dim <- dim(obj$yvar)[2]
          }
          else {
              r.dim <- 1
          }
          event <- event.type <- cens <- time.interest <- cens <- time <- NULL
      }
      return(list(event = event, event.type = event.type, cens = cens, time.interest = time.interest, time = time, 
          r.dim = r.dim))
  }
  .km.censor.predict <- function(time_knots, G, t_new, type = c("left", "right")) {
      type <- match.arg(type)
      t_new <- as.numeric(t_new)
      out <- rep(NA_real_, length(t_new))
      ok <- !is.na(t_new)
      if (!any(ok)) 
          return(out)
      if (length(time_knots) == 0L) {
          out[ok] <- 1
          return(out)
      }
      idx <- if (type == "left") {
          findInterval(t_new[ok], time_knots, left.open = TRUE)
      }
      else {
          findInterval(t_new[ok], time_knots)
      }
      out[ok] <- c(1, G)[1L + idx]
      out
  }
  get.uno.weights.test <- function(time_test, fit, eps = 1e-12, drop_if_G0 = FALSE) {
      if (is.null(fit$time) || is.null(fit$G)) 
          stop("fit must be a list with elements $time and $G")
      gmin_used <- if (!is.null(fit$gmin) && is.finite(fit$gmin)) 
          fit$gmin
      else 0
      eps_keep <- if (!is.null(fit$eps_keep) && is.finite(fit$eps_keep)) 
          fit$eps_keep
      else .Machine$double.eps
      G_gate <- uno_Ghat_minus_predict(fit$time, fit$G, time_test)
      w <- rep(0, length(time_test))
      ok <- !is.na(G_gate)
      if (!drop_if_G0) {
          keep <- ok & (G_gate >= gmin_used)
      }
      else {
          keep <- ok & (G_gate >= gmin_used) & (G_gate > eps)
      }
      drop <- ok & !keep
      if (any(keep)) {
          Gsafe <- pmax(G_gate[keep], eps)
          w[keep] <- 1/(Gsafe * Gsafe)
      }
      if (any(drop)) {
          w[drop] <- eps_keep
      }
      w
  }
  partial.rfsrc <- function(object, oob = TRUE, partial.type = NULL, partial.xvar = NULL, partial.values = NULL, 
      partial.xvar2 = NULL, partial.values2 = NULL, partial.time = NULL, get.tree = NULL, seed = NULL, 
      do.trace = FALSE, ...) {
      user.option <- list(...)
      if (missing(object)) {
          stop("object is missing!")
      }
      if (sum(inherits(object, c("rfsrc", "grow"), TRUE) == c(1, 2)) != 2 & sum(inherits(object, c("rfsrc", 
          "forest"), TRUE) == c(1, 2)) != 2) {
          stop("this function only works for objects of class `(rfsrc, grow)' or '(rfsrc, forest)'")
      }
      if (inherits(object, "anonymous")) {
          stop("this function does not work with anonymous forests")
      }
      jitt <- is.hidden.jitt(user.option, "none", "na.omit", FALSE, partial = TRUE)
      data.pass <- is.hidden.data.pass(user.option)
      if (sum(inherits(object, c("rfsrc", "grow"), TRUE) == c(1, 2)) == 2) {
          if (is.forest.missing(object)) {
              stop("The forest is empty.  Re-run rfsrc (grow call) with forest=TRUE")
          }
          object <- object$forest
      }
      else {
      }
      if (!is.logical(oob) || length(oob) != 1L || is.na(oob)) {
          stop("'oob' must be TRUE or FALSE")
      }
      if (oob) {
          ensemble <- "oob"
      }
      else {
          ensemble <- "inbag"
      }
      family <- object$family
      splitrule <- object$splitrule
      xvar.names <- object$xvar.names
      yvar.names <- object$yvar.names
      if (!is.character(partial.xvar) || length(partial.xvar) != 1L || is.na(partial.xvar) || !(partial.xvar %in% 
          xvar.names)) {
          stop("'partial.xvar' must name one predictor in the forest")
      }
      .partial.check.values(partial.values, partial.xvar, object)
      partial.values <- sort(unique(partial.values))
      if (length(partial.xvar2) || length(partial.values2)) {
          if (!is.character(partial.xvar2) || anyNA(partial.xvar2) || anyDuplicated(partial.xvar2) || any(!(partial.xvar2 %in% 
              xvar.names)) || partial.xvar %in% partial.xvar2 || length(partial.xvar2) != length(partial.values2)) {
              stop("secondary predictors must be distinct forest predictors, different ", "from 'partial.xvar', with one value for each predictor")
          }
          for (i in seq_along(partial.xvar2)) {
              .partial.check.values(partial.values2[i], partial.xvar2[i], object)
          }
      }
      if (family %in% c("surv", "surv-CR")) {
          allowed <- if (family == "surv") 
              c("mort", "rel.freq", "surv", "chf")
          else c("years.lost", "cif", "chf")
          if (!is.character(partial.type) || length(partial.type) != 1L || is.na(partial.type)) {
              stop("specify one 'partial.type': ", paste(allowed, collapse = ", "))
          }
          partial.type <- match.arg(partial.type, allowed)
      }
      else if (grepl("surv", family)) {
          stop("this survival family is not supported by partial()")
      }
      yfactor <- object$yvar.factor
      m.target.idx <- 1:length(yvar.names)
      yvar.types <- yfactor$types
      yvar.nlevels <- yfactor$nlevels
      yvar.numeric.levels <- yfactor$numeric.levels
      subj <- object$subj
      event.info <- object$event.info
      event.type <- event.info$event.type
      partial.time.idx <- NULL
      if (family %in% c("surv", "surv-CR") && partial.type %in% c("surv", "cif", "chf")) {
          partial.time.idx <- .partial.time.index(partial.time, event.info$time.interest)
      }
      cr.bits <- get.cr.bits(family)
      xfactor <- object$xvar.factor
      xvar.types <- xfactor$types
      xvar.nlevels <- xfactor$nlevels
      xvar.numeric.levels <- xfactor$numeric.levels
      ntree <- object$ntree
      na.action = object$na.action
      xvar <- as.matrix(data.matrix(object$xvar))
      yvar <- as.matrix(data.matrix(object$yvar))
      r.dim <- ncol(cbind(yvar))
      rownames(xvar) <- colnames(xvar) <- NULL
      n.xvar <- ncol(xvar)
      n <- nrow(xvar)
      sampsize <- round(object$sampsize(n))
      case.wt <- object$case.wt
      samp <- object$samp
      outcome = "train"
      get.tree <- get.tree.index(get.tree, ntree)
      ensemble.bits <- get.ensemble.bits(ensemble)
      bootstrap.bits <- get.bootstrap.bits(object$bootstrap)
      na.action.bits <- get.na.action.bits(na.action)
      samptype.bits <- get.samptype.bits(object$samptype)
      partial.bits <- get.partial.bits(length(partial.values))
      terminal.qualts.bits <- get.terminal.qualts.predict.bits(object$terminal.qualts)
      terminal.quants.bits <- get.terminal.quants.predict.bits(object$terminal.quants)
      data.pass.bits <- get.data.pass.bits(data.pass)
      jitt.bits <- get.jitt.bits(jitt)
      seed <- get.seed(seed)
      do.trace <- get.trace.bits(do.trace)
      pivot = 0
      chunk = 0
      nativeOutput <- tryCatch({
          .Call("sl_rfsrcPredict", as.integer(do.trace), as.integer(seed), as.integer(ensemble.bits + bootstrap.bits + 
              cr.bits), as.integer(samptype.bits + na.action.bits + terminal.qualts.bits + terminal.quants.bits + 
              partial.bits + data.pass.bits + jitt.bits), as.numeric(1), as.integer(ntree), as.integer(n), 
              list(as.integer(length(yvar.types)), if (is.null(yvar.types)) NULL else as.character(yvar.types), 
                  if (is.null(yvar.types)) NULL else as.integer(yvar.nlevels), if (is.null(yvar.numeric.levels)) NULL else sapply(1:length(yvar.numeric.levels), 
                    function(nn) {
                      as.integer(length(yvar.numeric.levels[[nn]]))
                    }), if (is.null(subj)) NULL else as.integer(subj), if (is.null(event.type)) NULL else as.integer(length(event.type)), 
                  if (is.null(event.type)) NULL else as.integer(event.type)), if (is.null(yvar.numeric.levels)) {
                  NULL
              } else {
                  lapply(1:length(yvar.numeric.levels), function(nn) {
                    as.integer(yvar.numeric.levels[[nn]])
                  })
              }, if (is.null(yvar.types)) NULL else as.double(as.vector(yvar)), list(as.integer(n.xvar), 
                  as.character(xvar.types), if (is.null(xvar.types)) NULL else as.integer(xvar.nlevels), 
                  if (is.null(xvar.numeric.levels)) NULL else sapply(1:length(xvar.numeric.levels), function(nn) {
                    as.integer(length(xvar.numeric.levels[[nn]]))
                  }), NULL, NULL), if (is.null(xvar.numeric.levels)) {
                  NULL
              } else {
                  lapply(1:length(xvar.numeric.levels), function(nn) {
                    as.integer(xvar.numeric.levels[[nn]])
                  })
              }, as.double(as.vector(xvar)), list(as.integer(length(case.wt)), if (is.null(case.wt)) NULL else as.double(case.wt), 
                  as.integer(sampsize), if (is.null(samp)) NULL else as.integer(samp)), list(if (is.null(event.info$time.interest)) as.integer(0) else as.integer(length(event.info$time.interest)), 
                  if (is.null(event.info$time.interest)) NULL else as.double(event.info$time.interest)), 
              as.integer(object$totalNodeCount), as.integer(object$leafCount), list(as.integer(object$seed), 
                  if (is.null(object$seedVimp)) NULL else as.integer(object$seedVimp), as.integer(object$optLoGrow)), 
              as.integer(0), NULL, as.integer((object$nativeArray)$treeID), as.integer((object$nativeArray)$nodeID), 
              as.integer((object$nativeArray)$nodeSZ), as.integer((object$nativeArray)$brnodeID), list(as.integer((object$nativeArray)$parmID), 
                  as.double((object$nativeArray)$contPT), as.integer((object$nativeArray)$mwcpSZ), as.integer((object$nativeArray)$fsrecID), 
                  if (is.null((object$nativeFactorArray)$mwcpPT)) NULL else as.integer((object$nativeFactorArray)$mwcpPT)), 
              NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, as.integer(object$nativeArrayTNDS$tnRMBR), 
              as.integer(object$nativeArrayTNDS$tnAMBR), as.integer(object$nativeArrayTNDS$tnRCNT), as.integer(object$nativeArrayTNDS$tnACNT), 
              as.double((object$nativeArrayTNDS$tnSURV)), as.double((object$nativeArrayTNDS$tnMORT)), as.double((object$nativeArrayTNDS$tnNLSN)), 
              as.double((object$nativeArrayTNDS$tnCSHZ)), as.double((object$nativeArrayTNDS$tnCIFN)), as.double((object$nativeArrayTNDS$tnREGR)), 
              as.integer((object$nativeArrayTNDS$tnCLAS)), list(if (is.null(m.target.idx)) as.integer(0) else as.integer(length(m.target.idx)), 
                  if (is.null(m.target.idx)) NULL else as.integer(m.target.idx)), as.integer(0), NULL, 
              list(as.integer(0), NULL), list(as.integer(get.partial.type(family, partial.type)), as.integer(which(xvar.names == 
                  partial.xvar)), as.integer(length(partial.values)), as.double(partial.values), as.integer(length(partial.xvar2)), 
                  if (length(partial.xvar2) == 0) NULL else as.integer(match(partial.xvar2, xvar.names)), 
                  as.double(partial.values2)), as.integer(0), as.integer(0), as.double(NULL), as.double(NULL), 
              as.integer(ntree), list(as.integer(0), NULL, as.double(0)), as.integer(get.tree), NULL, as.integer(get.rf.cores()), 
              PACKAGE = "survlearning")
      }, error = function(e) {
          stop(e)
      })
      if (is.null(nativeOutput)) {
          stop("An error has occurred in prediction.  Please turn trace on for further analysis.")
      }
      rfsrcOutput <- list(call = match.call(), family = family, partial.time = partial.time)
      if (family == "surv") {
          if ((partial.type == "rel.freq") || (partial.type == "mort")) {
              mort.names <- list(NULL, NULL)
              survOutput <- (if (!is.null(nativeOutput$partialSurv)) 
                  array(nativeOutput$partialSurv, c(n, length(partial.values)), dimnames = mort.names)
              else NULL)
          }
          else if (partial.type == "chf") {
              nlsn.names <- list(NULL, NULL, NULL)
              survOutput <- (if (!is.null(nativeOutput$partialSurv)) 
                  array(nativeOutput$partialSurv, c(n, length(event.info$time.interest), length(partial.values)), 
                    dimnames = nlsn.names)
              else NULL)
              if (!is.null(survOutput)) {
                  survOutput <- survOutput[, partial.time.idx, , drop = FALSE]
              }
          }
          else if (partial.type == "surv") {
              surv.names <- list(NULL, NULL, NULL)
              survOutput <- (if (!is.null(nativeOutput$partialSurv)) 
                  array(nativeOutput$partialSurv, c(n, length(event.info$time.interest), length(partial.values)), 
                    dimnames = surv.names)
              else NULL)
              if (!is.null(survOutput)) {
                  survOutput <- survOutput[, partial.time.idx, , drop = FALSE]
              }
          }
          else {
              stop("Invalid choice for 'partial.type' option:  ", partial.type)
          }
          rfsrcOutput <- c(rfsrcOutput, survOutput = list(survOutput))
      }
      else if (family == "surv-CR") {
          if (partial.type == "years.lost") {
              yrls.names <- list(NULL, NULL, NULL)
              survOutput <- (if (!is.null(nativeOutput$partialSurv)) 
                  array(nativeOutput$partialSurv, c(n, length(event.info$event.type), length(partial.values)), 
                    dimnames = yrls.names)
              else NULL)
          }
          else if (partial.type == "cif") {
              cifn.names <- list(NULL, NULL, NULL, NULL)
              survOutput <- (if (!is.null(nativeOutput$partialSurv)) 
                  array(nativeOutput$partialSurv, c(n, length(event.info$time.interest), length(event.info$event.type), 
                    length(partial.values)), dimnames = cifn.names)
              else NULL)
              if (!is.null(survOutput)) {
                  survOutput <- survOutput[, partial.time.idx, , , drop = FALSE]
              }
          }
          else if (partial.type == "chf") {
              chfn.names <- list(NULL, NULL, NULL, NULL)
              survOutput <- (if (!is.null(nativeOutput$partialSurv)) 
                  array(nativeOutput$partialSurv, c(n, length(event.info$time.interest), length(event.info$event.type), 
                    length(partial.values)), dimnames = chfn.names)
              else NULL)
              if (!is.null(survOutput)) {
                  survOutput <- survOutput[, partial.time.idx, , , drop = FALSE]
              }
          }
          else {
              stop("Invalid choice for 'partial.type' option:  ", partial.type)
          }
          rfsrcOutput <- c(rfsrcOutput, survOutput = list(survOutput))
      }
      else {
          class.index <- which(yvar.types != "R")
          class.count <- length(class.index)
          regr.index <- which(yvar.types == "R")
          regr.count <- length(regr.index)
          if (class.count > 0) {
              classOutput <- vector("list", class.count)
              names(classOutput) <- yvar.names[class.index]
              levels.count <- array(0, class.count)
              levels.names <- vector("list", class.count)
              counter <- 0
              for (i in class.index) {
                  counter <- counter + 1
                  levels.count[counter] <- yvar.nlevels[i]
                  if (yvar.types[i] == "C") {
                    levels.names[[counter]] <- yfactor$levels[[which(yfactor$factor == yvar.names[i])]]
                  }
                  else {
                    levels.names[[counter]] <- yfactor$order.levels[[which(yfactor$order == yvar.names[i])]]
                  }
              }
              iter.start <- 0
              iter.end <- 0
              offset <- vector("list", class.count)
              for (p in 1:length(partial.values)) {
                  for (k in 1:length(m.target.idx)) {
                    target.idx <- which(class.index == m.target.idx[k])
                    if (length(target.idx) > 0) {
                      iter.start <- iter.end
                      iter.end <- iter.start + ((1 + levels.count[target.idx]) * n)
                      offset[[target.idx]] <- c(offset[[target.idx]], (iter.start + 1):iter.end)
                    }
                  }
              }
              for (i in 1:length(m.target.idx)) {
                  target.idx <- which(class.index == m.target.idx[i])
                  if (length(target.idx) > 0) {
                    ens.names <- list(NULL, c("all", levels.names[[target.idx]]), NULL)
                    ensemble <- (if (!is.null(nativeOutput$partialClas)) 
                      array(nativeOutput$partialClas[offset[[target.idx]]], c(n, 1 + levels.count[target.idx], 
                        length(partial.values)), dimnames = ens.names)
                    else NULL)
                    classOutput[[target.idx]] <- ensemble
                    remove(ensemble)
                  }
              }
              rfsrcOutput <- c(rfsrcOutput, classOutput = list(classOutput))
          }
          if (regr.count > 0) {
              regrOutput <- vector("list", regr.count)
              names(regrOutput) <- yvar.names[regr.index]
              iter.start <- 0
              iter.end <- 0
              offset <- vector("list", regr.count)
              for (p in 1:length(partial.values)) {
                  for (k in 1:length(m.target.idx)) {
                    target.idx <- which(regr.index == m.target.idx[k])
                    if (length(target.idx) > 0) {
                      iter.start <- iter.end
                      iter.end <- iter.start + n
                      offset[[target.idx]] <- c(offset[[target.idx]], (iter.start + 1):iter.end)
                    }
                  }
              }
              for (i in 1:length(m.target.idx)) {
                  target.idx <- which(regr.index == m.target.idx[i])
                  if (length(target.idx) > 0) {
                    ens.names <- list(NULL, NULL)
                    ensemble <- (if (!is.null(nativeOutput$partialRegr)) 
                      array(nativeOutput$partialRegr[offset[[target.idx]]], c(n, length(partial.values)), 
                        dimnames = ens.names)
                    else NULL)
                    regrOutput[[target.idx]] <- ensemble
                    remove(ensemble)
                  }
              }
              rfsrcOutput <- c(rfsrcOutput, regrOutput = list(regrOutput))
          }
      }
      rfsrcOutput$partial.values <- partial.values
      rfsrcOutput$yvar.names <- object$yvar.names
      rfsrcOutput$event.info <- object$event.info
      class(rfsrcOutput) <- c("rfsrc", "partial", family)
      return(rfsrcOutput)
  }
  make.holdout.array <- function(vtry = 0, p, ntree, ntree.allvars = NULL) {
      if (vtry == 0) {
          return(NULL)
      }
      if (vtry < 0 || vtry >= p) {
          stop("vtry must be positive and less than the feature dimension")
      }
      holdout <- do.call(cbind, lapply(1:ntree, function(b) {
          ho <- rep(0, p)
          ho[resample(1:p, size = vtry, replace = FALSE)] <- 1
          ho
      }))
      if (is.null(ntree.allvars)) {
          holdout
      }
      else {
          cbind(matrix(0, p, ntree.allvars), holdout)
      }
  }
  .partial.check.values <- function(values, name, object) {
      if (!is.numeric(values) || !is.null(dim(values)) || !length(values) || any(!is.finite(values))) {
          stop("partial values for '", name, "' must be a nonempty finite numeric vector")
      }
      labels <- .partial.factor.levels(object, name)
      if (length(labels) && any(values != floor(values) | values < 1L | values > length(labels))) {
          stop("partial values for factor '", name, "' must use the original training codes 1 to ", length(labels))
      }
      invisible(NULL)
  }
  get.partial.type <- function(family, partial.type) {
      if (family == "surv") {
          if (partial.type == "rel.freq") {
              partial.type <- "mort"
          }
          type <- match(partial.type, c("mort", "chf", "surv"))
      }
      else if (family == "surv-CR") {
          type <- match(partial.type, c("years.lost", "cif", "chf"))
      }
      else {
          type <- 0
      }
      if (is.na(type)) {
          stop("Invalid choice for 'partial.type' option:  ", partial.type)
      }
      return(type)
  }
  .partial.time.index <- function(times, grid, name = "partial.time", single = FALSE) {
      if (!is.numeric(grid) || !length(grid) || any(!is.finite(grid)) || is.unsorted(grid)) {
          stop("the forest does not contain a valid ordered time.interest grid")
      }
      if (!is.numeric(times) || !is.null(dim(times)) || !length(times) || any(!is.finite(times)) || (single && 
          length(times) != 1L)) {
          stop("'", name, "' must contain ", if (single) 
              "one finite time"
          else "finite evaluation times")
      }
      if (any(times < grid[1L])) {
          stop("'", name, "' must not precede the first stored time (", grid[1L], "). Select a time from the forest's time.interest grid.")
      }
      findInterval(times, grid)
  }
  .partial.factor.levels <- function(object, name) {
      fm <- object$xvar.factor
      j <- match(name, fm$factor)
      if (!is.na(j)) 
          return(fm$levels[[j]])
      j <- match(name, fm$order)
      if (!is.na(j)) 
          return(fm$order.levels[[j]])
      if (!is.null(object$xvar)) {
          xx <- if (is.matrix(object$xvar)) 
              object$xvar[, name]
          else object$xvar[[name]]
          return(levels(xx))
      }
      NULL
  }
  holdout.vimp <- holdout.vimp.rfsrc
  partial <- partial.rfsrc
  list(fit = rfsrc, predict = predict.rfsrc)
})
