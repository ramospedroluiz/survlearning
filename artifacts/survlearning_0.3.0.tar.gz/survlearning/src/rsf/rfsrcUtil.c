/* Derived from randomForestSRC 3.9.0, Ishwaran and Kogalur.
 * GPL (>= 3); see inst/COPYRIGHTS. Numerical core retained. */

// *** THIS HEADER IS AUTO GENERATED. DO NOT EDIT IT ***
#include           "global.h"
#include           "external.h"

// *** THIS HEADER IS AUTO GENERATED. DO NOT EDIT IT ***

      
    

#include "rfsrcUtil.h"
#include "survival.h"
#include "survivalE.h"
#include "classification.h"
#include "regression.h"
#include "impute.h"
#include "termOps.h"
#include "nrutil.h"
void updateTerminalNodeOutcomes(char       mode,
                                uint       treeID,
                                Terminal  *parent,
                                uint      *repMembrIndx,
                                uint       repMembrSize,
                                uint      *genMembrIndx,
                                uint       genMembrSize,
                                uint      *rmbrIterator,
                                uint      *ambrIterator) {
  uint clasIterator, regrIterator;
  uint i;
  if (!(SL_RF_optHigh & OPT_JIT_TOP)) {
    if (SL_RF_optHigh & OPT_MEMB_INCG) {
      for (i = 1; i <= genMembrSize; i++) {
        ++(*ambrIterator);
        SL_RF_tTermMembership[treeID][SL_RF_AMBR_ID_ptr[treeID][(*ambrIterator)]] = parent;
      }
    }
    else if (SL_RF_optHigh & OPT_MEMB_OUTG) {
      for (i = 1; i <= genMembrSize; i++) {
        SL_RF_tTermMembership[treeID][genMembrIndx[i]] = parent;
        SL_RF_AMBR_ID_ptr[treeID][++(*ambrIterator)] = genMembrIndx[i];
      }
    }
    else {
      for (i = 1; i <= genMembrSize; i++) {
        SL_RF_tTermMembership[treeID][genMembrIndx[i]] = parent;
      }
    }
  }  
  if ((SL_RF_opt & OPT_PERF) ||
      (SL_RF_opt & OPT_OENS) ||
      (SL_RF_opt & OPT_FENS)) {
    if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
      getAtRiskAndEventCount(treeID, parent, repMembrIndx, repMembrSize, genMembrIndx, genMembrSize, rmbrIterator);
      if (!(SL_RF_optHigh & OPT_TERM_INCG)) {
        getLocalRatio(treeID, parent);
        getLocalSurvival(treeID, parent);
        if (!(SL_RF_opt & OPT_COMP_RISK)) {
          getLocalNelsonAalen(treeID, parent);
        }
        else {
          getLocalCSH(treeID, parent);
          getLocalCIF(treeID, parent);
        }
        unstackAtRiskAndEventCount(parent);
      }  
      if (!(SL_RF_opt & OPT_COMP_RISK)) {
        getSurvival(treeID, parent);
        getNelsonAalen(treeID, parent);
      }
      else {
        getCSH(treeID, parent);
        getCIF(treeID, parent);
      }
      getMortality(treeID, parent);
      freeTerminalNodeLocalSurvivalStructures(parent);
    }
    else {
      clasIterator = regrIterator = *rmbrIterator;
      if (SL_RF_rFactorCount > 0) {
        getMultiClassProb(treeID, parent, repMembrIndx, repMembrSize, genMembrIndx, genMembrSize, & clasIterator);
        *rmbrIterator = clasIterator;
      }
      if (SL_RF_rNonFactorCount > 0) {
        getMeanResponse(treeID, parent, repMembrIndx, repMembrSize, genMembrIndx, genMembrSize, & regrIterator);
        *rmbrIterator = regrIterator;
      }
    }
  }
  else {
    getMembrCountOnly(treeID, parent, repMembrIndx, repMembrSize, genMembrIndx, genMembrSize);
  }
}
void getMembrCountOnly (uint       treeID,
                        Terminal  *parent,
                        uint      *repMembrIndx,
                        uint       repMembrSize,
                        uint      *genMembrIndx,
                        uint       genMembrSize) {
  if ( !(SL_RF_opt & OPT_BOOT_TYP1) && (SL_RF_opt & OPT_BOOT_TYP2) ) {
    parent -> membrCount = genMembrSize;
  }
  else {
    parent -> membrCount = repMembrSize;
    if (SL_RF_optHigh & OPT_MEMB_OUTG) {
    }
    if (SL_RF_optHigh & OPT_MEMB_INCG) {
      parent -> membrCount = SL_RF_TN_RCNT_ptr[treeID][parent -> nodeID];
    }
  }
  if ((parent -> membrCount) == 0) {
    if (!(SL_RF_opt & OPT_OUTC_TYPE)) {
    }
  }
}
void updateEnsemble (char mode, uint b) {
  LeafLinkedObj *leafLinkedPtr;
  char      potentiallyMixedMultivariate;
    if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
      updateEnsembleSurvival(mode, b, FALSE);
    }
    else {
      potentiallyMixedMultivariate = FALSE;
      if (SL_RF_rTargetFactorCount > 0) {
        updateEnsembleMultiClass(mode, b, FALSE, potentiallyMixedMultivariate);
        potentiallyMixedMultivariate = TRUE;
      }
      if (SL_RF_rTargetNonFactorCount > 0) {
        updateEnsembleMean(mode, b, FALSE, potentiallyMixedMultivariate);
        if (SL_RF_opt & OPT_QUANTLE) {        
          updateQuantileStream(mode, b);
        }
        potentiallyMixedMultivariate = TRUE;
      }
    }
    switch (mode) {
    case SL_RF_GROW:
      if (!(SL_RF_optHigh & OPT_TERM_OUTG)) {
        if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
          leafLinkedPtr = SL_RF_leafLinkedObjHead[b] -> fwdLink;
          while (leafLinkedPtr != NULL) {
            freeTerminalNodeSurvivalStructuresIntermediate(leafLinkedPtr -> termPtr);
            leafLinkedPtr = leafLinkedPtr -> fwdLink;
          }
          if (!(SL_RF_opt & OPT_VIMP)) {
            leafLinkedPtr = SL_RF_leafLinkedObjHead[b] -> fwdLink;
            while (leafLinkedPtr != NULL) {
              freeTerminalNodeSurvivalStructuresFinal(leafLinkedPtr -> termPtr);
              leafLinkedPtr = leafLinkedPtr -> fwdLink;
            }
          }
        }
        else {
          if (!(SL_RF_opt & OPT_VIMP)) {
            leafLinkedPtr = SL_RF_leafLinkedObjHead[b] -> fwdLink;
            while (leafLinkedPtr != NULL) {
              freeTerminalNodeNonSurvivalStructures(leafLinkedPtr -> termPtr);
              leafLinkedPtr = leafLinkedPtr -> fwdLink;
            }
          }
        }
      }
      break;
    default:
      if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
        if (!(SL_RF_optHigh & OPT_PART_PLOT)) {
          leafLinkedPtr = SL_RF_leafLinkedObjHead[b] -> fwdLink;
          while (leafLinkedPtr != NULL) {
            freeTerminalNodeSurvivalStructuresIntermediate(leafLinkedPtr -> termPtr);
            leafLinkedPtr = leafLinkedPtr -> fwdLink;
          }
        }
        if (!(SL_RF_opt & OPT_VIMP) && !(SL_RF_optHigh & OPT_PART_PLOT)) {
          leafLinkedPtr = SL_RF_leafLinkedObjHead[b] -> fwdLink;
          while (leafLinkedPtr != NULL) {
            freeTerminalNodeSurvivalStructuresFinal(leafLinkedPtr -> termPtr);
            leafLinkedPtr = leafLinkedPtr -> fwdLink;
          }
        }
      }
      else {
        if (!(SL_RF_opt & OPT_VIMP) && !(SL_RF_optHigh & OPT_PART_PLOT)) {
          leafLinkedPtr = SL_RF_leafLinkedObjHead[b] -> fwdLink;
          while (leafLinkedPtr != NULL) {
            freeTerminalNodeNonSurvivalStructures(leafLinkedPtr -> termPtr);
            leafLinkedPtr = leafLinkedPtr -> fwdLink;
          }
        }
      }
      break;
    }
}
void summarizeFaithfulBlockPerformance (char        mode,
                                        uint        b,
                                        uint        blockID,
                                        double    **blkEnsembleMRTnum,
                                        double   ***blkEnsembleCLSnum,
                                        double    **blkEnsembleRGRnum,
                                        double     *blkEnsembleDen,
                                        double    **responsePtr,
                                        double    **perfMRTblk,
                                        double   ***perfCLSblk,
                                        double    **perfRGRblk) {
  uint      obsSize;
  obsSize = (mode == SL_RF_PRED) ?  SL_RF_fobservationSize : SL_RF_observationSize;
  if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
    getPerformance(b,
                   mode,
                   obsSize,
                   responsePtr,
                   blkEnsembleDen,
                   blkEnsembleMRTnum,
                   NULL,
                   NULL,
                   perfMRTblk[blockID],
                   NULL,
                   NULL);
  }
  else {
    if (SL_RF_rTargetFactorCount > 0) {
      getPerformance(b,
                     mode,
                     obsSize,
                     responsePtr,
                     blkEnsembleDen,
                     NULL,
                     blkEnsembleCLSnum,
                     NULL,
                     NULL,
                     perfCLSblk[blockID],
                     NULL);
    }
    if (SL_RF_rTargetNonFactorCount > 0) {
      getPerformance(b,
                     mode,
                     obsSize,
                     responsePtr,
                     blkEnsembleDen,
                     NULL,
                     NULL,
                     blkEnsembleRGRnum,
                     NULL,
                     NULL,
                     perfRGRblk[blockID]);
    }
  }
}
void summarizeHoldoutBlockPerformance (char        mode,
                                       uint        b,
                                       uint        xVarIdx,
                                       uint        blockID,
                                       double    **responsePtr,
                                       double    **holdMRTstd,
                                       double   ***holdCLSstd,
                                       double    **holdRGRstd,
                                       double     *holdEnsembleDen,
                                       double     *holdMRTptr,
                                       double    **holdCLSptr,
                                       double     *holdRGRptr) {
  uint      obsSize;
  obsSize = SL_RF_observationSize;
  if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
    getPerformance(b,
                   mode,
                   obsSize,
                   responsePtr,
                   holdEnsembleDen,
                   holdMRTstd,
                   NULL,
                   NULL,
                   holdMRTptr,
                   NULL,
                   NULL);
  }
  else {
    if (SL_RF_rTargetFactorCount > 0) {
      if (holdCLSstd != NULL) {
        getPerformance(b,
                       mode,
                       obsSize,
                       responsePtr,
                       holdEnsembleDen,
                       NULL,
                       holdCLSstd,
                       NULL,
                       NULL,
                       holdCLSptr,
                       NULL);
      }
    }
    if (SL_RF_rTargetNonFactorCount > 0) {
      if (holdRGRstd != NULL) {
        getPerformance(b,
                       mode,
                       obsSize,
                       responsePtr,
                       holdEnsembleDen,
                       NULL,
                       NULL,
                       holdRGRstd,
                       NULL,
                       NULL,
                       holdRGRptr);
      }
    }
  }
}
char stackAndImputePerfResponse(char      mode,
                                char      multImpFlag,
                                uint      b,
                                uint      loSerialTreeID,
                                uint      hiSerialTreeID,
                                uint     *serialTreePtr,
                                double ***responsePtr) {
  double **mResponsePtr;
  uint     obsSize;
  char     imputeFlag;
  uint     i, p;
  imputeFlag = FALSE;
  switch (mode) {
  case SL_RF_PRED:
    obsSize = SL_RF_fobservationSize;
    if (b == 0) {
      *responsePtr = SL_RF_fresponseIn;
    }
    else {
      *responsePtr = SL_RF_fresponse[b];
    }
    if (SL_RF_fmRecordSize > 0) {
      if(SL_RF_fmResponseFlag == TRUE) {
        imputeFlag = TRUE;
      }
    }
    break;
  default:
    obsSize  = SL_RF_observationSize;
    if (b == 0) {
      *responsePtr = SL_RF_responseIn;
    }
    else {
      *responsePtr = SL_RF_response[b];
    }
    if (multImpFlag == FALSE) {
      if (SL_RF_mRecordSize > 0) {
        if(SL_RF_mResponseFlag == TRUE) {
          imputeFlag = TRUE;
        }
      }
    }
    break;
  }
  if (imputeFlag) {
    mResponsePtr   = dmatrix(1, SL_RF_ySize, 1, obsSize);
    for (p = 1; p <= SL_RF_ySize; p++) {
      for (i = 1; i <= obsSize; i++) {
        mResponsePtr[p][i] = (*responsePtr)[p][i];
      }
    }
    if (b != 0) {
      imputeResponse(mode, loSerialTreeID, hiSerialTreeID, serialTreePtr, mResponsePtr);
      *responsePtr = mResponsePtr;
    }
    else {
      imputeUpdateShadow(mode, mResponsePtr, NULL);
      *responsePtr = mResponsePtr;
    }      
  }
  return imputeFlag;
}
void unstackPerfResponse(char mode, char flag, double **mResponsePtr) {
  uint obsSize;
  if (flag == TRUE) {
    obsSize = (mode == SL_RF_PRED) ?  SL_RF_fobservationSize : SL_RF_observationSize;
    free_dmatrix(mResponsePtr, 1, SL_RF_ySize, 1, obsSize);
  }
}
void getPerformance(uint      serialTreeID,
                    char      mode,
                    uint      obsSize,
                    double  **responsePtr,
                    double    *denomPtr,
                    double   **outcomeMRT,
                    double  ***outcomeCLS,
                    double   **outcomeRGR,
                    double   *perfMRTptr,
                    double  **perfCLSptr,
                    double   *perfRGRptr) {
  uint j, k;
  if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
    if (!(SL_RF_opt & OPT_COMP_RISK)) {
      perfMRTptr[1] = getConcordanceIndex(-1,
                                           obsSize,
                                           responsePtr[SL_RF_timeIndex],
                                           responsePtr[SL_RF_statusIndex],
                                           outcomeMRT[1],
                                           denomPtr,
                                           SL_RF_unoWeight);
    }
    else {
      double *cpv = dvector(1, SL_RF_eventTypeSize);
      getCRPerformance(mode,
                       obsSize,
                       responsePtr,
                       outcomeMRT,
                       denomPtr,
                       SL_RF_unoWeight,
                       cpv);
      for (j=1; j <= SL_RF_eventTypeSize; j++) {
        perfMRTptr[j] = cpv[j];
      }
      free_dvector(cpv, 1, SL_RF_eventTypeSize);
    }
  }
  else {
    if (perfCLSptr != NULL) {
      for (j = 1; j <= SL_RF_rTargetFactorCount; j++) {
        if (SL_RF_opt & OPT_PERF_CALB) {
          double *cpv = dvector(1, SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]);
          perfCLSptr[j][1] = getBrierScore(obsSize,
                                           SL_RF_rTargetFactor[j],                                                            
                                           responsePtr[SL_RF_rTargetFactor[j]],
                                           outcomeCLS[j],
                                           denomPtr,
                                           cpv);
          for (k = 1; k <= SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]; k++) {
            perfCLSptr[j][1+k] = cpv[k];
          }
          free_dvector(cpv, 1, SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]);
        }
        else if ((SL_RF_opt & OPT_PERF_GMN2) && (SL_RF_rFactorMinorityFlag[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]] == TRUE)) {
          double *maxVote = dvector(1, obsSize);
          getMaxVote(obsSize,
                     SL_RF_rTargetFactor[j],
                     outcomeCLS[j],
                     denomPtr,
                     maxVote);
          perfCLSptr[j][1] = getGMeanIndex(obsSize,
                                           SL_RF_rTargetFactor[j],
                                           responsePtr[SL_RF_rTargetFactor[j]],
                                           denomPtr,
                                           maxVote);
          free_dvector(maxVote, 1, obsSize);
        }
        else {
          double *cpv = dvector(1, SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]);
          double *maxVote = dvector(1, obsSize);
          getMaxVote(obsSize,
                     SL_RF_rTargetFactor[j],
                     outcomeCLS[j],
                     denomPtr,
                     maxVote);
          perfCLSptr[j][1] = getClassificationIndex(obsSize,
                                                    SL_RF_rTargetFactor[j],
                                                    responsePtr[SL_RF_rTargetFactor[j]],
                                                    denomPtr,
                                                    maxVote);
          getConditionalClassificationIndex(obsSize,
                                            SL_RF_rTargetFactor[j],
                                            responsePtr[SL_RF_rTargetFactor[j]],
                                            outcomeCLS[j],
                                            maxVote,
                                            denomPtr,
                                            cpv);
          for (k = 1; k <= SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]; k++) {
            perfCLSptr[j][1+k] = cpv[k];
          }
          free_dvector(cpv, 1, SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]);
          free_dvector(maxVote, 1, obsSize);
        }
      }
    }
    if (perfRGRptr != NULL) {
      for (j = 1; j <= SL_RF_rTargetNonFactorCount; j++) {
        perfRGRptr[j] = getMeanSquareError(obsSize,
                                           responsePtr[SL_RF_rTargetNonFactor[j]],
                                           outcomeRGR[j],
                                           denomPtr);
      }
    }
  }
}
void normalizeEnsembleEstimates(char mode, char final) {
  char oobFlag, fullFlag;
  uint      obsSize;
  double ***ensembleSRGptr;
  double  **ensembleMRTptr;
  double  **ensembleSRVptr;
  double ***ensembleCIFptr;
  double ***ensembleCLSptr;
  double  **ensembleRGRptr;
  double ***ensembleSRGnum;
  double  **ensembleMRTnum;
  double  **ensembleSRVnum;
  double ***ensembleCIFnum;
  double ***ensembleCLSnum;
  double  **ensembleRGRnum;
  double      ***ensembleQNTptr;
  QuantileObj ***quantileHead;
  uint         **quantileStreamSize;
  double   *ensembleDen;
  uint i, j, k;
  oobFlag = fullFlag = FALSE;
  switch (mode) {
  case SL_RF_PRED:
    obsSize = SL_RF_fobservationSize;
    oobFlag = FALSE;
    if (SL_RF_opt & OPT_FENS) {
      fullFlag = TRUE;
    }
    break;
  default:
    obsSize = SL_RF_observationSize;
    if (SL_RF_opt & OPT_OENS) {
      oobFlag = TRUE;
    }
    if (SL_RF_opt & OPT_FENS) {
      fullFlag = TRUE;
    }
    break;
  }
  while ((oobFlag == TRUE) || (fullFlag == TRUE)) {
    if (oobFlag == TRUE) {
      ensembleDen    = SL_RF_oobEnsembleDen;
      ensembleSRGptr = SL_RF_oobEnsembleSRGptr;
      ensembleMRTptr = SL_RF_oobEnsembleMRTptr;
      ensembleSRVptr = SL_RF_oobEnsembleSRVptr;
      ensembleCIFptr = SL_RF_oobEnsembleCIFptr;
      ensembleCLSptr = SL_RF_oobEnsembleCLSptr;
      ensembleRGRptr = SL_RF_oobEnsembleRGRptr;
      ensembleSRGnum = SL_RF_oobEnsembleSRGnum;
      ensembleMRTnum = SL_RF_oobEnsembleMRTnum;
      ensembleSRVnum = SL_RF_oobEnsembleSRVnum;
      ensembleCIFnum = SL_RF_oobEnsembleCIFnum;
      ensembleCLSnum = SL_RF_oobEnsembleCLSnum;
      ensembleRGRnum = SL_RF_oobEnsembleRGRnum;
      ensembleQNTptr     = SL_RF_oobEnsembleQNTptr;
      quantileHead       = SL_RF_oobQuantileHead;
      quantileStreamSize = SL_RF_oobQuantileStreamSize;
    }
    else {
      ensembleDen    = SL_RF_fullEnsembleDen;
      ensembleSRGptr = SL_RF_fullEnsembleSRGptr;
      ensembleMRTptr = SL_RF_fullEnsembleMRTptr;
      ensembleSRVptr = SL_RF_fullEnsembleSRVptr;
      ensembleCIFptr = SL_RF_fullEnsembleCIFptr;
      ensembleCLSptr = SL_RF_fullEnsembleCLSptr;
      ensembleRGRptr = SL_RF_fullEnsembleRGRptr;
      ensembleSRGnum = SL_RF_fullEnsembleSRGnum;
      ensembleMRTnum = SL_RF_fullEnsembleMRTnum;
      ensembleSRVnum = SL_RF_fullEnsembleSRVnum;
      ensembleCIFnum = SL_RF_fullEnsembleCIFnum;
      ensembleCLSnum = SL_RF_fullEnsembleCLSnum;
      ensembleRGRnum = SL_RF_fullEnsembleRGRnum;
      ensembleQNTptr     = SL_RF_fullEnsembleQNTptr;
      quantileHead       = SL_RF_fullQuantileHead;
      quantileStreamSize = SL_RF_fullQuantileStreamSize;
    }
    if ((SL_RF_timeIndex > 0) && (SL_RF_statusIndex > 0)) {
      for (i = 1; i <= obsSize; i++) {
        if (ensembleDen[i] != 0) {
          if (!(SL_RF_opt & OPT_COMP_RISK)) {
            if (final) {
              for (k = 1; k <= SL_RF_sortedTimeInterestSize; k++) {
                ensembleSRGptr[1][k][i] = ensembleSRGnum[1][k][i] / ensembleDen[i];
                ensembleSRVptr[k][i]    = ensembleSRVnum[k][i] / ensembleDen[i];
              }
            }
            ensembleMRTptr[1][i] = ensembleMRTnum[1][i] / ensembleDen[i];
          }
          else {
            for(j = 1; j <= SL_RF_eventTypeSize; j ++) {
              if (final) {              
                for (k = 1; k <= SL_RF_sortedTimeInterestSize; k++) {
                  ensembleSRGptr[j][k][i] = ensembleSRGnum[j][k][i] / ensembleDen[i];
                  ensembleCIFptr[j][k][i] = ensembleCIFnum[j][k][i] / ensembleDen[i];
                }
              }
              ensembleMRTptr[j][i] = ensembleMRTnum[j][i] / ensembleDen[i];
            }
          }
        }
        else {
          if (!(SL_RF_opt & OPT_COMP_RISK)) {
            if (final) {
              for (k = 1; k <= SL_RF_sortedTimeInterestSize; k++) {
                ensembleSRGptr[1][k][i] = SL_RF_nativeNaN;
                ensembleSRVptr[k][i]    = SL_RF_nativeNaN;
              }
            }
            ensembleMRTptr[1][i] = SL_RF_nativeNaN;
          }
          else {
            for(j = 1; j <= SL_RF_eventTypeSize; j ++) {
              if (final) {              
                for (k = 1; k <= SL_RF_sortedTimeInterestSize; k++) {
                  ensembleSRGptr[j][k][i] = SL_RF_nativeNaN;
                  ensembleCIFptr[j][k][i] = SL_RF_nativeNaN;
                }
              }
              ensembleMRTptr[j][i] = SL_RF_nativeNaN;
            }
          }          
        }
      }
    }  
    else {
      if (SL_RF_rTargetFactorCount > 0) {
        for (i = 1; i <= obsSize; i++) {
          if (ensembleDen[i] != 0) {
            for (j = 1; j <= SL_RF_rTargetFactorCount; j++) {
              for (k = 1; k <= SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]; k++) {
                ensembleCLSptr[j][k][i] = ensembleCLSnum[j][k][i] / ensembleDen[i];
              }
            }
          }
          else {
            for (j = 1; j <= SL_RF_rTargetFactorCount; j++) {
              for (k = 1; k <= SL_RF_rFactorSize[SL_RF_rFactorMap[SL_RF_rTargetFactor[j]]]; k++) {
                ensembleCLSptr[j][k][i] = SL_RF_nativeNaN;
              }
            }
          }
        }
      }
      if (SL_RF_rTargetNonFactorCount > 0) {      
        for (i = 1; i <= obsSize; i++) {
          if (ensembleDen[i] != 0) {
            for (j = 1; j <= SL_RF_rTargetNonFactorCount; j++) {
              ensembleRGRptr[j][i] = ensembleRGRnum[j][i] / ensembleDen[i];
            }
          }
          else {
            for (j = 1; j <= SL_RF_rTargetNonFactorCount; j++) {
              ensembleRGRptr[j][i] = SL_RF_nativeNaN;
            }
          }
        }
        if (final) {        
          if (SL_RF_opt & OPT_QUANTLE) {
            for (i = 1; i <= obsSize; i++) {
              if (ensembleDen[i] != 0) {
                for (j = 1; j <= SL_RF_rTargetNonFactorCount; j++) {
                  for (k = 1; k <= SL_RF_quantileSize; k++) {
                    ensembleQNTptr[j][k][i] = getApproxQuantile(quantileHead[j][i], SL_RF_quantile[k], quantileStreamSize[j][i]);
                  }
                }
              }
              else {
                for (j = 1; j <= SL_RF_rTargetNonFactorCount; j++) {
                  for (k = 1; k <= SL_RF_quantileSize; k++) {
                    ensembleQNTptr[j][k][i] = SL_RF_nativeNaN;
                  }
                }
              }
            }
          }
        }
      }
    }
    if (oobFlag == TRUE) {
      oobFlag = FALSE;
    }
    else {
      fullFlag = FALSE;
    }
  }  
}
char getPerfFlag (char mode, uint serialTreeID) {
  char result;
  if (SL_RF_opt & OPT_PERF) {
    result = TRUE;
  }
  else {
    result = FALSE;
  }
  if (result) {
    if (serialTreeID % SL_RF_perfBlock == 0){
    }
    else {
      if (serialTreeID == SL_RF_ntree) {
      }
      else {
        result = FALSE;
      }
    }
  }
  return result;
}
void getVariablesUsed(uint treeID, Node *parent, uint *varUsedVector) {
  SplitInfo *info;
  if (SL_RF_tLeafCount[treeID] > 0) {
    if (((parent -> left) != NULL) && ((parent -> right) != NULL)) {
      info = parent -> splitInfo;
      varUsedVector[info -> randomVar[1]] ++;
      getVariablesUsed(treeID, parent ->  left, varUsedVector);
      getVariablesUsed(treeID, parent -> right, varUsedVector);
    }
  }
  return;
}
