/* Derived from randomForestSRC 3.9.0, Ishwaran and Kogalur.
 * GPL (>= 3); see inst/COPYRIGHTS. Numerical core retained. */
#ifndef SL_RF_SPLIT_CUSTOM_H
#define SL_RF_SPLIT_CUSTOM_H
#define LEFT      0x01
#define RIGHT     0x02
#define CLAS_FAM     0
#define REGR_FAM     1
#define SURV_FAM     2
#define CRSK_FAM     3
void registerCustomFunctions(void);
extern void registerThis (double (*func) (unsigned int    n,
                                          char           *membership,
                                          double         *time,
                                          double         *event,
                                          unsigned int    eventTypeSize,
                                          unsigned int    eventTimeSize,
                                          double         *eventTime,
                                          double         *response,
                                          double          mean,
                                          double          variance,
                                          unsigned int    maxLevel,
                                          double        **feature,
                                          unsigned int    featureCount),
                          unsigned int family,
                          unsigned int slot);
double getCustomSplitStatisticMultivariateRegression  (unsigned int  n,
                                                       char         *membership,
                                                       double       *time,
                                                       double       *event,
                                                       unsigned int  eventTypeSize,
                                                       unsigned int  eventTimeSize,
                                                       double       *eventTime,
                                                       double       *response,
                                                       double        mean,
                                                       double        variance,
                                                       unsigned int  maxLevel,
                                                       double      **feature,
                                                       unsigned int  featureCount);
double getCustomSplitStatisticMultivariateClassification (unsigned int  n,
                                                          char         *membership,
                                                          double       *time,
                                                          double       *event,
                                                          unsigned int  eventTypeSize,
                                                          unsigned int  eventTimeSize,
                                                          double       *eventTime,
                                                          double       *response,
                                                          double        mean,
                                                          double        variance,
                                                          unsigned int  maxLevel,
                                                          double      **feature,
                                                          unsigned int  featureCount);
double getCustomSplitStatisticSurvival (unsigned int  n,
                                        char         *membership,
                                        double       *time,
                                        double       *event,
                                        unsigned int  eventTypeSize,
                                        unsigned int  eventTimeSize,
                                        double       *eventTime,
                                        double       *response,
                                        double        mean,
                                        double        variance,
                                        unsigned int  maxLevel,
                                        double      **feature,
                                        unsigned int  featureCount);
double getCustomSplitStatisticCompetingRisk (unsigned int  n,
                                             char         *membership,
                                             double       *time,
                                             double       *event,
                                             unsigned int  eventTypeSize,
                                             unsigned int  eventTimeSize,
                                             double       *eventTime,
                                             double       *response,
                                             double        mean,
                                             double        variance,
                                             unsigned int  maxLevel,
                                             double      **feature,
                                             unsigned int  featureCount);
unsigned int *alloc_uivector(unsigned int nh);
void          dealloc_uivector(unsigned int *v, unsigned int nh);
double       *alloc_dvector(double *v, unsigned int nh);
void          dealloc_dvector(double *v, unsigned int nh);
unsigned int **alloc_uimatrix(unsigned int n2h, unsigned int nh);
void          dealloc_uimatrix(unsigned int **v, unsigned int n2h, unsigned int nh);
#endif
